import { Video, Comment, Post } from '../types';

export const DEFAULT_USER = {
  name: "GamerCool YouTube",
  avatarUrl: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
  subscribers: 124000,
};

const MOCK_AVATARS = [
  "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&auto=format&fit=crop&q=80"
];

export const createMockComments = (videoId: string): Comment[] => [
  {
    id: `${videoId}-c1`,
    author: "Elena R.",
    avatarUrl: MOCK_AVATARS[0],
    text: "¡Qué locura de producción! Súper recomendado este video para repasar conceptos artísticos y técnicos. 🔥",
    timestamp: "Hace 2 horas",
    likes: 242,
    dislikes: 12,
  },
  {
    id: `${videoId}-c2`,
    author: "Carlos Tech",
    avatarUrl: MOCK_AVATARS[1],
    text: "Muy buena calidad del stream. Llevaba tiempo buscando un canal interactivo tan pulido.",
    timestamp: "Hace 4 horas",
    likes: 89,
    dislikes: 3,
  },
  {
    id: `${videoId}-c3`,
    author: "GamerPro99",
    avatarUrl: MOCK_AVATARS[2],
    text: "¡Espectacular! Definitivamente un hito técnico este portal OpenTube. Increíble clon.",
    timestamp: "Hace 1 día",
    likes: 18,
    dislikes: 1,
  },
  {
    id: `${videoId}-c4`,
    author: "Sofía Martínez",
    avatarUrl: MOCK_AVATARS[3],
    text: "Amo el estilo oscuro de la interfaz. Los controles se sienten súper bien.",
    timestamp: "Hace 3 días",
    likes: 56,
    dislikes: 0,
  }
];

export const INITIAL_VIDEOS: Video[] = [];

export const INITIAL_SHORTS: Video[] = [];

export const INITIAL_POSTS: Post[] = [
  {
    id: "p1",
    authorName: "GamerCool YouTube", // The main user
    authorAvatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
    isVerifiedAuthor: true, // gets the tick!
    text: "¡Hola a todos los suscriptores de OpenTube! Estoy probando la pestaña Comunidad del canal. ¿Qué les parece este clon interactivo completo construido con React, Tailwind CSS y Lucide? Dejen sus votos y me gustas aquí abajo. 🚀🎮",
    timestamp: "Hace 5 horas",
    likes: 842,
    dislikes: 11,
    comments: [
      {
        id: "p1-c1",
        author: "María Paz",
        avatarUrl: MOCK_AVATARS[4],
        text: "¡Te quedó increíble! Me encanta que compile tan rápido y se sienta súper fluido.",
        timestamp: "Hace 4 horas",
        likes: 45,
        dislikes: 1,
      },
      {
        id: "p1-c2",
        author: "Jorge Tech-Vlogs",
        avatarUrl: MOCK_AVATARS[3],
        text: "¡Buenísimo canal, amigazo! Saludos de un colega verificado ficticio (sin tick) jaja.",
        timestamp: "Hace 2 horas",
        likes: 12,
        dislikes: 0,
      }
    ]
  },
  {
    id: "p2",
    authorName: "GamerCool YouTube",
    authorAvatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
    isVerifiedAuthor: true,
    text: "Encuesta rápida: ¿Prefieren videos de larga duración con tutoriales profundos u OpenTube Shorts dinámicos sobre desarrollo de simuladores web de 2 a 3 minutos? ¡Voten dándole like!",
    timestamp: "Hace 2 días",
    likes: 1205,
    dislikes: 48,
    comments: [
      {
        id: "p2-c1",
        author: "DevMaster",
        avatarUrl: MOCK_AVATARS[1],
        text: "Definitivamente tutoriales largos de más de 60 segundos. Es donde mejor se entiende la lógica.",
        timestamp: "Hace 1 día",
        likes: 72,
        dislikes: 2,
      }
    ]
  }
];
