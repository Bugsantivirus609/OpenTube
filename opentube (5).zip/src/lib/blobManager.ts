/**
 * Circular Blob URL Tracker / Garbage Collector
 * Prevents memory leaks and browser crash on infinite preview uploads of videos.
 */
class BlobManager {
  private activeBlobs: Map<string, { url: string; timestamp: number }> = new Map();
  private maxActive = 15; // Circular buffer size limit for active blob URLs. Let's make it 15.

  /**
   * Register a dynamic Blob URL. If the maximum is exceeded,
   * we revoke the oldest registered Blob URL to clean up system memory.
   */
  register(id: string, url: string) {
    if (this.activeBlobs.has(id)) {
      // Re-register: revoke the old one first
      const existing = this.activeBlobs.get(id);
      if (existing) {
        URL.revokeObjectURL(existing.url);
      }
    }

    this.activeBlobs.set(id, { url, timestamp: Date.now() });

    // Enforce Circular Buffer
    if (this.activeBlobs.size > this.maxActive) {
      // Find the oldest record
      let oldestId: string | null = null;
      let oldestTime = Infinity;

      for (const [key, val] of this.activeBlobs.entries()) {
        if (val.timestamp < oldestTime) {
          oldestTime = val.timestamp;
          oldestId = key;
        }
      }

      if (oldestId) {
        const oldest = this.activeBlobs.get(oldestId);
        if (oldest) {
          console.log(`[BlobManager Circular Buffer] Revoking oldest URL for memory release:`, oldest.url);
          URL.revokeObjectURL(oldest.url);
        }
        this.activeBlobs.delete(oldestId);
      }
    }
  }

  /**
   * Safe and complete unmounting garbage collector.
   * Directly revokes a specific resource when deleted or changed.
   */
  revoke(id: string) {
    const existing = this.activeBlobs.get(id);
    if (existing) {
      URL.revokeObjectURL(existing.url);
      this.activeBlobs.delete(id);
      console.log(`[BlobManager Clean Unmount] Revoked URL for id ${id}:`, existing.url);
    }
  }

  /**
   * Auto-cleaning patch: instantly purges all registered blob URLs.
   */
  purgeAll() {
    console.log(`[BlobManager Auto-Clean Patch] Purging all active ${this.activeBlobs.size} Blob URL representations.`);
    for (const [id, value] of this.activeBlobs.entries()) {
      URL.revokeObjectURL(value.url);
    }
    this.activeBlobs.clear();
  }
}

export const blobManager = new BlobManager();
export default blobManager;
