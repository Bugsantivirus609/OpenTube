import Dexie, { type Table } from 'dexie';
import { Video } from '../types';

export interface DBVideo {
  id: string;
  title: string;
  description: string;
  videoUrl: string; // Blob URL representing the file
  thumbnailUrl: string; // Base64 representation or Blob URL representing the thumbnail file
  duration: number;
  views: number;
  uploadDate: string;
  likes: number;
  dislikes: number;
  userVoted?: 'like' | 'dislike';
  category: string;
  isShort: boolean;
  authorName: string;
  authorAvatar: string;
  isVerifiedAuthor: boolean;
  isAudio?: boolean;
  comments: any[];
  hashtags?: string[];
  language?: string;
  originalityScore?: number;
  
  // Storage of actual binary blobs to survive page refresh
  videoFileBlob?: Blob | File;
  thumbnailFileBlob?: Blob | File;
  binaryHash?: string; // Cache hash computed during upload
}

class OpenTubeDB extends Dexie {
  dbVideos!: Table<DBVideo>;

  constructor() {
    super('OpenTubeDB');
    this.version(1).stores({
      dbVideos: 'id, title, isShort, category, originalityScore, binaryHash'
    });
  }
}

export const db = new OpenTubeDB();

/**
 * Saves a video's binary files and metadata directly inside IndexedDB.
 */
export async function saveVideoToIndexedDB(video: Video, videoBlob?: Blob | File, thumbnailBlob?: Blob | File, hash?: string) {
  try {
    const dbVid: DBVideo = {
      ...video,
      videoFileBlob: videoBlob,
      thumbnailFileBlob: thumbnailBlob,
      binaryHash: hash
    };
    await db.dbVideos.put(dbVid);
    console.log(`[IndexedDB] Video "${video.title}" saved successfully to Dexie!`);
  } catch (err) {
    console.error("[IndexedDB] Error saving video:", err);
  }
}

/**
 * Deletes a video from IndexedDB.
 */
export async function deleteVideoFromIndexedDB(id: string) {
  try {
    await db.dbVideos.delete(id);
    console.log(`[IndexedDB] Video "${id}" removed from Dexie.`);
  } catch (err) {
    console.error("[IndexedDB] Error deleting video:", err);
  }
}

/**
 * Retrieves all stored custom videos from IndexedDB, re-creating live Blob URLs.
 * Also registers them in blobManager circular buffer.
 * @param registerBlob callback to register Blob URLs in circular buffer or garbage collector
 */
export async function loadVideosFromIndexedDB(registerBlob: (id: string, url: string) => void): Promise<Video[]> {
  try {
    const records = await db.dbVideos.toArray();
    console.log(`[IndexedDB] Loaded ${records.length} videos from Dexie.`);
    
    return records.map(record => {
      let finalVideoUrl = record.videoUrl;
      let finalThumbnailUrl = record.thumbnailUrl;
      
      // Re-apply Blob URLs if binary exists
      if (record.videoFileBlob) {
        finalVideoUrl = URL.createObjectURL(record.videoFileBlob);
        registerBlob(record.id + '-video', finalVideoUrl);
      }
      
      if (record.thumbnailFileBlob) {
        finalThumbnailUrl = URL.createObjectURL(record.thumbnailFileBlob);
        registerBlob(record.id + '-thumbnail', finalThumbnailUrl);
      }
      
      const { videoFileBlob, thumbnailFileBlob, ...videoMetadata } = record;
      return {
        ...videoMetadata,
        videoUrl: finalVideoUrl,
        thumbnailUrl: finalThumbnailUrl
      } as Video;
    });
  } catch (err) {
    console.error("[IndexedDB] Error loading videos:", err);
    return [];
  }
}

// Expose Dexie Database onto the window object for browser console debugging/terminal usage as requested by user
if (typeof window !== 'undefined') {
  (window as any).db = db;
}
