// Local AI "On-Device" Toxicity Moderator & Content Sanitizer
// Runs heuristics and pattern matching to simulate dynamic transformer model classification in client-side.

export interface ModerationResult {
  isToxic: boolean;
  score: number; // Percentage 0 - 100
  originalText: string;
  moderatedText: string;
  violations: string[];
  suggestedPoliteText: string;
}

const TOXIC_PATTERNS = [
  // Spanish slurs/offensive
  { word: "mierda", label: "Lenguaje Vulgar/Explicito", polite: "recuerdos agradables" },
  { word: "puto", label: "Llamado Ofensivo", polite: "estimado" },
  { word: "puta", label: "Llamado Ofensivo", polite: "estimada" },
  { word: "gilipollas", label: "Insulto/Falta de Respeto", polite: "amigo despistado" },
  { word: "basura", label: "Desprecio de Contenido", polite: "joya incomprendida" },
  { word: "asco", label: "Hostilidad Subjetiva", polite: "sensación particular" },
  { word: "tonto", label: "Subestimación/Insulto", polite: "corazón noble" },
  { word: "idiota", label: "Insulto Grave", polite: "genio incomprendido" },
  { word: "estupido", label: "Falta de Respeto", polite: "distraído" },
  { word: "estúpido", label: "Falta de Respeto", polite: "distraído" },
  { word: "cabron", label: "Insulto", polite: "valiente" },
  { word: "cabrón", label: "Insulto", polite: "valiente" },
  { word: "pendejo", label: "Insulto Hostil", polite: "muchacho alegre" },
  { word: "pendeja", label: "Insulto Hostil", polite: "muchacha alegre" },
  { word: "culiao", label: "Lenguaje Adulto", polite: "compañero" },
  { word: "coño", label: "Lenguaje Soez", polite: "caramba" },
  { word: "maldito", label: "Desprecio Hostil", polite: "bendito" },
  { word: "retardado", label: "Hostilidad/Discriminación", polite: "especial" },
  { word: "inútil", label: "Despectivo/Desprecio", polite: "colaborador en potencia" },
  { word: "inutil", label: "Despectivo/Desprecio", polite: "colaborador en potencia" },
  { word: "estafa", label: "Spam/Acusación Maliciosa", polite: "proyecto experimental" },
  { word: "fake", label: "Spam/Contenido Falso", polite: "ficción inspiradora" },
  { word: "odiar", label: "Discurso de Odio", polite: "amar con reparo" },
  { word: "odio", label: "Discurso de Odio", polite: "aprecio extremo" },
  { word: "maricon", label: "Hostilidad/Discriminación", polite: "amigo precioso" },
  { word: "maricón", label: "Hostilidad/Discriminación", polite: "amigo precioso" },
  { word: "carajo", label: "Hostilidad/Lenguaje Soez", polite: "caramba" },
  { word: "joder", label: "Falta de Respeto", polite: "por favor" },
  { word: "culon", label: "Falta de Respeto", polite: "atento" },
  { word: "verga", label: "Lenguaje Explícito", polite: "fuerza" },
  { word: "zorra", label: "Insulto Grave", polite: "persona talentosa" },
  { word: "perra", label: "Insulto Grave", polite: "compañera fiel" },

  // English counterparts commonly used
  { word: "fuck", label: "English Vulgarity", polite: "flip" },
  { word: "shit", label: "English Vulgarity", polite: "stuff" },
  { word: "bitch", label: "English Insult", polite: "queen" },
  { word: "asshole", label: "English Slur", polite: "fellow" },
  { word: "idiot", label: "English Insult", polite: "creative mind" },
  { word: "stupid", label: "English Insult", polite: "peculiar" },
  { word: "sucks", label: "English Negativity", polite: "could be optimized" }
];

export function cleanString(str: string): string {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

export function moderateComment(text: string): ModerationResult {
  const lowercaseText = text.toLowerCase();
  const normalizedText = cleanString(text);
  const violations: string[] = [];
  let score = 0;
  let moderatedText = text;
  let suggestedPoliteText = text;

  // 1. Analyze for toxic keywords and compute dynamic confidence score
  const matches: typeof TOXIC_PATTERNS = [];
  
  TOXIC_PATTERNS.forEach(pattern => {
    const cleanPatternWord = cleanString(pattern.word);
    
    // Check if the normalized clean bad word appears anywhere in the clean user input
    if (normalizedText.includes(cleanPatternWord)) {
      matches.push(pattern);
      if (!violations.includes(pattern.label)) {
        violations.push(pattern.label);
      }
    }
  });

  if (matches.length > 0) {
    // Compound score: base 35% + 20% for each additional match, up to 99%
    score = Math.min(30 + matches.length * 20, 99);
    
    // Apply local "Positive Grammar" transformer to build suggested polite wording
    let politeDraft = text;
    matches.forEach(match => {
      // Create a case-and-accent insensitive substitution
      const cleanWord = cleanString(match.word);
      politeDraft = politeDraft.split(" ").map(w => {
        if (cleanString(w).includes(cleanWord)) {
          return `[${match.polite} 🌸]`;
        }
        return w;
      }).join(" ");

      moderatedText = moderatedText.split(" ").map(w => {
        if (cleanString(w).includes(cleanWord)) {
          return "*".repeat(w.length);
        }
        return w;
      }).join(" ");
    });
    suggestedPoliteText = politeDraft;
  } else {
    // Sentiment heuristics based on exclamation and length caps
    const noiseLevel = (text.match(/!/g) || []).length;
    const capsCount = (text.match(/[A-Z]/g) || []).length;
    const totalChars = text.length || 1;
    const capsRatio = capsCount / totalChars;

    if (capsRatio > 0.6 && totalChars > 8) {
      score = 25;
      violations.push("Agitación Verbal (Exceso de Mayúsculas)");
      suggestedPoliteText = text.toLowerCase() + " 😊";
    } else if (noiseLevel > 4) {
      score = 15;
      violations.push("Entusiasmo Excesivo/Posible Spam");
    } else {
      score = 0;
    }
  }

  // Threshold to block/notify is 30%
  const isToxic = score >= 30;

  return {
    isToxic,
    score,
    originalText: text,
    moderatedText,
    violations,
    suggestedPoliteText
  };
}
