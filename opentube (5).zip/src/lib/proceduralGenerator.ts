import { Video, Comment } from '../types';

const THUMBNAIL_PICS = [
  "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&auto=format&fit=crop&q=85", // Developer
  "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=600&auto=format&fit=crop&q=85", // LoFi girl
  "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=85", // Anime Setup
  "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600&auto=format&fit=crop&q=85", // Gaming
  "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&auto=format&fit=crop&q=85", // Universe Space
  "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=600&auto=format&fit=crop&q=85", // Matrix Code
  "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&auto=format&fit=crop&q=85", // Cybertech
  "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600&auto=format&fit=crop&q=85", // Web design mockup
  "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=85"  // AI Art
];

const LIGHT_VIDEO_PRESETS = [
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"
];

const AUTORS = [
  { name: "Sistemas Inteligentes AI", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100" },
  { name: "ByteMaster Premium", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100" },
  { name: "Aria Lofi & Chill", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100" },
  { name: "CodeCraft Academy", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100" },
  { name: "Planeta Documentales", avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100" }
];

const SAMPLE_TITLES = [
  "Curso Completo de React con Inteligencia Artificial - 2026",
  "Sesión de Lo-Fi Beats Para Programar sin Estrés 🧠💻 [Pista Dual]",
  "Diseño Web en CSS Grid 3D de Forma Fácil y Fluida",
  "Unboxing del Nuevo Monitor Holográfico de Última Generación",
  "Un Recorrido Visual por la Nebulosa de Orión en 8K Ultra-Fidelity",
  "Secretos Ocultos que los Desarrolladores Senior No Te Cuentan",
  "Cómo Integrar Modelos de Lenguaje Local On-Device en Tu Web",
  "Construyendo un Clon de YouTube desde Cero con Rendimiento Óptimo",
  "Mitos y Verdades sobre la Singularidad Tecnológica de la IA",
  "Iniciando en Kubernetes: De Cero a Producción en 15 Minutos"
];

const CATEGORIES_BY_INDEX = [
  "Desarrollo Web",
  "Música & Lo-Fi",
  "Desarrollo Web",
  "Tecnología de Punta",
  "Entretenimiento",
  "Tecnología de Punta",
  "Desarrollo Web",
  "Desarrollo Web",
  "Tecnología de Punta",
  "Tecnología de Punta"
];

export function generateProceduralVideo(idIndex: number): Video {
  const title = SAMPLE_TITLES[idIndex % SAMPLE_TITLES.length];
  const category = CATEGORIES_BY_INDEX[idIndex % CATEGORIES_BY_INDEX.length];
  const videoUrl = LIGHT_VIDEO_PRESETS[idIndex % LIGHT_VIDEO_PRESETS.length];
  const thumbnailUrl = THUMBNAIL_PICS[idIndex % THUMBNAIL_PICS.length];
  const author = AUTORS[idIndex % AUTORS.length];
  
  const views = Math.floor(1200 + Math.random() * 850000);
  const likes = Math.floor(views * (0.05 + Math.random() * 0.08));
  const dislikes = Math.floor(likes * (0.01 + Math.random() * 0.02));
  
  const comments: Comment[] = [
    {
      id: `pc-${idIndex}-c1`,
      author: "Pedro Tech",
      avatarUrl: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=100",
      text: "¡Excelente video tutorial! El ritmo de explicación es genial.",
      timestamp: "Hace 23 minutos",
      likes: 15,
      dislikes: 0
    },
    {
      id: `pc-${idIndex}-c2`,
      author: "Laura Sanz",
      avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
      text: "Me encanta el fondo sonoro. Súper limpio y pro.",
      timestamp: "Hace 2 horas",
      likes: 42,
      dislikes: 1
    }
  ];

  return {
    id: `procedural-v-${idIndex}-${Date.now()}`,
    title,
    description: `Este es un video generado procedimentalmente por el motor inteligente de recomendación local OpenTube. Basado en tus intereses de búsqueda, diseñado para cargar de manera inmediata a través de codecs optimizados.\n\nCategoría: ${category} • Origen de streaming: Cloud Edge.`,
    videoUrl,
    thumbnailUrl,
    duration: 15 + (idIndex * 5) % 45, // 15 to 60s
    views,
    uploadDate: `Hace ${idIndex + 1} días`,
    likes,
    dislikes,
    category,
    isShort: false,
    authorName: author.name,
    authorAvatar: author.avatar,
    isVerifiedAuthor: Math.random() > 0.4,
    comments
  };
}

export function generateProceduralShort(idIndex: number): Video {
  const author = AUTORS[idIndex % AUTORS.length];
  const videoUrl = LIGHT_VIDEO_PRESETS[idIndex % LIGHT_VIDEO_PRESETS.length];
  const thumbnailUrl = THUMBNAIL_PICS[idIndex % THUMBNAIL_PICS.length];
  const views = Math.floor(5000 + Math.random() * 120000);
  const likes = Math.floor(views * (0.1 + Math.random() * 0.15));
  
  return {
    id: `procedural-s-${idIndex}-${Date.now()}`,
    title: `Micro truco de código #${idIndex + 1} en 30 segundos! 💻🚀 #shorts`,
    description: `Aprende este tip rápido para mejorar la usabilidad de tus aplicaciones de desarrollo frontend reactivo. #shorts #developer #ai`,
    videoUrl,
    thumbnailUrl,
    duration: 15,
    views,
    uploadDate: "Hace unas horas",
    likes,
    dislikes: Math.floor(likes * 0.01),
    category: "Shorts",
    isShort: true,
    authorName: author.name,
    authorAvatar: author.avatar,
    isVerifiedAuthor: true,
    comments: [
      {
        id: `psc-${idIndex}-c1`,
        author: "DevJunior",
        avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
        text: "¡No conocía este atajo de hooks! Definitivamente lo voy a aplicar en producción.",
        timestamp: "Hace 5 minutos",
        likes: 2,
        dislikes: 0
      }
    ]
  };
}
