import React from 'react';
import { Home, Clock, Sparkles, MessageSquare, UserCheck, AlertTriangle } from 'lucide-react';
import { Language, TRANSLATIONS } from '../lib/translations';

interface SidebarProps {
  activeTab: 'home' | 'history' | 'shorts' | 'community' | 'profile';
  setActiveTab: (tab: 'home' | 'history' | 'shorts' | 'community' | 'profile') => void;
  subscribersCount: number;
  lang: Language;
}

export default function Sidebar({ activeTab, setActiveTab, subscribersCount, lang }: SidebarProps) {
  const links = [
    { id: 'home', label: TRANSLATIONS[lang].home, icon: Home, color: 'text-red-500' },
    { id: 'history', label: TRANSLATIONS[lang].history, icon: Clock, color: 'text-amber-500' },
    { id: 'shorts', label: TRANSLATIONS[lang].shorts, icon: Sparkles, color: 'text-amber-500' },
    { id: 'community', label: TRANSLATIONS[lang].community, icon: MessageSquare, color: 'text-indigo-400' },
    { id: 'profile', label: TRANSLATIONS[lang].profile, icon: UserCheck, color: 'text-blue-400' }
  ] as const;

  return (
    <aside className="w-full md:w-56 bg-neutral-900 md:border-r border-neutral-800/80 p-3 md:flex md:flex-col justify-between shrink-0 gap-4">
      
      <div className="flex flex-col gap-3">
        {/* Compliance Legal Disclaimer Notice (Moved to the very top!) */}
        <div className="bg-red-950/20 border border-red-500/20 rounded-xl p-3 text-[10px] leading-relaxed text-red-200">
          <div className="flex items-center gap-1.5 mb-1 text-red-400 font-bold uppercase tracking-wider">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{lang === 'es' ? 'Aviso Importante' : 'Important Notice'}</span>
          </div>
          <p>
            {lang === 'es' 
              ? 'Oigan, yo solo pongo la plataforma, si algún usuario sube algo suyo sin permiso, mándenme un correo y yo lo borro rápido. Email:' 
              : 'Hey, I just host the platform, if any user uploads your content without permission, send me an email and I will delete it quickly. Email:'}
            {' '}
            <a href="mailto:OpenTubeofficial@proton.me" className="underline font-bold text-red-400 hover:text-red-300">OpenTubeofficial@proton.me</a>
          </p>
        </div>

        {/* Top category loops */}
        <div className="flex md:flex-col justify-around md:justify-start gap-1 w-full overflow-x-auto md:overflow-x-visible pb-1 md:pb-0 scrollbar-none">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`flex items-center gap-2.5 py-1.5 px-3 md:py-3 md:px-4 rounded-xl text-xs md:text-sm font-semibold tracking-wide transition-all focus:outline-none shrink-0 md:w-full cursor-pointer ${
                  isActive
                    ? 'bg-neutral-800/90 text-white border-b-2 md:border-b-0 md:border-l-4 border-red-500 shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-800/30'
                }`}
              >
                <Icon className={`w-4 h-4 md:w-4.5 md:h-4.5 ${isActive ? link.color : 'text-neutral-400'}`} />
                <span className="truncate">{link.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex flex-col gap-3">
        {/* Decorative Bottom Side Status card (only on medium screen or larger) */}
        <div className="hidden md:flex flex-col gap-3 bg-neutral-950 p-4 rounded-xl border border-neutral-800/80">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-650 animate-pulse" />
            <span className="text-[10px] font-bold text-neutral-400 font-sans tracking-wide uppercase">
              {lang === 'es' ? 'ESTADO' : 'STATUS'}
            </span>
          </div>
          
          <div>
            <span className="text-[10px] text-neutral-500 block">
              {lang === 'es' ? 'Suscriptores:' : 'Subscribers:'}
            </span>
            <span className="text-sm font-mono text-white font-bold">
              {subscribersCount.toLocaleString(lang === 'es' ? 'es-ES' : 'en-US')}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-neutral-500 block">
              {lang === 'es' ? 'Licencia:' : 'License:'}
            </span>
            <span className="text-[10px] font-semibold text-sky-400 bg-sky-950/40 border border-sky-800/30 px-1.5 py-0.5 rounded inline-block mt-0.5">
              {lang === 'es' ? 'Partner Verificado 🛡️' : 'Verified Partner 🛡️'}
            </span>
          </div>
        </div>
      </div>

    </aside>
  );
}
