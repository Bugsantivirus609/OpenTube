import React, { useState, useRef } from 'react';
import { BadgeCheck, Upload, Award, Users, Save, TrendingUp, TrendingDown, Image, RefreshCw, Sparkles, Trophy, Radio, Shield, Palette } from 'lucide-react';
import { UserProfile, Video } from '../types';
import VerifiedBadge from './VerifiedBadge';

interface ProfileSettingsProps {
  currentUser: UserProfile;
  onUpdateUser: (updated: UserProfile) => void;
  videos: Video[];
  playbackProgress: Record<string, { currentTime: number; duration: number; timestamp: number }>;
  onSelectVideo: (video: Video) => void;
  onAdminCommand: (command: string, args: string[]) => void;
}

export default function ProfileSettings({ 
  currentUser, 
  onUpdateUser,
  videos,
  playbackProgress,
  onSelectVideo,
  onAdminCommand
}: ProfileSettingsProps) {
  const [name, setName] = useState(currentUser.name);
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl);
  const [subsCount, setSubsCount] = useState(currentUser.subscribers);
  const [tickerSpeed, setTickerSpeed] = useState<number>(0); // 0 = stopped, 1 = slow, 2 = fast
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [saveStatus, setSaveStatus] = useState<string | null>(null);

  // Social Channels Media handles
  const [socialInstagram, setSocialInstagram] = useState(currentUser.socialInstagram || '');
  const [socialTwitter, setSocialTwitter] = useState(currentUser.socialTwitter || '');
  const [socialYoutube, setSocialYoutube] = useState(currentUser.socialYoutube || '');
  const [socialGithub, setSocialGithub] = useState(currentUser.socialGithub || '');

  // VIP Customizations
  const [vipEmblem, setVipEmblem] = useState<'classic' | 'crown' | 'star' | 'shield'>(currentUser.vipEmblem || 'classic');
  const [vipNeonTheme, setVipNeonTheme] = useState<boolean>(currentUser.vipNeonTheme || false);
  const [vipAnnouncement, setVipAnnouncement] = useState<string>(currentUser.vipAnnouncement || '');

  // Retro Admin Console terminal states
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalLogs, setTerminalLogs] = useState<string[]>(["Consola segura inicializada con privilegios de root. Listo para comandos."]);

  // Sync state values when currentUser changes (fixing the stale configuration menu bug)
  React.useEffect(() => {
    setName(currentUser.name);
    setAvatarUrl(currentUser.avatarUrl);
    setSubsCount(currentUser.subscribers);
    setSocialInstagram(currentUser.socialInstagram || '');
    setSocialTwitter(currentUser.socialTwitter || '');
    setSocialYoutube(currentUser.socialYoutube || '');
    setSocialGithub(currentUser.socialGithub || '');
    setVipEmblem(currentUser.vipEmblem || 'classic');
    setVipNeonTheme(currentUser.vipNeonTheme || false);
    setVipAnnouncement(currentUser.vipAnnouncement || '');
  }, [currentUser]);

  const handleExecuteCommand = () => {
    const input = terminalInput.trim();
    if (!input) return;

    setTerminalLogs(prev => [...prev, `Ejecutando en núcleo: ${input}`]);
    const parts = input.split(' ');
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1);

    if (cmd === '/addsubs') {
      const amount = parseInt(args[0], 10);
      if (isNaN(amount)) {
        setTerminalLogs(prev => [...prev, "❌ Error: Especifica una cantidad numérica válida. Ej: /addsubs 250000"]);
      } else {
        const nextSubs = Math.max(0, subsCount + amount);
        setSubsCount(nextSubs);
        onUpdateUser({ ...currentUser, subscribers: nextSubs });
        setTerminalLogs(prev => [...prev, `▶ Éxito: Añadidos ${amount} suscriptores. Nuevo total: ${nextSubs}`]);
      }
    } else if (cmd === '/eliminatesubs') {
      const amount = parseInt(args[0], 10);
      if (isNaN(amount)) {
        setTerminalLogs(prev => [...prev, "❌ Error: Especifica una cantidad numérica válida. Ej: /eliminatesubs 10000"]);
      } else {
        const nextSubs = Math.max(0, subsCount - amount);
        setSubsCount(nextSubs);
        onUpdateUser({ ...currentUser, subscribers: nextSubs });
        setTerminalLogs(prev => [...prev, `▶ Éxito: Eliminados ${amount} suscriptores de tu canal. Nuevo total: ${nextSubs}`]);
      }
    } else if (cmd === '/randomgift') {
      onAdminCommand('/randomgift', args);
      setTerminalLogs(prev => [...prev, "▶ Éxito: Regalados suscriptores a un creador aleatorio y generada advertencia aleatoria instructiva."]);
    } else {
      // Pass other commands system-wide
      onAdminCommand(cmd, args);
      
      if (cmd === '/boostviews') {
        setTerminalLogs(prev => [...prev, "▶ Éxito: Visitas multiplicadas en +1,000,000 para todos los videos locales."]);
      } else if (cmd === '/verifyall') {
        setTerminalLogs(prev => [...prev, "▶ Éxito: Insignias de verificación VIP de diamante distribuidas globalmente."]);
      } else if (cmd === '/addtestshort') {
        setTerminalLogs(prev => [...prev, "▶ Éxito: Short de prueba de videojuegos Full HD 4K inyectado exitosamente."]);
      } else if (cmd === '/cleanothers') {
        setTerminalLogs(prev => [...prev, "▶ Éxito: Borrados todos los videos que no pertenecen a tu autoría."]);
      } else {
        setTerminalLogs(prev => [...prev, `❌ Error: Comando desconocido o no válido: ${cmd}`]);
      }
    }

    setTerminalInput('');
  };

  // We keep the latest values in a Ref so that the interval does not capture stale closures and operates safely out of render cycle
  const stateRef = useRef({ subsCount, currentUser, vipEmblem, vipNeonTheme, vipAnnouncement });
  React.useEffect(() => {
    stateRef.current = { subsCount, currentUser, vipEmblem, vipNeonTheme, vipAnnouncement };
  });

  // Auto incremental ticker
  React.useEffect(() => {
    if (tickerSpeed === 0) return;
    const interval = setInterval(() => {
      const increment = tickerSpeed === 1 ? Math.floor(Math.random() * 3) + 1 : Math.floor(Math.random() * 85) + 15;
      const nextSubs = stateRef.current.subsCount + increment;
      
      setSubsCount(nextSubs);
      onUpdateUser({
        ...stateRef.current.currentUser,
        subscribers: nextSubs,
        vipEmblem: stateRef.current.vipEmblem,
        vipNeonTheme: stateRef.current.vipNeonTheme,
        vipAnnouncement: stateRef.current.vipAnnouncement
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [tickerSpeed, onUpdateUser]);

  // Handle image upload from user local computer
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          const img = new window.Image();
          img.onload = () => {
            const canvas = document.createElement('canvas');
            const size = 120; // Perfect, sharp dimensions for circle avatars
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              const minDim = Math.min(img.width, img.height);
              const sx = (img.width - minDim) / 2;
              const sy = (img.height - minDim) / 2;
              ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, size, size);
              const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7); // Tiny footprint (~5-8KB)
              setAvatarUrl(compressedBase64);
            } else {
              setAvatarUrl(reader.result as string);
            }
          };
          img.src = reader.result;
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleManualSubChange = (amount: number) => {
    const nextSubs = Math.max(0, subsCount + amount);
    setSubsCount(nextSubs);
    onUpdateUser({
      ...currentUser,
      subscribers: nextSubs,
      vipEmblem,
      vipNeonTheme,
      vipAnnouncement
    });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      name: name.trim() || currentUser.name,
      avatarUrl: avatarUrl,
      subscribers: subsCount,
      vipEmblem,
      vipNeonTheme,
      vipAnnouncement: vipAnnouncement.trim(),
      socialInstagram: socialInstagram.trim(),
      socialTwitter: socialTwitter.trim(),
      socialYoutube: socialYoutube.trim(),
      socialGithub: socialGithub.trim()
    });
    setSaveStatus("¡Información del canal guardada!");
    setTimeout(() => {
      setSaveStatus(null);
    }, 2000);
  };

  return (
    <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6 shadow-xl max-w-4xl mx-auto flex flex-col gap-6">
      
      {/* Upper banner design */}
      <div className="relative h-28 rounded-xl overflow-hidden bg-gradient-to-r from-red-800/80 via-purple-900/60 to-zinc-900 flex items-center px-6">
        <div className="absolute inset-0 bg-black/10 backdrop-blur-[1px]" />
        <div className="relative z-10 flex items-center gap-3">
          <div className="p-2.5 rounded-full bg-black/40 border border-white/10 text-rose-500">
            <Award className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-white text-xl font-bold tracking-tight font-sans flex items-center gap-2">
              Panel del Creador Verificado
              <span className="inline-flex items-center gap-1.5">
                <VerifiedBadge type={vipEmblem} size="lg" />
                {vipEmblem === 'star' && (
                  <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-widest bg-gradient-to-r from-red-500 via-amber-500 to-amber-300 text-neutral-950 rounded-full shadow-md animate-pulse">
                    creator
                  </span>
                )}
              </span>
            </h2>
            <p className="text-neutral-300 text-xs">Administra la configuración pública de tu canal de OpenTube</p>
            {/* Render Public Social Badges */}
            <div className="flex flex-wrap gap-2 mt-2">
              {currentUser.socialInstagram && (
                <span className="text-[10px] text-pink-400 bg-black/40 border border-pink-500/15 py-0.5 px-2 rounded-full flex items-center gap-1 font-mono">
                  <span>📷 Instagram:</span> {currentUser.socialInstagram}
                </span>
              )}
              {currentUser.socialTwitter && (
                <span className="text-[10px] text-sky-400 bg-black/40 border border-sky-400/15 py-0.5 px-2 rounded-full flex items-center gap-1 font-mono">
                  <span>🐦 Twitter:</span> {currentUser.socialTwitter}
                </span>
              )}
              {currentUser.socialYoutube && (
                <span className="text-[10px] text-red-400 bg-black/40 border border-red-500/15 py-0.5 px-2 rounded-full flex items-center gap-1 font-mono">
                  <span>▶ YouTube:</span> {currentUser.socialYoutube}
                </span>
              )}
              {currentUser.socialGithub && (
                <span className="text-[10px] text-zinc-300 bg-black/40 border border-white/10 py-0.5 px-2 rounded-full flex items-center gap-1 font-mono">
                  <span>💻 GitHub:</span> {currentUser.socialGithub}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Left side: Avatar and Name fields */}
        <form onSubmit={handleSave} className="flex flex-col gap-5">
          <h3 className="text-white text-base font-semibold border-b border-neutral-800 pb-2">
            Editar Detalles de Canal
          </h3>

          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="relative group">
              <img
                src={avatarUrl}
                alt="Canal Avatar"
                className="w-20 h-20 rounded-full border-2 border-red-500 object-cover shadow-md"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 rounded-full bg-black/60 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Upload className="w-4 h-4 text-white" />
                <span className="text-[9px] text-white font-mono mt-0.5">SUBIR</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*.png,image/*.jpg,image/*.jpeg"
                onChange={handleImageFileChange}
                className="hidden"
              />
            </div>

            <div className="flex-1 w-full flex flex-col gap-1">
              <span className="text-[10px] text-neutral-400 font-semibold uppercase tracking-wider">Avatar del Canal (.PNG / .JPG)</span>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-lg self-start transition-colors"
              >
                <Image className="w-3.5 h-3.5 text-neutral-400" />
                Seleccionar Archivo Local
              </button>
            </div>
          </div>

          <div>
            <label className="text-xs text-neutral-400 font-semibold uppercase tracking-wider block mb-1">Nombre del Canal</label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-neutral-950 text-white placeholder-neutral-600 text-sm rounded-xl px-4 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors pr-10"
                placeholder="Nombre del canal..."
              />
              {/* Badge visual indicator */}
              <div className="absolute right-3.5 top-3">
                <VerifiedBadge type={vipEmblem} size="lg" />
              </div>
            </div>
            <span className="text-[10px] text-neutral-500 mt-1 block">
              ⭐ Sólo tú posees la verificación oficial VIP de la plataforma. Nadie más puede duplicar esta patente.
            </span>
          </div>

          <div>
            <label className="text-xs text-neutral-400 font-semibold uppercase tracking-wider block mb-1">Cambiar Foto por URL directa (Alternativa)</label>
            <input
              type="text"
              value={avatarUrl}
              onChange={(e) => setAvatarUrl(e.target.value)}
              className="w-full bg-neutral-950 text-white text-xs rounded-xl px-4 py-2 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors font-mono"
              placeholder="https://images.unsplash.com/photo-..."
            />
          </div>

          {/* Social Networks Form Input Box */}
          <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 flex flex-col gap-3">
            <span className="text-[10px] text-red-500 font-bold tracking-wider uppercase block mb-1">Redes Sociales de tu Perfil 🌐</span>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[10px] text-neutral-400 font-semibold uppercase block mb-1">Instagram</label>
                <input
                  type="text"
                  value={socialInstagram}
                  onChange={(e) => setSocialInstagram(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-red-500 text-white font-mono text-[11px]"
                  placeholder="@usuario"
                />
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 font-semibold uppercase block mb-1">Twitter / X</label>
                <input
                  type="text"
                  value={socialTwitter}
                  onChange={(e) => setSocialTwitter(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-red-500 text-white font-mono text-[11px]"
                  placeholder="@usuario"
                />
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 font-semibold uppercase block mb-1">YouTube</label>
                <input
                  type="text"
                  value={socialYoutube}
                  onChange={(e) => setSocialYoutube(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-red-500 text-white font-mono text-[11px]"
                  placeholder="https://youtube.com/..."
                />
              </div>
              <div>
                <label className="text-[10px] text-neutral-400 font-semibold uppercase block mb-1">GitHub</label>
                <input
                  type="text"
                  value={socialGithub}
                  onChange={(e) => setSocialGithub(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-red-500 text-white font-mono text-[11px]"
                  placeholder="github.com/usuario"
                />
              </div>
            </div>
          </div>

          {saveStatus && (
            <div className="bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 text-xs px-3 py-2 rounded-xl text-center">
              {saveStatus}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5"
          >
            <Save className="w-4 h-4" />
            Guardar Cambios del Perfil
          </button>
        </form>

        {/* Right side: SUBSCRIBER SIMULATOR */}
        <div className="bg-neutral-950 rounded-2xl p-5 border border-neutral-800 flex flex-col justify-between">
          <div>
            <h3 className="text-white text-base font-semibold border-b border-neutral-800 pb-2 flex items-center gap-2">
              <Users className="w-4.5 h-4.5 text-red-500" />
              Simulador de Suscriptores
            </h3>

            {/* Display panel */}
            <div className="my-5 bg-neutral-900 border border-neutral-800/80 rounded-xl p-4 text-center">
              <span className="text-xs text-zinc-400 uppercase font-bold tracking-widest block mb-1">SUSCRIPTORES TOTALES</span>
              <span className="text-2xl sm:text-3xl font-mono text-white font-bold tracking-tight">
                {subsCount.toLocaleString('es-ES')}
              </span>
              <div className="flex justify-center gap-1.5 mt-2">
                {subsCount >= 100000 && (
                  <span className="bg-stone-800 border border-stone-600 text-[10px] uppercase font-bold font-mono text-zinc-200 px-2 py-0.5 rounded shadow">
                    Placa de Plata
                  </span>
                )}
                {subsCount >= 1000000 && (
                  <span className="bg-amber-800 border border-amber-600 text-[10px] uppercase font-bold font-mono text-amber-200 px-2 py-0.5 rounded shadow">
                    Placa de Oro
                  </span>
                )}
              </div>
            </div>

            {/* Manual modifiers */}
            {(() => {
              const isGamer = currentUser.name.toLowerCase().includes('gamer') || currentUser.name === 'GamerCool';
              return isGamer ? (
                <>
                  <div className="flex flex-col gap-2">
                    <span className="text-[11px] text-neutral-400 uppercase font-semibold tracking-wider">Ajustes Manuales</span>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleManualSubChange(1000)}
                        className="flex items-center justify-center gap-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold py-2 transition-colors leading-none"
                      >
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                        +1,000 Subs
                      </button>
                      <button
                        type="button"
                        onClick={() => handleManualSubChange(-1500)}
                        className="flex items-center justify-center gap-1.5 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold py-2 transition-colors leading-none"
                      >
                        <TrendingDown className="w-3.5 h-3.5 text-rose-400" />
                        -1,500 Subs
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-0.5">
                      <button
                        type="button"
                        onClick={() => handleManualSubChange(55200)}
                        className="flex items-center justify-center gap-1.5 bg-red-950/50 hover:bg-red-900/40 text-rose-300 rounded-lg text-xs leading-none font-semibold py-2 transition-colors border border-red-500/20"
                      >
                        <TrendingUp className="w-3.5 h-3.5 text-red-400 animate-bounce" />
                        +55.2K Éxito Viral
                      </button>
                      <button
                        type="button"
                        onClick={() => setSubsCount(0)}
                        className="bg-neutral-900 hover:bg-neutral-800 text-neutral-400 hover:text-white rounded-lg text-[10px] font-mono tracking-wider py-2 transition-all leading-none"
                      >
                        Resetear a 0
                      </button>
                    </div>
                  </div>

                  {/* Auto simulation ticker */}
                  <div className="mt-4 pt-4 border-t border-neutral-800">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-[11px] text-neutral-400 uppercase font-semibold tracking-wider">Simulación en Tiempo Real</span>
                      {tickerSpeed > 0 && (
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setTickerSpeed(0)}
                        className={`text-[10px] font-semibold py-1.5 rounded transition-all ${
                          tickerSpeed === 0 ? 'bg-red-600 text-white' : 'bg-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        Pausado
                      </button>
                      <button
                        type="button"
                        onClick={() => setTickerSpeed(1)}
                        className={`text-[10px] font-semibold py-1.5 rounded transition-all ${
                          tickerSpeed === 1 ? 'bg-emerald-600 text-white' : 'bg-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        Lento (+1-3s)
                      </button>
                      <button
                        type="button"
                        onClick={() => setTickerSpeed(2)}
                        className={`text-[10px] font-semibold py-1.5 rounded transition-all ${
                          tickerSpeed === 2 ? 'bg-indigo-600 text-white' : 'bg-neutral-800 text-neutral-400 hover:text-white'
                        }`}
                      >
                        Viral (+15-100s)
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="bg-neutral-900 border border-neutral-900 p-4 rounded-xl text-center flex flex-col items-center justify-center gap-1.5 pt-6 pb-6 shadow-inner">
                  <Shield className="w-8 h-8 text-red-500 animate-pulse mb-1" />
                  <span className="text-white text-xs font-bold font-mono uppercase tracking-wider">CONTROLES BLOQUEADOS</span>
                  <span className="text-neutral-400 text-[10.5px] font-sans leading-normal max-w-xs block">
                    La simulación/atallos de suscriptores con botones está restringida de uso exclusivo para el diseñador GamerCool. No se permiten imitadores.
                  </span>
                </div>
              );
            })()}
          </div>

          <div className="mt-4 pt-3 border-t border-neutral-900 text-center">
            <span className="text-[10px] text-neutral-500 block">
              ⚙️ Los cambios se aplicarán instantáneamente como autor en todos los videos que publiques y comentarios que dejes.
            </span>
          </div>
        </div>

      </div>

      {/* EXCLUSIVE GOLDEN VIP COMMAND CENTER */}
      <div className="border-t border-neutral-800 pt-6 mt-2 flex flex-col gap-5">
        <div className="bg-gradient-to-r from-amber-500/10 via-rose-500/5 to-neutral-950 border border-amber-500/30 rounded-2xl p-6 shadow-lg shadow-amber-950/10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl pointer-events-none group-hover:scale-125 transition-transform duration-700" />
          
          <div className="flex items-center gap-3 mb-1">
            <div className="p-2 rounded-xl bg-gradient-to-br from-amber-500 to-rose-600 text-neutral-950">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-amber-400 text-lg font-black tracking-tight flex items-center gap-2">
                👑 Panel de Control VIP (Exclusivo GamerCool)
              </h3>
              <p className="text-neutral-300 text-xs font-sans">
                Como único canónicamente verificado de la plataforma, posees privilegios especiales para moldear visualmente OpenTube. No se permiten imitadores.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            {/* 1. EMBLEM CUSTOMIZER */}
            <div className="bg-neutral-905/60 p-4 rounded-xl border border-neutral-800 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-amber-400 font-bold tracking-widest uppercase block mb-1 font-mono">VIP OPTION 1</span>
                <h4 className="text-white text-sm font-bold mb-3 flex items-center gap-1.5">
                  <Trophy className="w-4 h-4 text-amber-400 animate-bounce" />
                  Insignia VIP Personalizada
                </h4>
                <p className="text-neutral-400 text-xs mb-4 font-sans leading-relaxed">
                  Cambia la identidad visual de tu insignia de verificación verificada oficial para todos tus comentarios, posts y videos.
                </p>

                <div className="grid grid-cols-1 gap-2.5 font-mono text-[11px]">
                  <button
                    type="button"
                    onClick={() => {
                      setVipEmblem('classic');
                      onUpdateUser({ ...currentUser, vipEmblem: 'classic' });
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 justify-center transition-all cursor-pointer ${
                      vipEmblem === 'classic'
                        ? 'bg-blue-950/60 border-blue-500 text-blue-300 shadow-md shadow-blue-500/20'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <VerifiedBadge type="classic" size="sm" />
                    <span>Blue Check Oficial</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setVipEmblem('star');
                      onUpdateUser({ ...currentUser, vipEmblem: 'star' });
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col sm:flex-row items-center gap-1.5 justify-center transition-all cursor-pointer ${
                      vipEmblem === 'star'
                        ? 'bg-amber-950/60 border-amber-500 text-amber-300 shadow-md shadow-amber-500/20'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <VerifiedBadge type="star" size="sm" />
                      <span>Estrella ✦</span>
                    </div>
                    <span className="px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wider bg-gradient-to-r from-red-500 to-amber-500 text-neutral-950 rounded shadow-sm">
                      creator
                    </span>
                  </button>
                </div>
              </div>
            </div>

            {/* 2. THEME NEON GLOW DECOR */}
            <div className="bg-neutral-905/60 p-4 rounded-xl border border-neutral-800 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-amber-400 font-bold tracking-widest uppercase block mb-1 font-mono">VIP OPTION 2</span>
                <h4 className="text-white text-sm font-bold mb-3 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-rose-500 animate-pulse" />
                  Efecto Brillo Neón VIP
                </h4>
                <p className="text-neutral-400 text-xs mb-4 font-sans leading-relaxed">
                  Activa un aura premium fluorescente en tus videos subidos. Se verán rodeados por un resplandor dinámico de colores.
                </p>

                <button
                  type="button"
                  onClick={() => {
                    const nextTheme = !vipNeonTheme;
                    setVipNeonTheme(nextTheme);
                    onUpdateUser({ ...currentUser, vipNeonTheme: nextTheme });
                  }}
                  className={`w-full py-2.5 rounded-lg border text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 group ${
                    vipNeonTheme
                      ? 'bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 border-rose-400 text-white animate-pulse'
                      : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-white group-hover:scale-110 transition-transform" />
                  <span>{vipNeonTheme ? '¡Efecto VIP Activado!' : 'Activar Brillo Neón VIP'}</span>
                </button>
              </div>
            </div>

            {/* 3. BROADCAST MARQUEE BANNER ANNOUNCER */}
            <div className="bg-neutral-905/60 p-4 rounded-xl border border-neutral-800 flex flex-col justify-between">
              <div>
                <span className="text-[10px] text-amber-400 font-bold tracking-widest uppercase block mb-1 font-mono">VIP OPTION 3</span>
                <h4 className="text-white text-sm font-bold mb-2 flex items-center gap-1.5">
                  <Radio className="w-4 h-4 text-blue-400 animate-pulse" />
                  Alerta Marquee Global
                </h4>
                <p className="text-neutral-400 text-xs mb-3 font-sans leading-relaxed">
                  Genera una marquesina de alerta flotante con colores de advertencia que estará activa en forma sincronizada en la parte superior.
                </p>

                <div className="flex flex-col gap-2">
                  <input
                    type="text"
                    value={vipAnnouncement}
                    onChange={(e) => {
                      const text = e.target.value;
                      setVipAnnouncement(text);
                      onUpdateUser({ ...currentUser, vipAnnouncement: text });
                    }}
                    placeholder="Escribe un anuncio importante..."
                    className="w-full bg-neutral-950 text-white placeholder-neutral-600 rounded-lg py-2 px-3 text-xs border border-neutral-800 focus:outline-none focus:border-amber-400 font-sans"
                  />
                  {vipAnnouncement && (
                    <button
                      type="button"
                      onClick={() => {
                        setVipAnnouncement('');
                        onUpdateUser({ ...currentUser, vipAnnouncement: '' });
                      }}
                      className="text-[10px] text-rose-400 hover:text-rose-500 font-medium self-end underline"
                    >
                      Remover Alerta
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* SECCIÓN HISTORIAL DE REPRODUCCIÓN (PLAY BACK HISTORY) */}
      <div className="border-t border-neutral-800 pt-6 mt-2 flex flex-col gap-4">
        <h3 className="text-white text-base font-semibold flex items-center gap-2">
          🕒 Mi Historial de Reproducción ({(() => {
            const historialVideos = Object.entries(playbackProgress || {})
              .map(([videoId, prog]) => {
                const match = videos.find(v => v.id === videoId);
                return { video: match, progress: prog };
              })
              .filter(pair => pair.video !== undefined);
            return historialVideos.length;
          })()})
        </h3>
        {(() => {
          const historialVideos = Object.entries(playbackProgress || {})
            .map(([videoId, prog]) => {
              const match = videos.find(v => v.id === videoId);
              return { video: match, progress: prog };
            })
            .filter(pair => pair.video !== undefined)
            .sort((a, b) => b.progress.timestamp - a.progress.timestamp) as { video: Video; progress: { currentTime: number; duration: number; timestamp: number } }[];

          if (historialVideos.length === 0) {
            return (
              <div className="bg-neutral-950/60 rounded-xl p-6 border border-neutral-850 text-center text-neutral-500 text-xs font-mono uppercase tracking-widest">
                Aún no has visto ningún video en esta sesión. ¡Tu historia aparecerá aquí!
              </div>
            );
          }

          return (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {historialVideos.map(({ video, progress }) => {
                const percent = Math.min(((progress.currentTime || 0) / (progress.duration || 1)) * 100, 100);
                return (
                  <div 
                    key={`historial-${video.id}`}
                    onClick={() => onSelectVideo(video)}
                    className="bg-neutral-950 border border-neutral-850 hover:border-neutral-850 rounded-xl p-3 flex gap-3 cursor-pointer group transition-all"
                  >
                    <div className="relative w-20 aspect-video rounded-lg overflow-hidden bg-black shrink-0">
                      <img src={video.thumbnailUrl} alt={video.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-neutral-900 font-mono">
                        <div className="h-full bg-red-650" style={{ width: `${percent}%` }} />
                      </div>
                    </div>
                    <div className="min-w-0 flex-1 flex flex-col justify-between">
                      <h4 className="text-white text-xs font-bold leading-tight truncate group-hover:text-red-400 transition-colors">
                        {video.title}
                      </h4>
                      <div className="text-[10px] text-neutral-500 mt-1">
                        <p className="truncate text-neutral-400">{video.authorName}</p>
                        <span className="text-rose-500 font-mono text-[9px]">
                          Visto al {Math.round(percent)}%
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })()}
      </div>

      {/* EXCLUSIVE RETRO HACKER TERMINAL COMMAND CENTER */}
      {currentUser.name.toLowerCase().includes('gamer') || currentUser.name === 'GamerCool' ? (
        <div className="border-t border-neutral-800 pt-6 mt-2 flex flex-col gap-4">
          <div className="bg-black rounded-2xl border border-red-500/25 p-5 font-mono shadow-[0_0_30px_rgba(239,68,68,0.06)] relative overflow-hidden flex flex-col gap-3">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-650/5 rounded-full blur-[50px] pointer-events-none" />
            
            <div className="flex items-center justify-between border-b border-neutral-900 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-600 animate-pulse" />
                <span className="w-3 h-3 rounded-full bg-amber-500" />
                <span className="w-3 h-3 rounded-full bg-emerald-500" />
                <span className="text-xs text-red-500 font-bold ml-1.5 font-mono tracking-wider">OPENTUBE_SECURE_ADMIN_v2.6_CORESHELL</span>
              </div>
              <span className="text-[9px] text-neutral-500">CONEXIÓN ROOT CONTROL (SOLO PARA MI)</span>
            </div>

            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Escribe un comando especial de administración y pulsa el botón Ejecutar. Comandos autorizados:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] text-amber-500/80 font-mono">
              <div>
                <li><strong className="text-white">/addsubs [n]</strong> - Añade 'n' suscriptores (p. ej., <code className="text-emerald-400">/addsubs 500000</code>)</li>
                <li><strong className="text-white">/boostviews</strong> - Suma +1M visitas a todos los videos de la app</li>
              </div>
              <div>
                <li><strong className="text-white">/verifyall</strong> - Concede verificado diamante VIP a todos los creadores</li>
                <li><strong className="text-white">/addtestshort</strong> - Genera un Short HD en bucle vertical de videojuegos</li>
                <li><strong className="text-white">/cleanothers</strong> - Elimina videos ajenos (sólo para ti, ¡nadie más!)</li>
              </div>
            </div>

            <div className="flex gap-2.5 mt-2">
              <span className="text-red-500 text-sm py-1 font-black select-none font-mono">#&gt;</span>
              <input
                type="text"
                value={terminalInput}
                onChange={(e) => setTerminalInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleExecuteCommand(); }}
                placeholder="Escribe comando aquí... (Ej: /addsubs 1000000)"
                className="flex-1 bg-neutral-950 text-emerald-400 font-mono text-xs rounded-lg py-1.5 px-3 border border-neutral-850 hover:border-neutral-800 focus:outline-none focus:border-red-500 transition-colors placeholder-neutral-700"
              />
              <button
                onClick={handleExecuteCommand}
                className="px-4 py-1.5 bg-red-650 hover:bg-red-600 text-white font-bold rounded-lg text-xs font-mono transition-all cursor-pointer shadow border border-red-500/10"
              >
                EJECUTAR
              </button>
            </div>

            {terminalLogs.length > 0 && (
              <div className="bg-neutral-950 p-3 rounded-lg border border-neutral-850 h-28 overflow-y-auto font-mono text-[9px] text-zinc-400 mt-1 scrollbar-none">
                {terminalLogs.map((log, idx) => (
                  <div key={idx} className="pb-1">
                    <span className="text-neutral-600 font-bold select-none">[v]</span> {log}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      ) : (
        <p className="text-center text-[10px] text-neutral-600 py-2">🔒 Consola de comandos administrativos restringida. Acceso exclusivo para GamerCool.</p>
      )}

    </div>
  );
}
