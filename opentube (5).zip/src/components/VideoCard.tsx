import React from 'react';
import { ThumbsUp, ThumbsDown, Eye, Calendar, Play, Trash2 } from 'lucide-react';
import { Video, UserProfile } from '../types';
import VerifiedBadge from './VerifiedBadge';

interface VideoCardProps {
  key?: string;
  video: Video;
  currentUser: UserProfile;
  onSelectVideo: (video: Video) => void;
  onVote: (videoId: string, voteType: 'like' | 'dislike') => void;
  playbackProgress?: Record<string, { currentTime: number; duration: number; timestamp: number }>;
  onDeleteVideo?: (videoId: string, e: React.MouseEvent) => void;
  onSelectHashtag?: (tag: string) => void;
  isScheduledLocked?: boolean;
  scheduledUnlockTime?: number;
}

export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds <= 0) return '0:00';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);

  const formattedSecs = secs < 10 ? `0${secs}` : secs;

  if (hrs > 0) {
    const formattedMins = mins < 10 ? `0${mins}` : mins;
    return `${hrs}:${formattedMins}:${formattedSecs}`;
  }
  return `${mins}:${formattedSecs}`;
}

export function formatViews(views: number): string {
  if (views >= 1000000) {
    return `${(views / 1000000).toFixed(1)} M de vistas`;
  }
  if (views >= 1000) {
    return `${(views / 1000).toFixed(1)} K de vistas`;
  }
  return `${views} vistas`;
}

export default function VideoCard({ 
  video, 
  currentUser, 
  onSelectVideo, 
  onVote, 
  playbackProgress, 
  onDeleteVideo, 
  onSelectHashtag,
  isScheduledLocked,
  scheduledUnlockTime
}: VideoCardProps) {
  const isSelfVideo = video.authorName === currentUser.name;
  const isNeon = isSelfVideo && currentUser.vipNeonTheme;

  // Handle 50% lock countdown
  const [timeLeftStr, setTimeLeftStr] = React.useState('');
  React.useEffect(() => {
    if (!scheduledUnlockTime) return;
    const interval = setInterval(() => {
      const remaining = scheduledUnlockTime - Date.now();
      if (remaining <= 0) {
        setTimeLeftStr('');
        clearInterval(interval);
      } else {
        const mins = Math.floor(remaining / 60000);
        const secs = Math.floor((remaining % 60000) / 1000);
        setTimeLeftStr(`${mins}m ${secs}s`);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [scheduledUnlockTime]);

  // Handle 1% or 1.0% self-destruct countdown
  const parsedIdTime = parseInt(video.id.split('-')[1]);
  const isSelfDestruct10 = video.originalityScore === 1 && !isNaN(parsedIdTime);
  const isSelfDestruct1 = video.originalityScore === 1.0 && !isNaN(parsedIdTime);
  const [destructSecs, setDestructSecs] = React.useState(10);

  React.useEffect(() => {
    if (!isSelfDestruct10 && !isSelfDestruct1) return;
    const maxSecs = isSelfDestruct10 ? 10 : 1;
    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - parsedIdTime) / 1000);
      const remaining = maxSecs - elapsed;
      if (remaining <= 0) {
        setDestructSecs(0);
        clearInterval(interval);
      } else {
        setDestructSecs(remaining);
      }
    }, 500);
    return () => clearInterval(interval);
  }, [isSelfDestruct10, isSelfDestruct1, parsedIdTime]);

  // Priority Badge rendering inside the card
  const renderCardBadge = () => {
    const isGamerCool = video.authorName.toLowerCase().includes('gamercool');

    if (isGamerCool) {
      return (
        <span className="inline-flex items-center gap-1 shrink-0 bg-neutral-950/80 px-1 py-0.5 rounded border border-neutral-900">
          <VerifiedBadge type="classic" size="sm" />
          <VerifiedBadge type="star" size="sm" />
          <span className="px-1 py-0.2 text-[6.5px] font-black uppercase tracking-wider bg-gradient-to-r from-red-500 to-amber-500 text-neutral-950 rounded select-none">
            creator
          </span>
        </span>
      );
    }

    const isCompany = video.authorName.toLowerCase().includes('company') || 
                      video.authorName.toLowerCase().includes('official') || 
                      video.authorName.toLowerCase().includes('corp') ||
                      video.authorName.toLowerCase().includes('tech') ||
                      video.authorName.toLowerCase().includes('beats');

    if (video.isVerifiedAuthor) {
      return (
        <span className="inline-flex items-center gap-1 shrink-0 bg-neutral-950/80 px-1 py-0.5 rounded border border-neutral-900">
          <VerifiedBadge type="new-member" size="sm" />
          <span className="px-1 py-0.2 text-[7px] font-black bg-neutral-800 text-neutral-400 rounded">
            {isCompany ? 'Empresa' : 'Nuevo'}
          </span>
        </span>
      );
    }
    
    return null;
  };

  return (
    <div 
      className={`bg-neutral-900/40 border rounded-2xl overflow-hidden group flex flex-col justify-between hover:shadow-2xl transition-all duration-300 relative ${
        isNeon 
          ? 'border-amber-500/80 shadow-[0_0_15px_rgba(245,158,11,0.2)] bg-neutral-900/70' 
          : 'border-neutral-800/80 hover:border-neutral-700/80 hover:bg-neutral-900'
      }`}
    >
      {isNeon && (
        <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5 z-10">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
        </span>
      )}

      {/* Thumbnail block */}
      <div 
        onClick={() => {
          if (!isScheduledLocked) onSelectVideo(video);
        }}
        className="relative aspect-video rounded-xl overflow-hidden bg-black cursor-pointer"
      >
        <img
          src={video.thumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* 50% Plagiarism scheduled overlay */}
        {isScheduledLocked && (
          <div className="absolute inset-0 bg-neutral-950/95 backdrop-blur-sm flex flex-col justify-center items-center text-center p-3 z-30">
            <span className="text-lg p-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-500 rounded-lg mb-1.5 animate-bounce">
              🔒
            </span>
            <span className="text-[10px] font-black tracking-widest text-amber-400 uppercase leading-none">Originalidad Retardada (50%)</span>
            <span className="text-[9px] text-neutral-450 mt-1">Habilitado por la IA de plagio en:</span>
            <span className="text-xs font-mono font-bold text-white bg-amber-950/70 border border-amber-800/30 px-2 py-0.5 rounded mt-1.5 tracking-wider">
              {timeLeftStr || '59m 59s'}
            </span>
          </div>
        )}

        {/* Self-destruct indicators */}
        {(isSelfDestruct10 || isSelfDestruct1) && (
          <div className="absolute top-2.5 right-2.5 bg-red-650 text-white font-mono text-[9px] font-black tracking-widest px-2 py-0.5 rounded shadow z-20 animate-pulse uppercase flex items-center gap-1.5 border border-red-500/40">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping shrink-0" />
            <span>💥 Plagio {destructSecs}s</span>
          </div>
        )}
        
        {/* Play hover button */}
        {!isScheduledLocked && (
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="p-3 rounded-full bg-red-650 shadow-lg text-white transform translate-y-2 group-hover:translate-y-0 transition-all duration-300">
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </div>
          </div>
        )}

        {/* Video duration label */}
        <span className="absolute bottom-2.5 right-2.5 bg-black/85 text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded shadow">
          {formatDuration(video.duration)}
        </span>

        {/* Video category label */}
        <span className="absolute top-2.5 left-2.5 bg-red-650/90 text-white font-sans text-[10px] font-black tracking-wider px-2 py-0.5 rounded shadow uppercase">
          {video.category}
        </span>

        {/* Real-time watch progress bar */}
        {playbackProgress && playbackProgress[video.id] && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-neutral-850 z-10">
            <div 
              className="h-full bg-red-650 transition-all" 
              style={{ width: `${Math.min(((playbackProgress[video.id].currentTime) / (playbackProgress[video.id].duration || 1)) * 100, 100)}%` }}
            />
          </div>
        )}
      </div>

      {/* Details strip */}
      <div className="p-4 flex gap-3">
        {/* Author Avatar */}
        <div className="shrink-0">
          <img
            src={video.authorAvatar}
            alt={video.authorName}
            className="w-9 h-9 rounded-full border border-neutral-800 object-cover"
          />
        </div>

        <div className="flex-1 min-w-0">
          {/* Title */}
          <h4 
            onClick={() => { if (!isScheduledLocked) onSelectVideo(video); }}
            className={`text-white text-xs sm:text-sm font-semibold tracking-tight leading-snug line-clamp-2 transition-colors ${isScheduledLocked ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer hover:text-red-500'}`}
          >
            {video.title}
          </h4>

          {/* Author Strip with priority badges */}
          <div className="flex items-center gap-1.5 mt-1.5 text-neutral-400 text-xs flex-wrap">
            <span className="truncate hover:text-white transition-colors cursor-pointer">{video.authorName}</span>
            {renderCardBadge()}
          </div>

          {/* Views & Timestamp */}
          <div className="flex items-center gap-1.5 text-[11px] text-neutral-500 font-sans mt-1">
            <span className="flex items-center gap-1"><Eye className="w-3" /> {formatViews(video.views)}</span>
            <span>•</span>
            <span>{video.uploadDate}</span>
          </div>

          {/* Custom Hashtags */}
          {video.hashtags && video.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {video.hashtags.map((tag, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onSelectHashtag) onSelectHashtag(tag);
                  }}
                  className="text-[10px] text-red-400 bg-red-950/40 border border-red-550/15 py-0.5 px-2 rounded-full hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  {tag}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Buttons: Like / Dislike */}
      <div className="px-4 pb-4 pt-1 flex items-center justify-between border-t border-neutral-800/60 text-xs mt-auto">
        <span className="text-[10px] text-neutral-500 uppercase font-black tracking-widest font-mono">VALORACIÓN</span>
        
        <div className="flex items-center gap-1">
          {/* Like */}
          <button
            onClick={() => { if (!isScheduledLocked) onVote(video.id, 'like'); }}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-medium transition-all ${
              video.userVoted === 'like'
                ? 'bg-red-950/50 text-red-500 border border-red-500/40'
                : 'bg-neutral-800/60 hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200'
            }`}
            title="Me Gusta"
            disabled={isScheduledLocked}
          >
            <ThumbsUp className={`w-3.5 h-3.5 ${video.userVoted === 'like' ? 'fill-current' : ''}`} />
            <span>{video.likes.toLocaleString()}</span>
          </button>

          {/* Dislike */}
          <button
            onClick={() => { if (!isScheduledLocked) onVote(video.id, 'dislike'); }}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-medium transition-all ${
              video.userVoted === 'dislike'
                ? 'bg-neutral-950 text-zinc-300 border border-neutral-300/60'
                : 'bg-neutral-800/60 hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200'
            }`}
            title="No Me Gusta"
            disabled={isScheduledLocked}
          >
            <ThumbsDown className={`w-3.5 h-3.5 ${video.userVoted === 'dislike' ? 'fill-current' : ''}`} />
            <span>{video.dislikes.toLocaleString()}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
