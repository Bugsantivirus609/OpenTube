import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertOctagon, RefreshCw, Trash2 } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  props: Props;
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("OpenTube Uncaught Error Boundary:", error, errorInfo);
  }

  private handleReset = () => {
    // Clear potentially corrupted or outdated state to prevent loop crashes
    localStorage.removeItem('opentube_user');
    localStorage.removeItem('opentube_videos');
    localStorage.removeItem('opentube_posts');
    window.location.reload();
  };

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col justify-center items-center p-6 font-sans">
          <div className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 text-center shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-red-600/10 via-transparent to-transparent pointer-events-none" />
            
            <div className="w-16 h-16 rounded-2xl bg-red-600/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6">
              <AlertOctagon className="w-8 h-8 text-red-500" />
            </div>

            <h1 className="text-xl font-extrabold text-white mb-2 tracking-tight">OpenTube se ha recuperado</h1>
            <p className="text-neutral-400 text-xs mb-6 leading-relaxed">
              La aplicación detectó una inconsistencia o cambio de estado inesperado en el almacenamiento local de tu navegador.
            </p>

            {this.state.error && (
              <div className="bg-black/40 border border-neutral-850 rounded-xl p-3 mb-6 text-left overflow-x-auto max-h-24 scrollbar-none">
                <p className="text-[10px] font-mono text-rose-400 break-all leading-normal">
                  {this.state.error.toString()}
                </p>
              </div>
            )}

            <div className="flex flex-col gap-2.5">
              <button
                onClick={this.handleReload}
                className="w-full bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Recargar Página
              </button>
              
              <button
                onClick={this.handleReset}
                className="w-full bg-red-650 hover:bg-red-500 text-white font-bold text-xs py-3 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-950/40"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Limpiar Caché y Restaurar Base
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
