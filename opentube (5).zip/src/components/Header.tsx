import React, { useState, useRef, useEffect } from 'react';
import { Youtube, Search, Sparkles, PlusCircle, TrendingUp } from 'lucide-react';
import { UserProfile, Video } from '../types';
import { Language, TRANSLATIONS } from '../lib/translations';

interface HeaderProps {
  currentUser: UserProfile;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenUpload: (mode: 'video' | 'short') => void;
  onNavigateToProfile: () => void;
  onNavigateToHome: () => void;
  allVideos: Video[];
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onSelectSuggestion?: (suggestion: string) => void;
}

export default function Header({ 
  currentUser, 
  searchQuery, 
  setSearchQuery, 
  onOpenUpload,
  onNavigateToProfile,
  onNavigateToHome,
  allVideos,
  lang,
  onLanguageChange,
  onSelectSuggestion
}: HeaderProps) {
  const [isFocused, setIsFocused] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleOutsideClick = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsFocused(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Compute suggestions based on video titles + categories + trending keywords
  const trendingWords = lang === 'es' ? [
    "Curso de React con IA",
    "Gamer cool walkthrough",
    "Lo-fi beats para estudiar",
    "Inteligencia Artificial 2026",
    "Cómo ser creador VIP",
    "Shorts divertidos de misterio"
  ] : [
    "React Course with AI",
    "Cool Gamer Walkthrough",
    "Lo-Fi beats to study",
    "Artificial Intelligence 2026",
    "How to be a VIP Creator",
    "Funny mystery shorts"
  ];

  const getSuggestions = () => {
    if (!searchQuery.trim()) {
      return trendingWords.slice(0, 4); // default trending if empty
    }

    const query = searchQuery.toLowerCase();
    
    // Scan video titles and categories
    const videoMatches = allVideos
      .map(v => v.title)
      .filter(title => title.toLowerCase().includes(query));
      
    const categoryMatches = allVideos
      .map(v => v.category)
      .filter(cat => cat.toLowerCase().includes(query));

    const wordMatches = trendingWords.filter(word => word.toLowerCase().includes(query));

    // Combine and unique
    const merged = Array.from(new Set([...categoryMatches, ...videoMatches, ...wordMatches]));
    return merged.slice(0, 5); // top 5 recommendations
  };

  const suggestions = getSuggestions();

  return (
    <header className="sticky top-0 z-40 bg-neutral-900 border-b border-neutral-800/80 px-4 md:px-6 h-14 flex items-center justify-between">
      {/* Logos and Left */}
      <div className="flex items-center gap-3">
        <button 
          onClick={onNavigateToHome}
          className="flex items-center gap-1.5 focus:outline-none select-none group"
        >
          <div className="flex items-center justify-center p-1.5 bg-red-650 rounded-xl transition-transform group-hover:scale-105 shadow-md shadow-red-950/40">
            <Youtube className="w-5 h-5 text-white fill-current" />
          </div>
          <span className="text-white text-base md:text-lg font-black tracking-tight font-sans">
            Open<span className="text-neutral-300 font-normal">Tube</span>
          </span>
        </button>
      </div>

      {/* Center Search Input with Real-Time Autocomplete suggestions */}
      <div className="flex-1 max-w-xl mx-4 sm:mx-8 relative hidden sm:block" ref={containerRef}>
        <div className="relative flex items-center bg-neutral-950 rounded-full border border-neutral-800 focus-within:border-red-650 transition-all shadow-inner">
          <input
            type="text"
            placeholder={TRANSLATIONS[lang].searchPlaceholder}
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setIsFocused(true);
            }}
            onFocus={() => setIsFocused(true)}
            className="w-full bg-transparent text-white placeholder-neutral-600 text-xs py-2 px-4 focus:outline-none"
          />
          <button 
            type="button"
            className="px-4 py-2 hover:bg-neutral-850 text-neutral-400 hover:text-white rounded-r-full border-l border-neutral-800 transition-colors"
          >
            <Search className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic drop suggestions glass card overlay */}
        {isFocused && suggestions.length > 0 && (
          <div className="absolute left-0 right-0 mt-2 bg-neutral-900/95 border border-neutral-800 rounded-xl shadow-2xl p-2 z-50 text-xs text-neutral-200 font-sans backdrop-blur-md">
            <div className="px-2 py-1 text-[9px] font-black uppercase tracking-wider text-neutral-500 flex items-center gap-1 border-b border-neutral-800/60 pb-1.5 mb-1">
              <TrendingUp className="w-3 h-3 text-red-500" /> {lang === 'es' ? 'SUGERENCIAS EN TIEMPO REAL (ON-DEVICE)' : 'REAL-TIME SUGGESTIONS (ON-DEVICE)'}
            </div>
            <div className="flex flex-col">
              {suggestions.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSearchQuery(suggestion);
                    setIsFocused(false);
                    if (onSelectSuggestion) onSelectSuggestion(suggestion);
                  }}
                  className="flex items-center gap-2 px-2 py-1.5 hover:bg-neutral-800 rounded-lg text-left transition-colors cursor-pointer w-full text-neutral-300 hover:text-white font-medium"
                >
                  <Search className="w-3.5 h-3.5 text-neutral-600 group-hover:text-red-500 shrink-0" />
                  <span className="truncate">{suggestion}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Right Side Buttons & Avatar */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Language Switcher Button */}
        <button
          onClick={() => onLanguageChange(lang === 'es' ? 'en' : 'es')}
          className="flex items-center gap-1 px-1.5 py-1.5 bg-neutral-950/80 hover:bg-neutral-800 border border-neutral-800/70 rounded-xl text-neutral-300 hover:text-white text-xs font-bold transition-all shrink-0 cursor-pointer"
          title={lang === 'es' ? "Switch to English" : "Cambiar a Español"}
        >
          <span className="text-[10px]">🌐</span>
          <span className="font-mono uppercase text-[9px] tracking-wider">{lang}</span>
        </button>

        {/* Upload Dropdown actions */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => onOpenUpload('video')}
            className="flex items-center gap-1 px-2 py-1.5 hover:bg-neutral-800 text-neutral-300 hover:text-white rounded-lg text-xs font-semibold tracking-wide transition-all"
            title={lang === 'es' ? "Sube un video de formato estándar (>1 min)" : "Upload standard format video (>1 min)"}
          >
            <PlusCircle className="w-4 h-4 text-red-500" />
            <span className="hidden md:inline">{lang === 'es' ? 'Video' : 'Video'}</span>
          </button>
          
          <button
            onClick={() => onOpenUpload('short')}
            className="flex items-center gap-1 px-2 py-1.5 hover:bg-neutral-800 text-neutral-300 hover:text-white rounded-lg text-xs font-semibold tracking-wide transition-all"
            title={lang === 'es' ? "Sube un short interactivo (<1 min)" : "Upload interactive short (<1 min)"}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span className="hidden md:inline">{lang === 'es' ? 'Shorts' : 'Shorts'}</span>
          </button>
        </div>

        {/* Search button mobile display only */}
        <div className="sm:hidden relative">
          <input
            type="text"
            placeholder={lang === 'es' ? "Buscar..." : "Search..."}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-16 bg-neutral-950 text-white placeholder-neutral-600 text-[10px] py-1 px-2 rounded-lg border border-neutral-800 focus:outline-none focus:border-red-500 transition-all font-sans"
          />
        </div>

        {/* Channel Icon & Settings Trigger */}
        <button
          onClick={onNavigateToProfile}
          className="flex items-center gap-2 hover:bg-neutral-800 py-1.5 px-2 rounded-full md:rounded-xl transition-all focus:outline-none shrink-0"
          title={lang === 'es' ? "Gestión de Perfil Abierto de Creador" : "Creator Profile Settings"}
        >
          <img
            src={currentUser.avatarUrl}
            alt={currentUser.name}
            className="w-7 h-7 rounded-full border border-red-500 object-cover"
          />
          <span className="text-white text-xs font-semibold hidden lg:inline max-w-[120px] truncate">
            {currentUser.name}
          </span>
        </button>
      </div>
    </header>
  );
}
