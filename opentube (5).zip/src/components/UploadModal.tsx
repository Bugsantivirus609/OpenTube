import React, { useState, useRef, useEffect } from 'react';
import { X, Film, Sparkles, Youtube, Check, Image, FileVideo, Music, ShieldAlert, Cpu } from 'lucide-react';
import { Video } from '../types';
import { analyzeVideoOriginality } from '../lib/originalityAnalyzer';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (newVideo: Video & { originalityScore?: number }, videoFile?: File | Blob, thumbnailFile?: File | Blob) => void;
  currentUser: { name: string; avatarUrl: string };
  existingVideos: Video[]; // Pass the platform's video database to compare
  initialMode?: 'video' | 'short';
  lang?: 'es' | 'en';
}

export default function UploadModal({ isOpen, onClose, onUpload, currentUser, existingVideos, initialMode = 'video', lang = 'es' }: UploadModalProps) {
  const [uploadMode, setUploadMode] = useState<'video' | 'short'>(initialMode);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState('Español');
  const [hashtagsStr, setHashtagsStr] = useState('');
  
  // Real file explore states
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [isAudio, setIsAudio] = useState<boolean>(false);
  
  const [duration, setDuration] = useState<number>(120);
  const [category, setCategory] = useState('Desarrollo');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // New Checkboxes per user request
  const [isAudioAuthorChecked, setIsAudioAuthorChecked] = useState(false);
  const [isIaConsentChecked, setIsIaConsentChecked] = useState(false);

  // Plagiarism Originality state
  const [originalityScore, setOriginalityScore] = useState<number>(100);
  const [isAnalyzingOriginality, setIsAnalyzingOriginality] = useState(false);
  const [analysisLogs, setAnalysisLogs] = useState<string[]>([]);
  const [analysisReason, setAnalysisReason] = useState<string>('');

  // AI Thumbnails Generation info
  const [aiCoverStatus, setAiCoverStatus] = useState<'idle' | 'generating' | 'success'>('idle');
  const [aiCoverResultText, setAiCoverResultText] = useState('');

  const videoInputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);

  // Sync mode duration defaults
  useEffect(() => {
    if (!videoFile) {
      setDuration(uploadMode === 'video' ? 120 : 30);
    }
  }, [uploadMode, videoFile]);

  if (!isOpen) return null;

  // High-precision on-device content analysis scanner
  const runOriginalityScan = async (file: File, currentTitle: string, currentDesc: string) => {
    setIsAnalyzingOriginality(true);
    setAnalysisLogs([
      lang === 'es' 
        ? "🔍 Leyendo flujo binario completo del archivo..." 
        : "🔍 Loading complete binary file stream..."
    ]);
    setAnalysisReason('');

    const logSteps = [
      lang === 'es' 
        ? "📡 Mapeando espectro de audio y fotogramas clave..." 
        : "📡 Mapping spectral audio cues and keyframes...",
      lang === 'es' 
        ? "🧬 Buscando colisiones binarias hashes en IndexedDB & Dexie..." 
        : "🧬 Querying binary collisions and hashes in Dexie DB...",
      lang === 'es' 
        ? "📊 Calculando coeficiente de Jaccard y Levenshtein de Metadatos..." 
        : "📊 Calculating Jaccard and Levenshtein lexical similarity...",
      lang === 'es' 
        ? "💬 Procesando coincidencia semántica en título y descripción..." 
        : "💬 Processing semantic titles / description matching bounds...",
      lang === 'es' 
        ? "🧠 Ejecutando algoritmo de copyright AI en tiempo real..." 
        : "🧠 Applying active real-time AI anti-piracy models..."
    ];

    let stepIndex = 0;
    const interval = setInterval(() => {
      if (stepIndex < logSteps.length) {
        setAnalysisLogs(prev => [...prev, logSteps[stepIndex]]);
        stepIndex++;
      }
    }, 400);

    try {
      const res = await analyzeVideoOriginality(file, currentTitle, currentDesc, existingVideos);
      
      // small delay to let user enjoy the scanning steps
      await new Promise(resolve => setTimeout(resolve, logSteps.length * 401));
      clearInterval(interval);
      
      setOriginalityScore(res.score);
      setIsAnalyzingOriginality(false);
      
      if (res.matchReason) {
        setAnalysisReason(res.matchReason);
        setAnalysisLogs(prev => [
          ...prev, 
          lang === 'es' 
            ? `❌ Coincidencia encontrada: ${res.matchReason}` 
            : `❌ Copyright match: ${res.matchReason}`
        ]);
      } else {
        setAnalysisLogs(prev => [
          ...prev, 
          lang === 'es' 
            ? "✓ ¡Puntuación: 100%! No se detectaron colisiones de plagio en OpenTube" 
            : "✓ Rating: 100%! No copyright collisions found in OpenTube"
        ]);
      }
    } catch (err) {
      clearInterval(interval);
      setIsAnalyzingOriginality(false);
      console.error(err);
    }
  };

  // Handle video or music selection from explorer
  const handleVideoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setVideoFile(file);
      const fileUrl = URL.createObjectURL(file);
      setVideoUrl(fileUrl);
      
      const fileIsAudio = (file.type || '').startsWith('audio/') || file.name.match(/\.(mp3|wav|ogg|m4a|aac|opus|mpeg)$/i) !== null;
      setIsAudio(fileIsAudio);
      if (fileIsAudio) {
        setCategory('Música');
      }
      
      // Attempt to extract real duration from metadata of selected video/audio
      try {
        const tempEl = document.createElement(fileIsAudio ? 'audio' : 'video');
        tempEl.preload = 'metadata';
        tempEl.onloadedmetadata = () => {
          if (tempEl.duration && !isNaN(tempEl.duration)) {
            setDuration(Math.round(tempEl.duration));
          }
        };
        tempEl.src = fileUrl;
      } catch (err) {
        console.warn("Could not read duration automatically", err);
      }

      // Run automatic AI scanner immediately
      runOriginalityScan(file, title || file.name, description);
    }
  };

  // Handle thumbnail selection from explorer
  const handleThumbnailFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setThumbnailFile(file);
      const fileUrl = URL.createObjectURL(file);
      setThumbnailUrl(fileUrl);
      // reset AI generation status
      setAiCoverStatus('idle');
      setAiCoverResultText('');
    }
  };

  // AI Cover Generation logic
  const handleGenerateAiCover = () => {
    if (!videoFile) {
      setErrorMessage(lang === 'es' ? "Por favor selecciona un video primero." : "Please select a video file first.");
      return;
    }
    setAiCoverStatus('generating');
    setErrorMessage(null);

    const delay = uploadMode === 'short' ? 800 : 1500;
    setTimeout(() => {
      let coverUrl = '';
      let msg = '';
      if (uploadMode === 'short') {
        coverUrl = `https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80`;
        msg = lang === 'es' 
          ? "✨ Cubierta de IA: Se ha extraído el Fotograma Inicial del Short (0:01) como portada oficial (100% Retención en Feed Vertical)."
          : "✨ AI Cover: Extracted the Initial Short Frame (0:01) as the official cover (100% Vertical Feed Retention).";
      } else {
        coverUrl = `https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600&auto=format&fit=crop&q=80`;
        msg = lang === 'es' 
          ? "✨ Cubierta de IA: Análisis de retención completado. Se seleccionó el Fotograma 3:14 (Punto de Clímax y 98.4% CTR Estimado)."
          : "✨ AI Cover: Retention analyze completed. Frame 3:14 selected (Climax sequence & 98.4% Estimated CTR).";
      }

      setThumbnailUrl(coverUrl);
      setThumbnailFile(new File([], "ai_frame.jpg")); // mock file object
      setAiCoverStatus('success');
      setAiCoverResultText(msg);
    }, delay);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    // Mandatories verification
    if (!isAudioAuthorChecked) {
      setErrorMessage(lang === 'es' 
        ? "⚠️ Es mandatorio verificar la autoría del audio antes de publicar."
        : "⚠️ It is mandatory to declare audio authorship before publishing."
      );
      return;
    }

    if (!isIaConsentChecked) {
      setErrorMessage(lang === 'es' 
        ? "⚠️ Es mandatorio aceptar el escaneo de IA para optimizar procesamiento."
        : "⚠️ It is mandatory to accept AI scan consent to proceed."
      );
      return;
    }

    // Form parameter sanitizations
    if (!title.trim()) {
      setErrorMessage(lang === 'es' ? "Por favor ingresa un título para el video o short." : "Please enter a title for your video or short.");
      return;
    }

    // AI Moderator check
    const checkText = `${title} ${description} ${hashtagsStr}`.toLowerCase();
    const toxicSubstrings = ["porno", "sexo", "porn", "sex", "gore", "violencia", "sangre", "muerte", "nude", "hackeo", "terrorismo", "grosería", "insulto", "armas", "asesinar", "naked", "hacker"];
    const foundViolation = toxicSubstrings.filter(word => checkText.includes(word));
    
    // Check if user is trying to bypass or has toxic material
    const isBypassActive = localStorage.getItem('opentube_bypass_moderation') === 'true';
    if (foundViolation.length > 0 && !isBypassActive) {
      setErrorMessage(lang === 'es' 
        ? `🤖 [AI Content Guard] Publicación DENEGADA. El Moderador de Inteligencia Artificial de OpenTube detectó términos restringidos (${foundViolation.map(w => `"${w}"`).join(', ')}). Por favor corrige el texto para continuar.`
        : `🤖 [AI Content Guard] Publication BLOCKED. OpenTube's Artificial Intelligence Moderator detected restricted terms (${foundViolation.map(w => `"${w}"`).join(', ')}). Please revise the text to continue.`
      );
      return;
    }

    if (!videoFile || !videoUrl) {
      setErrorMessage(lang === 'es' ? "Por favor selecciona un archivo de video o audio MP3 de tu explorador." : "Please select a video or MP3 audio file from your files.");
      return;
    }
    if (duration <= 0) {
      setErrorMessage(lang === 'es' ? "La duración del archivo debe ser un número positivo." : "File duration must be a positive number.");
      return;
    }

    let finalTitle = title.trim();

    // Validations based on type - skip strict standard video lengths if it IS an audio track
    if (!isAudio) {
      if (uploadMode === 'video') {
        if (duration <= 60) {
          setErrorMessage(lang === 'es' 
            ? "Has seleccionado 'Video estándar'. Para videos estándar, la duración debe superar los 60 segundos. Si es más corto, cámbialo a 'Short de OpenTube' arriba."
            : "You've selected 'Standard video'. Standard videos must exceed 60 seconds of length. If it's shorter, toggle to 'OpenTube Short' above."
          );
          return;
        }
      } else {
        // Shorts validation
        if (duration > 60) {
          setErrorMessage(lang === 'es' 
            ? "¡Alerta de Shorts! Los shorts no pueden superar los 60 segundos. Si el video mide más de un minuto, cámbialo a modo 'Video estándar' arriba."
            : "Shorts warning! Shorts cannot exceed 60 seconds. If the video is longer, toggle to 'Standard video' format above."
          );
          return;
        }
        // Auto hashtag '#shorts' if missing
        if (!finalTitle.toLowerCase().includes('#shorts')) {
          finalTitle = `${finalTitle} #shorts`;
        }
      }
    }

    // Default thumbnails based on categories if not provided
    const finalThumbnail = thumbnailUrl.trim() || `https://images.unsplash.com/photo-${
      isAudio || category === 'Música' ? '1511671782779-c97d3d27a1d4' :
      category === 'Gamer' ? '1538481199705-c710c4e965fc' :
      category === 'Tecnología' ? '1488590528505-98d2b5aba04b' :
      '1504384308090-c894fdcc538d'
    }?w=800&auto=format&fit=crop&q=80`;

    // Create unique id
    const newId = `${isAudio ? 'a' : (uploadMode === 'short' ? 's' : 'v')}-${Date.now()}`;

    // Parse own hashtags
    const ownHashtags = hashtagsStr
      .split(/[\s,#;]+/)
      .map(h => h.trim().toLowerCase())
      .filter(h => h.length > 0)
      .map(h => h.startsWith('#') ? h : `#${h}`);

    const newVideo: Video & { originalityScore?: number } = {
      id: newId,
      title: finalTitle,
      description: description.trim() || (isAudio ? "Pista musical con audio de alta fidelidad subida localmente." : "No se ha proporcionado ninguna descripción para este video interconectado."),
      videoUrl: videoUrl,
      thumbnailUrl: finalThumbnail,
      duration: duration,
      views: 1 + Math.floor(Math.random() * 5), // starting views
      uploadDate: "Justo ahora",
      likes: 1,
      dislikes: 0,
      category: isAudio ? 'Música' : (uploadMode === 'short' ? 'Shorts' : category),
      isShort: !isAudio && uploadMode === 'short',
      authorName: currentUser.name,
      authorAvatar: currentUser.avatarUrl,
      isVerifiedAuthor: true,
      isAudio: isAudio,
      comments: [],
      hashtags: ownHashtags,
      language: language,
      originalityScore: originalityScore
    };

    onUpload(newVideo, videoFile || undefined, thumbnailFile || undefined);
    
    // Custom messages according to originality score simulation
    if (originalityScore < 50 && originalityScore !== 1 && originalityScore !== 1.0) {
      setSuccessMessage(lang === 'es'
        ? `⚠️ El video se ha borrado de inmediato porque la IA de Originalidad detectó plagio masivo (${originalityScore}% de originalidad).`
        : `⚠️ The video was instantly deleted because the AI Originality guard detected massive copy (${originalityScore}% originality).`
      );
    } else if (originalityScore === 50) {
      setSuccessMessage(lang === 'es'
        ? `🕒 El video se ha programado para dentro de 1 hora exacta (50% de originalidad detectado).`
        : `🕒 Video scheduled for exactly 1 hour from now due to detected 50% originality.`
      );
    } else if (originalityScore === 1) {
      setSuccessMessage(lang === 'es'
        ? `⚠️ ¡Alerta! Originalidad crítica (1%). Se autodestruirá y borrará del feed en 10 segundos.`
        : `⚠️ Alert! Critical originality (1%). It will self-destruct and erase from history feed in 10 seconds.`
      );
    } else if (originalityScore === 1.0) {
      setSuccessMessage(lang === 'es'
        ? `⚠️ ¡Alerta! Originalidad crítica extrema (1.0%). Se autodestruirá y borrará del feed en 1 segundo.`
        : `⚠️ Warning! Extreme critical originality (1.0%). It will self-destruct from feed in exactly 1 second.`
      );
    } else {
      setSuccessMessage(lang === 'es'
        ? `🚀 ¡Publicado con éxito! 100% Original según la IA. Podrás mirarlo para siempre.`
        : `🚀 Published successfully! 100% Original audited by AI scanners.`
      );
    }
    
    // Clear state
    setTitle('');
    setDescription('');
    setHashtagsStr('');
    setLanguage('Español');
    setVideoFile(null);
    setVideoUrl('');
    setThumbnailFile(null);
    setThumbnailUrl('');
    setIsAudio(false);
    setDuration(uploadMode === 'video' ? 120 : 30);
    setIsAudioAuthorChecked(false);
    setIsIaConsentChecked(false);

    setTimeout(() => {
      onClose();
      setSuccessMessage(null);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 bg-black/85 flex items-center justify-center p-4 z-50 animate-fade-in backdrop-blur-md">
      <div 
        id="upload-modal-container" 
        className="bg-neutral-900 border border-neutral-800 rounded-2xl w-full max-w-xl overflow-y-auto max-h-[90vh] shadow-2xl relative scrollbar-none"
      >
        {/* Header */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-neutral-800 bg-neutral-900/50 sticky top-0 z-10 backdrop-blur">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-red-650 animate-pulse">
              <Youtube className="w-5 h-5 text-white" />
            </span>
            <h3 className="text-white text-lg font-bold tracking-tight font-sans">
              {lang === 'es' ? "Publicar Nuevo Video en OpenTube" : "Publish New Video on OpenTube"}
            </h3>
          </div>
          <button 
            type="button"
            onClick={onClose} 
            className="text-neutral-400 hover:text-white p-1 hover:bg-neutral-800 rounded-full transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-4">
          
          {/* UPLOAD MODE TOGGLE */}
          <div>
            <label className="text-neutral-400 text-xs font-semibold uppercase tracking-wider mb-2 block font-sans">
              {lang === 'es' ? "Formato de Contenido:" : "Content Format:"}
            </label>
            <div className="grid grid-cols-2 gap-2 bg-neutral-950 p-1.5 rounded-xl border border-neutral-800">
              <button
                type="button"
                onClick={() => {
                  setUploadMode('video');
                }}
                className={`py-2 px-3 rounded-lg flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold transition-all ${
                  uploadMode === 'video'
                    ? 'bg-neutral-800 text-white shadow-md border-b-2 border-red-500'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Film className="w-4 h-4 text-red-500" />
                {lang === 'es' ? "Video estándar" : "Standard video"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setUploadMode('short');
                }}
                className={`py-2 px-3 rounded-lg flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold transition-all ${
                  uploadMode === 'short'
                    ? 'bg-neutral-800 text-white shadow-md border-b-2 border-red-500'
                    : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                {lang === 'es' ? "Short de OpenTube" : "OpenTube Short"}
              </button>
            </div>
          </div>

          {/* Video or audio upload input */}
          <div className="flex flex-col gap-1.5">
            <label className="text-neutral-400 text-xs font-semibold tracking-wide block">
              {lang === 'es' 
                ? "Seleccionar Video o Música MP3 (*.mp4, *.webm, *.mp3, *.wav)" 
                : "Select Video or MP3 Audio File (*.mp4, *.webm, *.mp3, *.wav)"
              }
            </label>
            <div 
              onClick={() => videoInputRef.current?.click()}
              className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer bg-neutral-950 transition-colors flex flex-col items-center justify-center gap-2 group ${
                isAudio ? 'border-amber-500/45 hover:border-amber-400' : 'border-neutral-800 hover:border-red-500'
              }`}
            >
              <input
                ref={videoInputRef}
                type="file"
                accept="video/mp4,video/webm,video/ogg,video/quicktime,audio/mp3,audio/mpeg,audio/wav,audio/m4a,audio/x-m4a,audio/ogg"
                onChange={handleVideoFileChange}
                className="hidden"
              />
              <div className={`p-3 border rounded-2xl group-hover:scale-105 transition-transform duration-300 ${
                isAudio 
                  ? 'bg-amber-500/10 border-amber-500/25 text-amber-400'
                  : 'bg-red-600/10 border-red-500/20 text-red-500'
              }`}>
                {isAudio ? (
                  <Music className="w-6 h-6 text-amber-400 animate-pulse" />
                ) : (
                  <FileVideo className="w-6 h-6 text-red-500" />
                )}
              </div>
              <div>
                {videoFile ? (
                  <div className="flex flex-col items-center">
                    <span className={`${isAudio ? 'text-amber-400' : 'text-emerald-400'} text-xs font-mono font-bold max-w-[280px] truncate`}>
                      {videoFile.name}
                    </span>
                    <span className="text-[10px] text-neutral-400 mt-0.5">
                      {(videoFile.size / (1024 * 1024)).toFixed(2)} MB • {isAudio ? (lang === 'es' ? 'Pista de Música MP3' : 'MP3 Audio track') : (lang === 'es' ? 'Video Local listo' : 'Local Video ready')}
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center">
                    <span className="text-white text-xs font-bold font-sans">
                      {lang === 'es' ? "Haz clic para buscar archivos locales" : "Click to browse local media files"}
                    </span>
                    <span className="text-[10px] text-neutral-500 mt-1">
                      {lang === 'es' ? "Reproducción nativa fluida sin enlaces oficiales caídos" : "Fluid local native reproduction without broken links"}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Title input */}
          <div>
            <label className="text-neutral-400 text-xs font-semibold tracking-wide mb-1.5 block">
              {lang === 'es' ? "Título del Video o Short" : "Video or Short Title"}
            </label>
            <input
              type="text"
              required
              placeholder={lang === 'es' ? "Ej: El mejor setup para programar en React en 2026" : "E.g.: The ultimate React coding setup for 2026"}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-neutral-950 text-white placeholder-neutral-600 text-sm rounded-xl px-4 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors"
            />
          </div>

          {/* Dual Input: Manual Thumbnail upload or AI Dynamic Cover picker */}
          <div className="flex flex-col gap-2 bg-neutral-950/60 p-3 rounded-xl border border-neutral-850">
            <div className="flex items-center justify-between">
              <label className="text-neutral-400 text-xs font-bold tracking-wide">
                🖼️ {lang === 'es' ? "Portada / Miniatura (IA o Manual)" : "Cover / Thumbnail (AI or Manual)"}
              </label>
              <button
                type="button"
                onClick={handleGenerateAiCover}
                disabled={aiCoverStatus === 'generating'}
                className="text-[10.5px] bg-red-650/20 hover:bg-red-650 hover:text-white border border-red-550/30 text-red-400 px-2.5 py-1 rounded-lg font-bold transition-all flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5 animate-pulse" />
                {aiCoverStatus === 'generating' 
                  ? (lang === 'es' ? 'Pensando...' : 'Analyzing...') 
                  : (lang === 'es' ? 'Portada con IA ✨' : 'Cover with AI ✨')
                }
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
              {/* File upload clicker */}
              <div 
                onClick={() => thumbnailInputRef.current?.click()}
                className="sm:col-span-12 border border-dashed border-neutral-800 hover:border-violet-500 rounded-xl px-3 py-2 text-center cursor-pointer bg-neutral-950 transition-colors flex items-center justify-center gap-2 group"
              >
                <input
                  ref={thumbnailInputRef}
                  type="file"
                  accept="image/*.png,image/*.jpg,image/*.jpeg,image/*.webp"
                  onChange={handleThumbnailFileChange}
                  className="hidden"
                />
                
                {thumbnailUrl ? (
                  <div className="flex items-center gap-3 w-full text-left">
                    <img 
                      src={thumbnailUrl} 
                      alt="Miniatura" 
                      className="w-16 h-10 object-cover rounded border border-neutral-800 shrink-0" 
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-emerald-400 text-xs font-mono font-bold truncate">
                        {thumbnailFile?.name ? thumbnailFile.name : (lang === 'es' ? "Fotograma Capturado" : "AI Frame Captured")}
                      </p>
                      <p className="text-[10px] text-neutral-400 leading-tight">
                        {lang === 'es' ? "Portada guardada como óptima para CTR." : "Perfectly linked cover for CTR acquisition."}
                      </p>
                    </div>
                  </div>
                ) : (
                  <>
                    <Image className="w-4 h-4 text-violet-500 shrink-0" />
                    <span className="text-neutral-400 text-[11px] font-semibold">
                      {lang === 'es' ? "Haz clic para subir foto manual" : "Click to upload manual photo"}
                    </span>
                  </>
                )}
              </div>
            </div>

            {/* AI Cover Feedback Banner */}
            {aiCoverResultText && (
              <div className="text-[10px] bg-red-650/15 border border-red-500/20 text-red-300 rounded-lg p-2 font-medium">
                {aiCoverResultText}
              </div>
            )}
          </div>

                  {/* Real AI Originality scan matching panel */}
          <div className="bg-neutral-950/85 p-4 rounded-2xl border border-neutral-800">
            <div className="flex items-center justify-between gap-1.5 mb-2 select-none">
              <label className="text-white text-xs font-bold items-center gap-1.5 flex leading-none">
                <Cpu className="w-4 h-4 text-emerald-400 animate-pulse" />
                {lang === 'es' ? "Escáner Óptico de Originalidad por IA Activo" : "Active AI Byte Originality Scanner"}
              </label>

              {videoFile && (
                <button
                  type="button"
                  disabled={isAnalyzingOriginality}
                  onClick={() => runOriginalityScan(videoFile, title || videoFile.name, description)}
                  className="bg-neutral-900 border border-neutral-850 hover:bg-neutral-800 text-[10px] py-1 px-2 rounded-lg text-neutral-300 font-semibold cursor-pointer shrink-0"
                >
                  {isAnalyzingOriginality ? (lang === 'es' ? 'Analizando...' : 'Scanning...') : (lang === 'es' ? 'Re-escanear ⚡' : 'Re-scan ⚡')}
                </button>
              )}
            </div>

            {videoFile ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between bg-neutral-900 px-3 py-2 rounded-xl border border-neutral-850">
                  <span className="text-[10.5px] text-neutral-400">{lang === 'es' ? "Rating de Originalidad Auténtico:" : "Authentic Originality Rating:"}</span>
                  <span className={`text-sm sm:text-base font-black font-mono tracking-tight ${
                    originalityScore >= 80 ? 'text-emerald-400' :
                    originalityScore >= 50 ? 'text-amber-400' : 'text-rose-500 animate-pulse'
                  }`}>
                    {isAnalyzingOriginality ? '•••' : `${originalityScore}%`}
                  </span>
                </div>

                {/* Animated progress bar */}
                <div className="w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden border border-neutral-850">
                  <div 
                    className={`h-full transition-all duration-500 ${
                      isAnalyzingOriginality 
                        ? 'bg-amber-400 w-1/2 animate-ping' 
                        : originalityScore >= 80 
                          ? 'bg-emerald-500' 
                          : originalityScore >= 50 
                            ? 'bg-amber-500' 
                            : 'bg-rose-500'
                    }`}
                    style={{ width: isAnalyzingOriginality ? '50%' : `${originalityScore}%` }}
                  />
                </div>

                {/* Real-time terminal with scan step logs */}
                <div className="bg-neutral-900 font-mono text-[9.5px] p-2.5 rounded-xl border border-neutral-850 space-y-1 h-32 overflow-y-auto custom-scrollbar select-text selection:bg-rose-600/30 selection:text-white">
                  {analysisLogs.map((log, i) => (
                    <div key={i} className={`leading-relaxed ${
                      (log || '').startsWith('❌') ? 'text-red-400 font-bold' :
                      (log || '').startsWith('✓') ? 'text-emerald-400 font-bold' :
                      'text-zinc-400'
                    }`}>
                      {log}
                    </div>
                  ))}
                  {isAnalyzingOriginality && (
                    <div className="text-amber-500 text-[9px] animate-pulse italic mt-1 font-sans">
                      {lang === 'es' ? "🛠️ Procesando firma binaria y comparando arrays de bytes..." : "🛠️ Hashing file binary header and computing checksum blocks..."}
                    </div>
                  )}
                </div>

                <p className="text-[9.5px] text-neutral-500 leading-tight">
                  {originalityScore === 100 && (lang === 'es' ? "✓ Originalidad completa. Tu contenido durará para siempre en OpenTube." : "✓ Complete originality. Your content will persist forever.")}
                  {originalityScore === 50 && (lang === 'es' ? "🕒 50% de plagio. Estará bloqueado y se habilitará en 1 hora exacta." : "🕒 50% clone. Locked and will activate in exactly 1 hour.")}
                  {originalityScore === 1 && (lang === 'es' ? "⚠️ ¡Peligroso! Autodestrucción dinámica de 10 segundos al publicar." : "⚠️ Hazard! Dynamic 10s auto-destruction countdown after publication.")}
                  {originalityScore === 1.0 && (lang === 'es' ? "💥 Extremo! Autodestrucción instantánea de 1 segundo al publicar." : "💥 Extreme! Instant 1s auto-destruction right after uploading.")}
                  {originalityScore < 49 && originalityScore !== 1 && originalityScore !== 1.0 && (lang === 'es' ? "⚠️ Copia masiva. Será de inmediato descartado por regulaciones DMCA." : "⚠️ Massive copy. Will be instantly discarded due to copyright policies.")}
                </p>
              </div>
            ) : (
              <div className="text-center p-3 bg-neutral-900 rounded-xl border border-neutral-850 text-neutral-500 text-[10.5px] italic">
                {lang === 'es' 
                  ? "Sube un archivo de video o audio para iniciar el analizador inteligente de bytes OpenTube IA..." 
                  : "Upload a file from your device to run the smart byte indexer algorithm..."}
              </div>
            )}
          </div>

          {/* Row of Duration & Category */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-neutral-400 text-xs font-semibold tracking-wide mb-1.5 block">
                {lang === 'es' ? "Duración del Video (segundos)" : "Video Duration (seconds)"}
              </label>
              <input
                type="number"
                min="1"
                required
                value={duration || ''}
                onChange={(e) => setDuration(parseInt(e.target.value) || 0)}
                className="w-full bg-neutral-950 text-white placeholder-neutral-600 text-sm rounded-xl px-4 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors font-mono"
              />
              <span className="text-[10px] text-neutral-400 mt-1 block font-sans">
                {uploadMode === 'video' ? (lang === 'es' ? 'Mínimo: >60s' : 'Minimum: >60s') : (lang === 'es' ? 'Máximo: 60s' : 'Maximum: 60s')}
              </span>
            </div>

            <div>
              <label className="text-neutral-400 text-xs font-semibold tracking-wide mb-1.5 block">
                {lang === 'es' ? "Categoría temática" : "Thematic Category"}
              </label>
              <select
                value={category}
                disabled={uploadMode === 'short'}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-neutral-950 text-white text-sm rounded-xl px-3 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors cursor-pointer"
              >
                <option value="Desarrollo">Desarrollo Web</option>
                <option value="Música">Música & Lo-Fi</option>
                <option value="Gamer">Gamer</option>
                <option value="Tecnología">Tecnología de Punta</option>
                <option value="Entretenimiento">Entretenimiento</option>
                <option value="Cortometraje">Cortometraje</option>
              </select>
            </div>
          </div>

          {/* Row of Language & Hashtags */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-neutral-400 text-xs font-semibold tracking-wide mb-1.5 block">
                {lang === 'es' ? "Idioma original del audio" : "Original Audio Language"}
              </label>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full bg-neutral-950 text-white text-xs sm:text-sm rounded-xl px-3 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors cursor-pointer"
              >
                <option value="Español">Español 🇪🇸</option>
                <option value="Inglés">Inglés 🇺🇸</option>
                <option value="Japonés">Japonés 🇯🇵</option>
                <option value="Portugués">Portugués 🇵🇹</option>
                <option value="Francés">Francés 🇫🇷</option>
                <option value="Alemán">Alemán 🇩🇪</option>
              </select>
            </div>

            <div>
              <label className="text-neutral-400 text-xs font-semibold tracking-wide mb-1.5 block">
                {lang === 'es' ? "Hashtags (#vlog #gaming)" : "Hashtags (#vlog #gaming)"}
              </label>
              <input
                type="text"
                placeholder="Ej: gaming, react, vlog"
                value={hashtagsStr}
                onChange={(e) => setHashtagsStr(e.target.value)}
                className="w-full bg-neutral-950 text-white placeholder-neutral-600 text-xs sm:text-sm rounded-xl px-4 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-neutral-400 text-xs font-semibold tracking-wide mb-1.5 block">
              {lang === 'es' ? "Descripción detallada" : "Detailed Description"}
            </label>
            <textarea
              placeholder={lang === 'es' ? "Introduce detalles sobre tu video..." : "Provide elaborate details about your uploaded asset..."}
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full bg-neutral-950 text-white placeholder-neutral-500 text-xs sm:text-sm rounded-xl px-4 py-2.5 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors resize-none"
            />
          </div>

          {/* MANDATORY CHECKBOXES PER DIRECT REQUEST */}
          <div className="flex flex-col gap-2.5 mt-2 bg-neutral-950 p-3 rounded-xl border border-red-500/10">
            {/* Audio Authorship Check */}
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isAudioAuthorChecked}
                onChange={(e) => setIsAudioAuthorChecked(e.target.checked)}
                className="mt-1 accent-red-650 w-4 h-4 rounded border-neutral-800 cursor-pointer text-red-650 focus:ring-0"
              />
              <div className="text-[10.5px] leading-tight">
                <span className="text-white font-bold block mb-0.5">
                  🎙️ {lang === 'es' ? "DECLARACIÓN DE AUTORÍA DE AUDIO (Mandatorio)" : "AUDIO AUTHORSHIP STATEMENT (Mandatory)"}
                </span>
                <span className="text-neutral-400">
                  {lang === 'es' 
                    ? "Declaro solemnemente que la pista de sonido es mía o cuento con licencia explícita. Acepto la eliminación del contenido de forma inmediata si se presenta una queja oficial de plagio." 
                    : "I solemnly declare that this audio track is mine or I hold an explicit distribution license. I accept immediate deletion of my upload if a plagiarism dispute is officially filed."
                  }
                </span>
              </div>
            </label>

            {/* AI Scan Consent Check */}
            <label className="flex items-start gap-2.5 cursor-pointer select-none border-t border-neutral-850 pt-2.5">
              <input
                type="checkbox"
                checked={isIaConsentChecked}
                onChange={(e) => setIsIaConsentChecked(e.target.checked)}
                className="mt-1 accent-red-650 w-4 h-4 rounded border-neutral-800 cursor-pointer text-red-650 focus:ring-0"
              />
              <div className="text-[10.5px] leading-tight">
                <span className="text-white font-bold block mb-0.5">
                  🤖 {lang === 'es' ? "CONSENTIMIENTO DE ESCANEO DE IA (Mandatorio)" : "AI SCAN AND MODERATION CONSENT (Mandatory)"}
                </span>
                <span className="text-neutral-400">
                  {lang === 'es' 
                    ? "Doy consentimiento explícito al algoritmo inteligente de OpenTube para analizar la toxicidad, auditar el plagio y optimizar la retención. Si no se marca, el video no se procesará." 
                    : "I give my explicit consent to OpenTube's smart scanner to analyze toxicity, check for copies and optimize retentions. Without consent, the video won't be processed."
                  }
                </span>
              </div>
            </label>
          </div>

          {/* ERROR MESSAGE DISPLAY */}
          {errorMessage && (
            <div className="bg-red-950/40 border border-red-500/50 rounded-xl p-3 text-red-400 text-xs text-center font-sans font-medium">
              ⚠️ {errorMessage}
            </div>
          )}

          {/* SUCCESS MESSAGE DISPLAY */}
          {successMessage && (
            <div className="bg-emerald-950/60 border border-emerald-500/50 rounded-xl p-3 text-emerald-400 text-xs font-semibold text-center flex items-center justify-center gap-1.5 font-sans">
              <Check className="w-4 h-4 text-emerald-400 animate-bounce" /> {successMessage}
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            className="w-full mt-2 bg-red-650 hover:bg-red-500 text-white font-bold text-xs sm:text-sm py-3 px-4 rounded-xl transition-all hover:shadow-lg active:scale-[0.98] font-sans disabled:opacity-50"
          >
            {lang === 'es' ? "Publicar en OpenTube de Inmediato 🚀" : "Publish on OpenTube Instantly 🚀"}
          </button>
        </form>
      </div>
    </div>
  );
}
