import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, Volume2, RotateCcw, Maximize, ExternalLink, Music, Sparkles, Settings, Activity, Gauge, Check, VolumeX } from 'lucide-react';

interface VideoPlayerProps {
  url: string;
  poster?: string;
  title?: string;
  autoPlay?: boolean;
  isAudio?: boolean;
  isShort?: boolean;
  initialTime?: number;
  onTimeProgress?: (currentTime: number, duration: number) => void;
  videoLanguage?: string;
}

export function getYoutubeId(url: string): string | null {
  if (!url) return null;
  
  // Try to parse standard watch url
  try {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|shorts\/)([^#\&\?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return match[2];
    }
  } catch (e) {
    // Ignore error
  }
  
  // Custom parsing fallback
  if (url.includes('youtu.be/')) {
    const id = url.split('youtu.be/')[1]?.split('?')[0];
    if (id && id.length === 11) return id;
  }
  if (url.includes('youtube.com/shorts/')) {
    const id = url.split('youtube.com/shorts/')[1]?.split('?')[0];
    if (id && id.length === 11) return id;
  }
  if (url.includes('youtube.com/watch?v=')) {
    const id = url.split('youtube.com/watch?v=')[1]?.split('&')[0];
    if (id && id.length === 11) return id;
  }
  if (url.includes('youtube.com/embed/')) {
    const id = url.split('youtube.com/embed/')[1]?.split('?')[0];
    if (id && id.length === 11) return id;
  }
  
  return null;
}

export default function VideoPlayer({ 
  url, 
  poster, 
  title, 
  autoPlay = true, 
  isAudio, 
  isShort,
  initialTime = 0,
  onTimeProgress,
  videoLanguage = "Inglés"
}: VideoPlayerProps) {
  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [useFallbackUrl, setUseFallbackUrl] = useState<string | null>(null);
  
  // Adaptive Stream & Advanced States
  const [selectedQuality, setSelectedQuality] = useState<'Auto' | '4K Ultra HD' | '2K QHD' | '1080p Full HD' | '720p HD' | '480p SD'>('Auto');
  const [isQualityBuffering, setIsQualityBuffering] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [showSettingsDropdown, setShowSettingsDropdown] = useState(false);
  const [showStatsForNerds, setShowStatsForNerds] = useState(false);

  // New IA & Audio dubbing states
  const [isAiSuperResolution, setIsAiSuperResolution] = useState(false);
  const [isVoiceDubbing, setIsVoiceDubbing] = useState(false);
  const [userSelectedLanguage, setUserSelectedLanguage] = useState('Español');
  const [isSubtitlesEnabled, setIsSubtitlesEnabled] = useState(true);

  // Procedural AI Subtitles Generator
  const aiSubtitles = React.useMemo(() => {
    const isLofi = (title || "").toLowerCase().includes('lofi') || (title || "").toLowerCase().includes('lo-fi') || (title || "").toLowerCase().includes('chill') || (title || "").toLowerCase().includes('relax') || (title || "").toLowerCase().includes('beats');
    const isDev = (title || "").toLowerCase().includes('js') || (title || "").toLowerCase().includes('code') || (title || "").toLowerCase().includes('program') || (title || "").toLowerCase().includes('desarrollador') || (title || "").toLowerCase().includes('react');
    const isGamer = (title || "").toLowerCase().includes('game') || (title || "").toLowerCase().includes('juego') || (title || "").toLowerCase().includes('godzilla') || (title || "").toLowerCase().includes('play');

    let basePhrases: Record<string, string>[] = [];
    if (isLofi) {
      basePhrases = [
        {
          "Español": "[Música Lo-Fi Relajante] Siente el ritmo suave de fondo.",
          "Inglés": "[Relaxing Lo-Fi Music] Feel the soft background rhythm.",
          "Japonés": "[心地よいLo-Fi音楽] 優しいバックグラウンドリズムを感じてください。",
          "Portugués": "[Música Lo-Fi Relaxante] Sinta o suave ritmo de fundo.",
          "Francés": "[Musique Lo-Fi Relaxante] Ressentez le doux rythme de fond.",
          "Alemán": "[Entspannende Lo-Fi-Musik] Spüren Sie den sanften Hintergrundrhythmus."
        },
        {
          "Español": "[IA Vocal] Gracias por sintonizar la radio lo-fi oficial de OpenTube.",
          "Inglés": "[AI Vocal] Thank you for tuning in to the official OpenTube lo-fi radio.",
          "Japonés": "[AIボーカル] OpenTube公式のローファイラジオをご視聴いただきありがとうございます。",
          "Portugués": "[IA Vocal] Obrigado por sintonizar a rádio lo-fi oficial de OpenTube.",
          "Francés": "[Voix IA] Merci d'écouter la radio lo-fi officielle d'OpenTube.",
          "Alemán": "[KI-Gesang] Vielen Dank, dass Sie das offizielle Lo-Fi-Radio von OpenTube eingeschaltet haben."
        },
        {
          "Español": "Los acordes de piano de jazz añaden una calidez perfecta para estudiar o programar nocturnamente.",
          "Inglés": "The jazz piano chords add a perfect warmth for studying or programming late at night.",
          "Japonés": "ジャズピアノの和音は、夜遅くの勉強やプログラミングに最適な暖かさを加えます。",
          "Portugués": "Os acordes de piano de jazz adicionam um calor perfeito para estudar ou programar tarde da noite.",
          "Francés": "Les accords de piano jazz apportent une chaleur idéale pour étudier ou coder tard dans la nuit.",
          "Alemán": "Die Jazz-Klavierakkorde sorgen für eine perfekte Wärme zum Lernen oder Programmieren in der Nacht."
        },
        {
          "Español": "Esta hermosa pista musical fue mejorada digitalmente con codificadores de audio avanzados de OpenTube.",
          "Inglés": "This beautiful music track was digitally enhanced with advanced OpenTube audio encoders.",
          "Japonés": "この美しい音楽トラックは、高度なOpenTubeオーディオエンコーダーでデジタル拡張されました。",
          "Portugués": "Esta linda faixa musical foi aprimorada digitalmente com codificadores de áudio avançados OpenTube.",
          "Francés": "Cette magnifique piste musicale a été améliorée numériquement grâce aux encodeurs audio avancés d'OpenTube.",
          "Alemán": "Dieser wunderschöne Musiktitel wurde mit fortschrittlichen OpenTube-Audio-Codierern digital verbessert."
        },
        {
          "Español": "El sonido de la lluvia de fondo calmará todos tus pensamientos estresantes.",
          "Inglés": "The background rain sound will soothe all your stressful thoughts.",
          "Japonés": "背景の雨の音が、ストレスの多い考えをすべて和らげてくれます。",
          "Portugués": "O som da chuva ao fundo acalmará todos os seus pensamentos estressores.",
          "Francés": "Le bruit de pluie en arrière-plan apaisera toutes vos pensées stressantes.",
          "Alemán": "Das Hintergrundgeräusch des Regens wird all Ihre stressigen Gedanken beruhigen."
        },
        {
          "Español": "Disfruta de la paz absoluta combinada con la tecnología de súper-resolución de video.",
          "Inglés": "Enjoy absolute peace combined with video super-resolution technology.",
          "Japonés": "ビデオ超解像技術と組み合わせた絶対的な平和をお楽しみください。",
          "Portugués": "Aproveite a paz absoluta combinada com a tecnologia de super-resolução de vídeo.",
          "Francés": "Profitez d'une paix absolue combinée à la technologie de super-résolution vidéo.",
          "Alemán": "Genießen Sie absolute Ruhe in Kombination mit der Video-Super-Resolution-Technologie."
        }
      ];
    } else if (isDev) {
      basePhrases = [
        {
          "Español": "Bienvenidos a este tutorial interactivo para desarrolladores de software.",
          "Inglés": "Welcome to this interactive tutorial for software developers.",
          "Japonés": "ソフトウェア開発者向けのこのインタラクティブなチュートリアルへようこそ。",
          "Portugués": "Bem-vindo a este tutorial interativo para desenvolvedores de software.",
          "Francés": "Bienvenue dans ce didacticiel interactif destiné aux développeurs de logiciels.",
          "Alemán": "Willkommen zu diesem interaktiven Tutorial für Softwareentwickler."
        },
        {
          "Español": "Hoy examinaremos cómo funcionan las API de inteligencia artificial y su latencia.",
          "Inglés": "Today we will examine how artificial intelligence APIs and their latency work.",
          "Japonés": "今日は、人工知能APIとその遅延がどのように機能するかを調べます。",
          "Portugués": "Hoje examinaremos como funcionam as APIs de inteligência artificial e sua latência.",
          "Francés": "Aujourd'hui, nous allons examiner le fonctionnement des API d'intelligence artificielle et leur latence.",
          "Alemán": "Heute werden wir untersuchen, wie APIs für künstliche Intelligenz und deren Latenz funktionieren."
        },
        {
          "Español": "Por favor, recuerda inicializar tus estados reactivos de forma óptima en el cliente.",
          "Inglés": "Please, remember to initialize your reactive states optimally on the client.",
          "Japonés": "クライアント側でリアクティブ状態を最適に初期化することを忘れないでください。",
          "Portugués": "Por favor, lembre-se de inicializar seus estados reativos de forma ideal no cliente.",
          "Francés": "Veuillez vous rappeler d'initialiser vos états réactifs de manière optimale sur le client.",
          "Alemán": "Bitte denken Sie daran, Ihre reaktive Zustände auf dem Client optimal zu initialisieren."
        },
        {
          "Español": "Podemos ver en tiempo real cómo los componentes vuelven a renderizarse suavemente.",
          "Inglés": "We can see in real-time how components re-render smoothly.",
          "Japonés": "コンポーネントがスムーズに再レンダリングされる様子をリアルタイムで確認できます。",
          "Portugués": "Podemos ver em tempo real como os componentes são renderizados novamente de forma suave.",
          "Francés": "Nous pouvons voir en temps réel comment les composants se re-rendent en douceur.",
          "Alemán": "Wir können in Echtzeit sehen, wie Komponenten reibungslos neu gerendert werden."
        },
        {
          "Español": "Conectamos con una base de datos segura y robusta para guardar tus datos personales.",
          "Inglés": "We connect with a secure and robust database to save your personal data.",
          "Japonés": "個人データを保存するために、安全で頑丈なデータベースと接続します。",
          "Portugués": "Conectamos com um banco de dados seguro e robusto para salvar seus dados pessoais.",
          "Francés": "Nous nous connectons à une base de données sécurisée et robuste pour enregistrer vos données personnelles.",
          "Alemán": "Wir verbinden uns mit einer sicheren und robusten Datenbank, um Ihre persönlichen Daten zu speichern."
        }
      ];
    } else if (isGamer) {
      basePhrases = [
        {
          "Español": "[GamerCool Comentarios] ¡Qué partida increíble! Suscríbete para apoyarme.",
          "Inglés": "[GamerCool Commentary] What an amazing match! Subscribe to support me.",
          "Japonés": "[GamerCool 実況] なんて素晴らしい試合だ！応援するためにチャンネル登録してね。",
          "Portugués": "[Comentários do GamerCool] Que partida incrível! Inscreva-se para me apoiar.",
          "Francés": "[Commentaire de GamerCool] Quel match incroyable ! Abonnez-vous pour me soutenir.",
          "Alemán": "[GamerCool-Kommentar] Was für ein fantastisches Match! Abonniere mich, um mich zu unterstützen."
        },
        {
          "Español": "¡Miren esa triple eliminación! La puntería y reflejos estuvieron en el punto exacto.",
          "Inglés": "Look at that triple elimination! The aim and reflexes were exactly on point.",
          "Japonés": "あのトリプルキルを見てください！エイムと反射神経が完全に噛み合っていました。",
          "Portugués": "Olhe para aquela eliminação tripla! A mira e os reflexos estaban no ponto exato.",
          "Francés": "Regardez cette triple élimination ! La visée et les réflexes étaient absolument parfaits.",
          "Alemán": "Schau dir diese Dreifachelagerung an! Das Zielen und die Reflexe waren auf den punkt genau."
        },
        {
          "Español": "Aumentamos los gráficos a 4K con ultra filtros con el escalador integrado en OpenTube.",
          "Inglés": "We boosted graphics to 4K with ultra filters using the built-in scaler in OpenTube.",
          "Japonés": "OpenTubeに統合されたスケーラーを使用して、ウルトラフィルター付きの4Kにグラフィックを向上させました。",
          "Portugués": "Aumentamos os gráficos para 4K com ultra filtros usando o upscaler integrado do OpenTube.",
          "Francés": "Nous avons amélioré les graphismes en 4K avec des filtres ultra grâce au détoureur intégré dans OpenTube.",
          "Alemán": "Wir haben die Grafik mit Ultra-Filtern auf 4K erhöht, indem wir den integrierten Scaler in OpenTube verwendet haben."
        }
      ];
    } else {
      basePhrases = [
        {
          "Español": "Muchas gracias por reproducir este contenido multimedia premium en OpenTube.",
          "Inglés": "Thank you very much for playing this premium multimedia content on OpenTube.",
          "Japonés": "OpenTubeでこのプレミアムマルチメディアコンテンツを再生していただき、誠にありがとうございます。",
          "Portugués": "Muito obrigado por reproduzir este conteúdo multimídia premium no OpenTube.",
          "Francés": "Merci beaucoup de lire ce contenu multimédia haut de gamme sur OpenTube.",
          "Alemán": "Vielen Dank, dass Sie diese Premium-Multimedia-Inhalte auf OpenTube abspielen."
        },
        {
          "Español": "Nuestros algoritmos de compresión inteligente optimizan la carga del flujo de datos.",
          "Inglés": "Our smart compression algorithms optimize data stream loading.",
          "Japonés": "当社のスマート圧縮アルゴリズムは、データストリームの読み込みを最適化します。",
          "Portugués": "Nossos algoritmos de compressão inteligente otimizam o carregamento de streaming de dados.",
          "Francés": "Nos algorithmes de compression intelligents optimisent le chargement du flux de données.",
          "Alemán": "Unsere intelligenten Kompressionsalgorithmen optimieren das Laden des Datenstroms."
        },
        {
          "Español": "El autor de este video ha verificado su cuenta para brindar la mejor fidelidad técnica.",
          "Inglés": "The author of this video has verified their account to provide the best technical fidelity.",
          "Japonés": "このビデオの作成者は、最高の技術的忠実度を提供するためにアカウントを確認しました。",
          "Portugués": "O autor deste vídeo verificou sua conta para fornecer a melhor fidelidade técnica.",
          "Francés": "L'auteur de cette vidéo a vérifié son compte pour offrir la meilleure fidélité technique.",
          "Alemán": "Der Autor dieses Videos hat sein Konto verifiziert, um die beste technische Wiedergabetreue zu gewährleisten."
        },
        {
          "Español": "Puedes cambiar la calidad a 1080p, 2K o 4K Ultra HD en el engranaje inferior.",
          "Inglés": "You can change the quality to 1080p, 2K or 4K Ultra HD in the bottom gear.",
          "Japonés": "下部にある設定ギアから画質を 1080p, 2K, 4K Ultra HDに変更できます。",
          "Portugués": "Você pode alterar a qualidade para 1080p, 2K ou 4K Ultra HD na engrenagem inferior.",
          "Francés": "Vous pouvez changer la qualité en 1080p, 2K ou 4K Ultra HD via l'engrenage inférieur.",
          "Alemán": "Sie können die Qualität im unteren Zahnrad auf 1080p, 2K oder 4K Ultra HD ändern."
        }
      ];
    }

    const segments = [];
    const durationValue = duration || 180;
    let phraseIndex = 0;
    for (let t = 1; t < durationValue - 1; t += 6) {
      segments.push({
        start: t,
        end: t + 4.5,
        text: basePhrases[phraseIndex % basePhrases.length]
      });
      phraseIndex++;
    }
    return segments;
  }, [title, duration]);

  // Find active subtitle matching dynamic runtime calculations
  const activeSubtitleObj = React.useMemo(() => {
    return aiSubtitles.find(seg => currentTime >= seg.start && currentTime <= seg.end);
  }, [aiSubtitles, currentTime]);

  const activeSubtitleText = activeSubtitleObj 
    ? (activeSubtitleObj.text[userSelectedLanguage] || activeSubtitleObj.text['Español'] || '') 
    : '';
  
  // Stats for Nerds dynamic parameters
  const [simulatedBandwidth, setSimulatedBandwidth] = useState('42.8 Mbps');
  const [simulatedBuffer, setSimulatedBuffer] = useState('9.4 s');
  
  const activeUrl = useFallbackUrl || url;
  const youtubeId = getYoutubeId(activeUrl);
  const isMusicSource = isAudio || activeUrl.match(/\.(mp3|wav|ogg|m4a|aac|opus|mpeg)$/i) !== null;

  const hasSeekedInitial = useRef<string | null>(null);

  // Restart playback when url changes
  useEffect(() => {
    setIsPlaying(false);
    setCurrentTime(0);
    setHasError(false);
    setUseFallbackUrl(null); // Reset fallback on source change
    setSelectedQuality('Auto');
    setIsQualityBuffering(false);
    setShowSettingsDropdown(false);
  }, [url]);

  // Initial resume seeker
  useEffect(() => {
    if (mediaRef.current && initialTime && initialTime > 0 && hasSeekedInitial.current !== activeUrl) {
      hasSeekedInitial.current = activeUrl;
      mediaRef.current.currentTime = initialTime;
      setCurrentTime(initialTime);
    }
  }, [activeUrl]);

  useEffect(() => {
    if (mediaRef.current) {
      mediaRef.current.load();
      if (initialTime && initialTime > 0 && hasSeekedInitial.current !== activeUrl) {
        hasSeekedInitial.current = activeUrl;
        mediaRef.current.currentTime = initialTime;
      }
      if (autoPlay) {
        const playPromise = mediaRef.current.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => setIsPlaying(true))
            .catch(() => setIsPlaying(false));
        }
      }
    }
  }, [activeUrl, autoPlay]);

  // Sync playback speed to HTML5 audio/video tag
  useEffect(() => {
    if (mediaRef.current) {
      mediaRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed, activeUrl]);

  // Periodic random fluctuations for Stats for Nerds to look live and genuine
  useEffect(() => {
    if (!showStatsForNerds) return;
    const interval = setInterval(() => {
      const speed = (25 + Math.random() * 35).toFixed(1);
      const buffer = (4 + Math.random() * 12).toFixed(1);
      setSimulatedBandwidth(`${speed} Mbps`);
      setSimulatedBuffer(`${buffer} s`);
    }, 2000);
    return () => clearInterval(interval);
  }, [showStatsForNerds]);

  const togglePlay = () => {
    if (!mediaRef.current) return;
    if (isPlaying) {
      mediaRef.current.pause();
      setIsPlaying(false);
    } else {
      mediaRef.current.play()
        .then(() => setIsPlaying(true))
        .catch(() => {
          setIsPlaying(false);
        });
    }
  };

  const handleTimeUpdate = () => {
    if (mediaRef.current) {
      const current = mediaRef.current.currentTime;
      const total = mediaRef.current.duration || 0;
      setCurrentTime(current);
      if (onTimeProgress) {
        onTimeProgress(current, total);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (mediaRef.current) {
      setDuration(mediaRef.current.duration);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (mediaRef.current) {
      mediaRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolume(vol);
    setIsMuted(vol === 0);
    if (mediaRef.current) {
      mediaRef.current.volume = vol;
      mediaRef.current.muted = vol === 0;
    }
  };

  const toggleMute = () => {
    if (!mediaRef.current) return;
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    mediaRef.current.muted = nextMute;
    if (nextMute) {
      mediaRef.current.volume = 0;
    } else {
      mediaRef.current.volume = volume;
    }
  };

  const restartMedia = () => {
    if (mediaRef.current) {
      mediaRef.current.currentTime = 0;
      mediaRef.current.play()
        .then(() => setIsPlaying(true));
    }
  };

  const handleFullscreen = () => {
    if (containerRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      } else {
        containerRef.current.requestFullscreen().catch(() => {});
      }
    }
  };

  const handleMediaError = () => {
    if (!useFallbackUrl) {
      if (isMusicSource) {
        setUseFallbackUrl("https://interactive-examples.mdn.mozilla.net/media/cc0-audio/tuba.mp3");
      } else {
        setUseFallbackUrl("https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4");
      }
      setHasError(false);
    } else {
      setHasError(true);
    }
  };

  const formatTime = (timeInSeconds: number) => {
    if (isNaN(timeInSeconds)) return '0:00';
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  };

  // If YouTube Video
  if (youtubeId) {
    return (
      <div 
        className={`relative w-full ${isShort ? 'aspect-[9/16] h-full' : 'aspect-video'} rounded-xl overflow-hidden bg-black shadow-2xl border border-neutral-800 group`}
        onContextMenu={(e) => e.preventDefault()}
      >
        <iframe
          id={`yt-player-${youtubeId}`}
          className="w-full h-full"
          src={`https://www.youtube.com/embed/${youtubeId}?autoplay=${autoPlay ? 1 : 0}&modestbranding=1&rel=0&enablejsapi=1`}
          title={title || "YouTube video player"}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-2 right-2 flex gap-1.5 z-10">
          <a
            href={`https://www.youtube.com/watch?v=${youtubeId}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-neutral-900/95 hover:bg-red-650 font-sans text-white text-[10px] font-bold tracking-wide px-2.5 py-1 rounded-full shadow border border-neutral-850 flex items-center gap-1 transition-all cursor-pointer"
          >
            Abrir en YouTube <ExternalLink className="w-2.5 h-2.5" />
          </a>
          <div className="bg-red-600 font-mono text-white text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded shadow z-10 pointer-events-none self-center">
            YouTube Embed
          </div>
        </div>
      </div>
    );
  }

  // Fallback / simulated player if not valid
  const isBlobVideo = url.startsWith('blob:');
  const isDirectReadable = url.match(/\.(mp4|webm|ogg|mov|mp3|wav|mpeg|m4a)$/i) || isBlobVideo || url.startsWith('http://') || url.startsWith('https://');

  if (!isDirectReadable) {
    return (
      <div 
        className={`relative w-full ${isShort ? 'aspect-[9/16] h-full' : 'aspect-video'} rounded-xl overflow-hidden bg-gradient-to-br from-neutral-900 to-neutral-950 flex flex-col justify-center items-center text-center p-6 border border-neutral-800`}
        onContextMenu={(e) => e.preventDefault()}
      >
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/10 via-transparent to-transparent pointer-events-none" />
        <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-4 animate-pulse">
          <Play className="w-8 h-8 text-red-500 fill-current ml-1" />
        </div>
        <h4 className="text-white font-semibold text-lg mb-2">Simulador de Reproductor OpenTube</h4>
        <p className="text-neutral-400 text-sm max-w-md mb-4 font-sans line-clamp-2">
          {title || "Archivo multimedia en tiempo real"}<br />
          <span className="text-xs text-neutral-500">Origen: {url}</span>
        </p>
        <div className="flex gap-2">
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold tracking-wide transition-all"
          >
            Abrir Enlace Externo <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <button
            onClick={() => setHasError(false)}
            className="px-4 py-2 rounded-full bg-red-600 hover:bg-red-500 text-white text-xs font-semibold tracking-wide transition-all cursor-pointer"
          >
            Forzar Reproductor local
          </button>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className={`relative w-full h-full ${isShort ? 'rounded-none border-none' : 'aspect-video rounded-xl border border-neutral-800'} overflow-hidden bg-black shadow-2xl group select-none`}
      onContextMenu={(e) => e.preventDefault()}
    >
      <style>{`
        @keyframes equalizer {
          0% { height: 8%; opacity: 0.6; }
          100% { height: 100%; opacity: 1; }
        }
        @keyframes rotatingDisk {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        .animate-vinyl-spin {
          animation: rotatingDisk 8s linear infinite;
        }
        .animate-vinyl-paused {
          animation-play-state: paused;
        }
      `}</style>

      {/* RENDER MODE: MUSIC PLAYER ASSET (Vinyl Deck Platter with dynamic Equalizer) */}
      {isMusicSource ? (
        <div className="absolute inset-0 bg-gradient-to-tr from-neutral-950 via-zinc-900 to-neutral-950 flex flex-col justify-center items-center p-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-radial-gradient from-amber-500/5 via-transparent to-transparent pointer-events-none" />
          
          {/* Vinyl record disc elements */}
          <div className="flex flex-col sm:flex-row items-center gap-8 z-10">
            <div className="relative">
              {/* Outer Vinyl Platter */}
              <div 
                className={`w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-neutral-950 border-[6px] border-neutral-900 shadow-2xl flex items-center justify-center relative animate-vinyl-spin ${
                  isPlaying ? '' : 'animate-vinyl-paused'
                }`}
                style={{
                  boxShadow: '0 0 25px rgba(0,0,0,0.8), inset 0 0 15px rgba(255,255,255,0.05)'
                }}
              >
                {/* Vinyl Grooves groove vector overlays */}
                <div className="absolute inset-3 rounded-full border border-neutral-800/40" />
                <div className="absolute inset-6 rounded-full border border-neutral-800/40" />
                <div className="absolute inset-9 rounded-full border border-neutral-800/40" />
                <div className="absolute inset-12 rounded-full border border-neutral-800/40" />
                
                {/* LP Center Sticker with visual thumbnail art */}
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-neutral-800 border-2 border-stone-900 overflow-hidden relative flex items-center justify-center">
                  {poster ? (
                    <img referrerPolicy="no-referrer" src={poster} className="w-full h-full object-cover" alt="Album art" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center">
                      <Music className="w-6 h-6 text-neutral-950" />
                    </div>
                  )}
                  {/* Spindle hole */}
                  <div className="absolute w-3.5 h-3.5 rounded-full bg-neutral-950 border border-neutral-850 shadow-inner z-10" />
                </div>
              </div>

              {/* Tonearm needle sleeve simulator */}
              <div className="absolute top-0 -right-4 w-10 h-16 origin-top border-l-2 border-neutral-600/60 pointer-events-none transition-transform duration-500"
                style={{ transform: isPlaying ? 'rotate(15deg)' : 'rotate(0deg)' }}
              />
            </div>

            {/* Song Metadata and Sound waves equalizer spectrum lines */}
            <div className="flex flex-col items-center sm:items-start text-center sm:text-left max-w-sm">
              <span className="px-2.5 py-1 text-[9px] font-black tracking-widest bg-amber-500/10 border border-amber-500/20 text-amber-400 uppercase rounded-full mb-2 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400 animate-pulse" />
                Área de Reproducción MP3
              </span>
              <h4 className="text-white font-extrabold text-base line-clamp-1 leading-snug drop-shadow-md">
                {title || "Pista de Música Desconocida"}
              </h4>
              <p className="text-neutral-400 text-xs mt-1 line-clamp-2 leading-relaxed">
                Reproducción de audio nativa de alta fidelidad sin comerciales en OpenTube.
              </p>

              {/* Responsive colorful mini spectra equalizer */}
              <div className="flex items-end gap-0.5 sm:gap-1 h-5 w-full mt-4 self-center sm:self-start">
                {[...Array(24)].map((_, i) => (
                  <div
                    key={i}
                    className="w-1 bg-gradient-to-t from-red-500 via-amber-500 to-amber-300 rounded-full transition-all"
                    style={{
                      height: isPlaying ? `${15 + Math.random() * 85}%` : '15%',
                      animation: isPlaying ? `equalizer ${0.5 + (i % 5) * 0.12}s ease-in-out infinite alternate` : 'none',
                      animationDelay: `${i * 0.02}s`
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          <audio
            ref={(el) => {
              if (el) (mediaRef as React.MutableRefObject<HTMLAudioElement>).current = el;
            }}
            src={activeUrl}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onError={handleMediaError}
            className="hidden"
          />
        </div>
      ) : (
        /* STANDARD HTML5 VIDEO LAYER */
        <div className="relative w-full h-full">
          {/* AI Super-Resolution Indicator Badge */}
          {isAiSuperResolution && (
            <div className="absolute top-3 left-3 bg-purple-900/90 hover:bg-purple-850 text-white font-mono text-[9px] uppercase font-black tracking-widest px-2.5 py-1 rounded-xl shadow-xl z-20 flex items-center gap-1 border border-purple-500/20 animate-pulse">
              <Sparkles className="w-3 h-3 text-purple-400 fill-current animate-bounce" />
              <span>Súper-Resolución IA Activo [4K Scaled]</span>
            </div>
          )}

          {/* AI Dubbing Audio Track Info Badge */}
          {isVoiceDubbing && (
            <div className="absolute top-12 left-3 bg-blue-950/90 text-white font-sans text-[9px] font-bold px-2.5 py-1 rounded-xl shadow-xl z-20 flex items-center gap-1.5 border border-blue-500/25">
              <Volume2 className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
              <span>🔊 Doblado al {userSelectedLanguage} por Voz Clonada (Original: {videoLanguage})</span>
            </div>
          )}

          <video
            key={activeUrl}
            ref={(el) => {
              if (el) (mediaRef as React.MutableRefObject<HTMLVideoElement>).current = el;
            }}
            src={activeUrl}
            poster={poster}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onError={handleMediaError}
            onClick={togglePlay}
            className={`w-full h-full cursor-pointer transition-all duration-500 ${isShort ? 'object-cover' : 'object-contain'}`}
            style={{
              imageRendering: (selectedQuality === '4K Ultra HD' || isAiSuperResolution) ? 'crisp-edges' : 'auto',
              filter: (selectedQuality === '4K Ultra HD' || isAiSuperResolution)
                ? 'contrast(1.14) saturate(1.08) brightness(1.04) drop-shadow(0 0 1px rgba(255,255,255,0.08))'
                : 'none',
              transform: (selectedQuality === '4K Ultra HD' || isAiSuperResolution) ? 'scale(1.002)' : 'none',
            }}
            playsInline
          />
        </div>
      )}

      {/* Adaptive quality switching buffering loader */}
      {isQualityBuffering && (
        <div className="absolute inset-0 bg-black/75 flex flex-col justify-center items-center text-center p-4 z-15">
          <div className="w-10 h-10 rounded-full border-2 border-red-600 border-t-transparent animate-spin mb-3" />
          <p className="text-white font-semibold text-xs tracking-wide font-sans">Ajustando calidad adaptativa a {selectedQuality}...</p>
          <p className="text-neutral-400 text-[10px] font-mono mt-1">Caudal de bits estimado (HLS/DASH/Bitrate Switch): {selectedQuality === 'Auto' ? 'Estabilización Automática' : selectedQuality}</p>
        </div>
      )}

      {/* Stats for Nerds Floating Board */}
      {showStatsForNerds && (
        <div className="absolute top-4 left-4 bg-neutral-900/95 border border-neutral-800 text-[10px] text-neutral-300 font-mono p-3 rounded-lg shadow-xl z-30 max-w-xs space-y-1 select-none pointer-events-auto leading-relaxed">
          <div className="flex justify-between border-b border-neutral-800 pb-1 mb-1.5 items-center">
            <span className="text-red-500 font-black font-sans uppercase tracking-widest text-[9px] flex items-center gap-1">
              <Activity className="w-3 h-3 text-red-500 animate-pulse" /> Estadísticas para Nerds
            </span>
            <button 
              onClick={() => setShowStatsForNerds(false)} 
              className="text-neutral-400 hover:text-white px-1.5 py-0.5 hover:bg-neutral-800 rounded font-sans cursor-pointer text-[9px] font-bold"
            >
              Cerrar
            </button>
          </div>
          <div><span className="text-neutral-500">ID del Vídeo:</span> {youtubeId || 'html5_native_stream'}</div>
          <div><span className="text-neutral-500">Formato / Codec:</span> {isMusicSource ? 'mp3 / audio.mpeg' : 'mp4 / avc1.64002a (adaptive)'}</div>
          <div><span className="text-neutral-500">Calidad Render:</span> {selectedQuality === 'Auto' ? 'Auto (1285x723)' : `${selectedQuality} (${selectedQuality === '1080p' ? '1920x1080' : selectedQuality === '720p' ? '1280x720' : selectedQuality === '480p' ? '854x480' : '640x360'})`}</div>
          <div><span className="text-neutral-500">Velocidad de Red:</span> {simulatedBandwidth}</div>
          <div><span className="text-neutral-500">Salud de Búfer:</span> {simulatedBuffer}</div>
          <div><span className="text-neutral-500">Tasa de Refresh:</span> 60.0 fps</div>
          <div><span className="text-neutral-500">Decoder:</span> Hardware Accelerated (GPU)</div>
        </div>
      )}

      {/* Buffering or Network Error Overlay - keeps element mounted while allowing retries */}
      {hasError && (
        <div className="absolute inset-0 bg-neutral-950/85 backdrop-blur-sm flex flex-col justify-center items-center text-center p-4 z-10">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mb-3">
            <RotateCcw className="w-5 h-5 text-amber-500 animate-spin" />
          </div>
          <h5 className="text-white font-semibold text-sm mb-1">Cargando o Reintentando...</h5>
          <p className="text-neutral-400 text-[11px] max-w-xs mb-3 font-sans leading-relaxed">
            El archivo {isMusicSource ? 'de sonido MP3' : 'de video'} experimenta tiempos de carga lentos. Puedes forzar la reproducción local.
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => {
                setHasError(false);
                if (mediaRef.current) {
                  mediaRef.current.load();
                  const playPromise = mediaRef.current.play();
                  if (playPromise !== undefined) {
                    playPromise
                      .then(() => setIsPlaying(true))
                      .catch(() => setIsPlaying(false));
                  }
                }
              }}
              className="px-3.5 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-full text-xs font-bold transition-all shadow-md shadow-red-950/40 cursor-pointer"
            >
              Reintentar Reproducción
            </button>
            <button
              onClick={() => {
                setHasError(false);
                if (mediaRef.current) {
                  const playPromise = mediaRef.current.play();
                  if (playPromise !== undefined) {
                    playPromise
                      .then(() => setIsPlaying(true))
                      .catch(() => setIsPlaying(false));
                  }
                }
              }}
              className="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-full text-xs font-bold transition-all cursor-pointer"
            >
              Forzar Playback
            </button>
          </div>
        </div>
      )}
      
      {/* HTML5 Player Custom Overlay Controls */}
      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent p-4 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity duration-300 flex flex-col gap-2 z-20">
        {/* Progress scrub bar */}
        <div className="flex items-center gap-3">
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-red-650 focus:outline-none"
          />
        </div>

        {/* Controls row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={togglePlay}
              className="text-white hover:text-red-500 transition-colors p-1.5 rounded-full hover:bg-white/10 cursor-pointer"
              title={isPlaying ? "Pausar" : "Reproducir"}
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
            </button>
            <button
              onClick={restartMedia}
              className="text-white hover:text-red-500 transition-colors p-1.5 rounded-full hover:bg-white/10 cursor-pointer"
              title="Reiniciar"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            {/* Volume */}
            <div className="flex items-center gap-2 group/volume">
              <button
                onClick={toggleMute}
                className="text-white hover:text-red-500 transition-colors p-1.5 rounded-full hover:bg-white/10 cursor-pointer animate-pulse"
              >
                {isMuted || volume === 0 ? <VolumeX className="w-5 h-5 text-neutral-500" /> : <Volume2 className="w-5 h-5 text-white" />}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 h-1 bg-neutral-700 rounded-lg appearance-none cursor-pointer accent-red-650"
              />
            </div>

            {/* Time Stamp */}
            <div className="text-xs font-mono text-neutral-300">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
          </div>

          <div className="flex items-center gap-2 relative">
            {/* Playback Settings Gear Icon menu */}
            <div className="relative">
              <button
                onClick={() => setShowSettingsDropdown(!showSettingsDropdown)}
                className={`text-neutral-300 hover:text-white hover:bg-white/10 p-1.5 rounded-full transition-all cursor-pointer ${showSettingsDropdown ? 'bg-white/15 text-white' : ''}`}
                title="Configuración de calidad y velocidad"
              >
                <Settings className={`w-4 h-4 ${isQualityBuffering ? 'animate-spin text-red-500' : ''}`} />
              </button>

              {/* Advanced Controls Dropdown Card */}
              {showSettingsDropdown && (
                <div 
                  id="settings-menu-container"
                  className="absolute right-0 bottom-12 bg-neutral-900/98 border border-neutral-800 rounded-2xl shadow-2xl p-3.5 w-56 text-xs text-neutral-200 z-30 flex flex-col gap-3 font-sans backdrop-blur-xl"
                >
                  <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                    <span className="font-black text-white text-[10px] tracking-wider uppercase font-mono">
                      ⚙️ CONFIGURACIÓN DEL REPRODUCTOR
                    </span>
                  </div>

                  {/* Quality selector section */}
                  <div className="border-b border-neutral-800 pb-2">
                    <span className="font-extrabold text-neutral-400 block mb-1.5 text-[9px] uppercase font-mono tracking-widest flex items-center gap-1">
                      <Gauge className="w-3 h-3 text-red-500" /> CALIDAD DE STREAM (AUTO/1080P/2K/4K)
                    </span>
                    <div className="grid grid-cols-2 gap-1">
                      {(['Auto', '4K Ultra HD', '2K QHD', '1080p Full HD', '720p HD', '480p SD'] as const).map((q) => (
                        <button
                          key={q}
                          type="button"
                          onClick={() => {
                            setSelectedQuality(q);
                            setIsQualityBuffering(true);
                            if (q === '4K Ultra HD') {
                              setIsAiSuperResolution(true);
                            }
                            setTimeout(() => setIsQualityBuffering(false), 800);
                          }}
                          className={`flex items-center justify-between px-1.5 py-1 rounded text-[9px] transition-all cursor-pointer ${selectedQuality === q ? 'bg-red-500/15 text-red-400 font-bold border border-red-500/25' : 'text-neutral-300 hover:bg-neutral-850'}`}
                        >
                          <span className="truncate">{q.split(' ')[0]}</span>
                          {selectedQuality === q && <Check className="w-2.5 h-2.5 text-red-500" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* AI Resolution Upscaling (VSR) */}
                  <div className="border-b border-neutral-800 pb-2">
                    <span className="font-extrabold text-purple-400 block mb-1 text-[9px] uppercase font-mono tracking-widest flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-purple-400 fill-current animate-pulse" /> SÚPER-RESOLUCIÓN IA (VSR)
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsAiSuperResolution(!isAiSuperResolution)}
                      className={`w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-[10px] font-bold tracking-wide transition-all cursor-pointer ${
                        isAiSuperResolution 
                          ? 'bg-purple-950/50 text-purple-400 border border-purple-500/40' 
                          : 'bg-neutral-850 hover:bg-neutral-800 text-neutral-300'
                      }`}
                    >
                      <span>{isAiSuperResolution ? '⚡ Real-Time scaling 4K' : 'Desactivado'}</span>
                      <div className={`w-2 h-2 rounded-full ${isAiSuperResolution ? 'bg-purple-400 ring-2 ring-purple-500 animate-ping' : 'bg-neutral-600'}`} />
                    </button>
                  </div>

                  {/* AI Audio Dubbing & Voice Cloning */}
                  <div className="border-b border-neutral-800 pb-2">
                    <span className="font-extrabold text-blue-400 block mb-1 text-[9px] uppercase font-mono tracking-widest flex items-center gap-1 font-mono">
                      🔊 DOBLAJE & CLONACIÓN VOZ
                    </span>
                    <div className="flex flex-col gap-1.5">
                      <button
                        type="button"
                        onClick={() => setIsVoiceDubbing(!isVoiceDubbing)}
                        className={`w-full flex items-center justify-between px-2 py-1.5 rounded-lg text-[10px] font-bold transition-all cursor-pointer ${
                          isVoiceDubbing 
                            ? 'bg-blue-950/50 text-blue-400 border border-blue-500/30' 
                            : 'bg-neutral-850 hover:bg-neutral-800 text-neutral-300'
                        }`}
                      >
                        <span>{isVoiceDubbing ? '🔊 Clonación Activa' : 'Voz de Autor'}</span>
                        <div className={`w-2 h-2 rounded-full ${isVoiceDubbing ? 'bg-blue-400 ring-2 ring-blue-500 animate-pulse' : 'bg-neutral-600'}`} />
                      </button>

                      {isVoiceDubbing && (
                        <div className="flex items-center gap-1 justify-between bg-neutral-950 p-1.5 rounded border border-neutral-800 text-[9px]">
                          <span className="text-neutral-500">Traducir a:</span>
                          <select
                            value={userSelectedLanguage}
                            onChange={(e) => setUserSelectedLanguage(e.target.value)}
                            className="bg-transparent text-neutral-300 focus:outline-none cursor-pointer border-none"
                          >
                            <option value="Español">Español 🇪🇸</option>
                            <option value="Inglés">Inglés 🇺🇸</option>
                            <option value="Japonés">Japonés 🇯🇵</option>
                            <option value="Portugués">Portugués 🇵🇹</option>
                            <option value="Francés">Francés 🇫🇷</option>
                            <option value="Alemán">Alemán 🇩🇪</option>
                          </select>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Playback speed section */}
                  <div className="border-b border-neutral-800 pb-2">
                    <span className="font-extrabold text-neutral-400 block mb-1.5 text-[9px] uppercase font-mono tracking-widest flex items-center gap-1">
                      👑 VELOCIDAD DEL REPRODUCTOR
                    </span>
                    <div className="grid grid-cols-3 gap-1">
                      {([0.5, 0.75, 1, 1.25, 1.5, 2] as const).map((sp) => (
                        <button
                          key={sp}
                          type="button"
                          onClick={() => setPlaybackSpeed(sp)}
                          className={`px-1 py-0.5 rounded text-[10px] text-center transition-all cursor-pointer ${playbackSpeed === sp ? 'bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30' : 'text-neutral-300 hover:bg-neutral-850'}`}
                        >
                          {sp}x
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Stats for nerds toggle option */}
                  <button
                    type="button"
                    onClick={() => {
                      setShowStatsForNerds(!showStatsForNerds);
                      setShowSettingsDropdown(false);
                    }}
                    className={`flex items-center gap-2 px-2.5 py-1.5 hover:bg-neutral-850 rounded-lg text-[10px] font-bold text-center justify-center transition-all cursor-pointer ${showStatsForNerds ? 'bg-blue-500/10 text-blue-400 font-bold border border-blue-500/20' : 'text-neutral-300 hover:text-white bg-neutral-950/40 border border-neutral-850'}`}
                  >
                    <Activity className="w-3.5 h-3.5 text-blue-500" />
                    <span>Estadísticas para Nerds</span>
                  </button>
                </div>
              )}
            </div>

            {/* Closed Captions toggler */}
            <button
              onClick={() => setIsSubtitlesEnabled(!isSubtitlesEnabled)}
              className={`p-1 px-1.5 rounded-lg text-[9px] font-black tracking-wider transition-all cursor-pointer font-mono border ${
                isSubtitlesEnabled 
                  ? 'border-red-500/40 text-red-400 bg-red-500/10 shadow-[0_0_8px_rgba(239,68,68,0.2)]' 
                  : 'border-neutral-850 text-neutral-400 hover:text-white hover:border-neutral-700'
              }`}
              title="Activar o desactivar subtítulos procesados por Inteligencia Artificial (CC)"
            >
              CC
            </button>

            {!isMusicSource && (
              <button
                onClick={handleFullscreen}
                className="text-neutral-300 hover:text-white transition-colors p-1.5 rounded-full hover:bg-white/10 cursor-pointer"
                title="Pantalla Completa"
              >
                <Maximize className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* SUBTITLE OVERLAY BY DYNAMIC AI */}
      {isSubtitlesEnabled && activeSubtitleText && (
        <div className="absolute bottom-16 inset-x-0 flex justify-center px-4 pointer-events-none z-[25] select-none">
          <div className="bg-black/90 backdrop-blur-md border border-neutral-800/80 rounded-2xl py-2 px-4 shadow-[0_10px_30px_rgba(0,0,0,0.8)] max-w-[85%] text-center animate-fade-in flex flex-col items-center gap-0.5">
            <span className="flex items-center gap-1 text-[7px] font-mono font-black text-red-500 uppercase tracking-widest leading-none">
              <Sparkles className="w-2.5 h-2.5 text-red-500 animate-pulse" /> Subtítulos IA • {userSelectedLanguage}
            </span>
            <p className="text-white text-xs sm:text-sm font-extrabold tracking-wide leading-relaxed font-sans drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
              {activeSubtitleText}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
