import React from 'react';

interface VerifiedBadgeProps {
  type?: 'classic' | 'crown' | 'star' | 'shield' | 'new-member';
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function VerifiedBadge({ type = 'classic', className = '', size = 'md' }: VerifiedBadgeProps) {
  const sizeClasses = {
    sm: 'w-3.5 h-3.5 text-[11px]',
    md: 'w-4.5 h-4.5 text-[14px]',
    lg: 'w-5.5 h-5.5 text-[18px]'
  };

  const roundedSizes = {
    sm: 'h-3.5',
    md: 'h-4.5',
    lg: 'h-5.5'
  };

  const currentSize = sizeClasses[size];

  // If star option, we render the glowing ✦ symbol
  if (type === 'star') {
    return (
      <span 
        className={`inline-flex items-center justify-center font-bold text-amber-400 select-none filter drop-shadow-[0_0_4px_rgba(245,158,11,0.9)] animate-pulse shrink-0 ${currentSize} ${className}`}
        title="Insignia Destellante VIP (✦ Creador)"
        style={{ textShadow: '0 0 6px rgb(245, 158, 11)' }}
      >
        ✦
      </span>
    );
  }

  const isNewMember = type === 'new-member';

  // Classic or fallback options render the official jagged rosette matching the user's uploaded image exactly!
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={`${roundedSizes[size]} aspect-square shrink-0 filter ${isNewMember ? 'drop-shadow-[0_0_2px_rgba(163,163,163,0.5)]' : 'drop-shadow-[0_0_2px_rgba(29,155,240,0.5)]'} ${className}`}
      title={isNewMember ? "Insignia de Nuevo Miembro (Tick Gris)" : "Insignia Oficial de Verificado (Blue Check)"}
    >
      {/* Hand-crafted jagged rosette shape representing the uploaded image precisely */}
      <path 
        d="M22.5 12.5c0-1.43-.88-2.67-2.19-3.34.46-1.39.17-2.9-.81-3.88s-2.49-1.27-3.88-.81c-.67-1.31-1.91-2.19-3.34-2.19s-2.67.88-3.34 2.19c-1.39-.46-2.9-.17-3.88.81s-1.27 2.49-.81 3.88C2.88 9.83 2 11.07 2 12.5s.88 2.67 2.19 3.34c-.46 1.39-.17 2.9.81 3.88s2.49 1.27 3.88.81c.67 1.31 1.91 2.19 3.34 2.19s2.67-.88 3.34-2.19c1.39.46 2.9.17 3.88-.81s1.27-2.49.81-3.88c1.31-.67 2.19-1.91 2.19-3.34z" 
        fill={isNewMember ? "#A3A3A3" : "#1D9BF0"} 
      />
      {/* Impeccable white verification checkmark keylines */}
      <path 
        d="M9.7 14.3l-3-3 1.4-1.4 1.6 1.6 4.8-4.8 1.4 1.4-6.2 6.2z" 
        fill="white" 
      />
    </svg>
  );
}

