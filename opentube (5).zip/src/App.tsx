import React, { useState, useEffect } from 'react';
import { 
  ThumbsUp, 
  ThumbsDown, 
  MessageSquare, 
  BadgeCheck, 
  Send, 
  Trash2, 
  Play, 
  Sparkles, 
  Heart,
  Share2,
  ChevronUp,
  ChevronDown,
  Plus,
  Tv,
  Users,
  Compass,
  Radio,
  X,
  Maximize,
  Music
} from 'lucide-react';

// Components
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import VideoCard, { formatDuration, formatViews } from './components/VideoCard';
import VideoPlayer from './components/VideoPlayer';
import UploadModal from './components/UploadModal';
import ProfileSettings from './components/ProfileSettings';
import VerifiedBadge from './components/VerifiedBadge';

// Toxicity Moderator & Procedural Generator
import { moderateComment } from './lib/toxicityModerator';
import { generateProceduralVideo, generateProceduralShort } from './lib/proceduralGenerator';
import { detectLanguage, Language, TRANSLATIONS } from './lib/translations';

// Database & Blob URL Manager
import { saveVideoToIndexedDB, deleteVideoFromIndexedDB, loadVideosFromIndexedDB } from './lib/db';
import { blobManager } from './lib/blobManager';

// Types
import { Video, Post, Comment, UserProfile } from './types';

// Mock / Initial Data
import { DEFAULT_USER, INITIAL_VIDEOS, INITIAL_SHORTS, INITIAL_POSTS } from './data/defaultVideos';

export default function App() {
  // --- CORE SYSTEM STATES ---
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('opentube_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [videos, setVideos] = useState<Video[]>(() => {
    const saved = localStorage.getItem('opentube_videos');
    const parsed: Video[] = saved ? JSON.parse(saved) : [];
    // Ensure we filter out any default or procedurally generated old sandbox videos
    return parsed.filter((v: Video) => !v.id.startsWith('procedural-'));
  });

  // Playback Progress Resume state
  const [playbackProgress, setPlaybackProgress] = useState<Record<string, { currentTime: number; duration: number; timestamp: number }>>(() => {
    const saved = localStorage.getItem('opentube_progress');
    return saved ? JSON.parse(saved) : {};
  });

  // Infinite Scroll state variables
  const [displayedLimit, setDisplayedLimit] = useState(6);
  const [isInfiniteLoading, setIsInfiniteLoading] = useState(false);
  const [proceduralCount, setProceduralCount] = useState(0);

  // local AI Toxicity warnings modal state
  const [toxicityModal, setToxicityModal] = useState<{
    text: string;
    score: number;
    violations: string[];
    originalText: string;
    suggestedPoliteText: string;
    onSubmitOriginal: () => void;
    onSubmitPolite: () => void;
  } | null>(null);

  const [posts, setPosts] = useState<Post[]>(() => {
    const saved = localStorage.getItem('opentube_posts');
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });

  const [activeTab, setActiveTab] = useState<'home' | 'history' | 'shorts' | 'community' | 'profile'>('home');
  const [showHomeWelcome, setShowHomeWelcome] = useState(true);
  const [showCommunityWelcome, setShowCommunityWelcome] = useState(true);
  const [scheduledVideoIds, setScheduledVideoIds] = useState<Record<string, number>>({});

  // Banning system
  const [bannedUntil, setBannedUntil] = useState<number | null>(() => {
    const saved = localStorage.getItem('opentube_banned_until');
    return saved ? parseInt(saved) : null;
  });
  const [banTimeRemaining, setBanTimeRemaining] = useState<number>(0);

  // Audio remixing state
  const [remixModalVideo, setRemixModalVideo] = useState<Video | null>(null);

  const [lang, setLang] = useState<Language>(detectLanguage());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  
  // Reports and Moderation blocks
  const [reportingVideo, setReportingVideo] = useState<Video | null>(null);
  const [selectedReportCategory, setSelectedReportCategory] = useState<string>('Infracción de derechos de autor (Copyright)');
  const [reportDescription, setReportDescription] = useState<string>('');
  const [reportSuccessModal, setReportSuccessModal] = useState<boolean>(false);
  
  const [commentBlockedModal, setCommentBlockedModal] = useState<{
    originalText: string;
    warningCount: number;
    reason: string;
  } | null>(null);

  // Video navigation & display state
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  
  // Modal toggle state
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadMode, setUploadMode] = useState<'video' | 'short'>('video');

  // Comments / Interactives Inputs
  const [videoComment, setVideoComment] = useState('');
  const [postCommentInputs, setPostCommentInputs] = useState<Record<string, string>>({});
  const [newPostText, setNewPostText] = useState('');

  // Active Short Navigator State
  const [currentShortIndex, setCurrentShortIndex] = useState(0);
  const [isShortCommentsOpen, setIsShortCommentsOpen] = useState(false);
  const [shortCommentText, setShortCommentText] = useState('');

  // Block right-click context menu globally across entire OpenTube layout per user request
  useEffect(() => {
    const blockContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };
    document.addEventListener('contextmenu', blockContextMenu);
    return () => {
      document.removeEventListener('contextmenu', blockContextMenu);
    };
  }, []);

  // Async load of custom videos from Dexie IndexedDB to avoid LocalStorage overflow and cache leak reloads
  useEffect(() => {
    async function initDB() {
      const dbVids = await loadVideosFromIndexedDB((id, url) => {
        blobManager.register(id, url);
      });
      if (dbVids.length > 0) {
        setVideos(prev => {
          const dbIds = new Set(dbVids.map(v => v.id));
          const filteredPrev = prev.filter(v => !dbIds.has(v.id));
          return [...dbVids, ...filteredPrev];
        });
      }
    }
    initDB();

    // Clean Unmounting / Garbage collection on exit
    return () => {
      blobManager.purgeAll();
    };
  }, []);

  // Ban timer countdown ticking effect
  useEffect(() => {
    if (bannedUntil === null) {
      setBanTimeRemaining(0);
      return;
    }

    const interval = setInterval(() => {
      const now = Date.now();
      if (now >= bannedUntil) {
        setBannedUntil(null);
        setBanTimeRemaining(0);
        localStorage.removeItem('opentube_banned_until');
        clearInterval(interval);
      } else {
        setBanTimeRemaining(Math.ceil((bannedUntil - now) / 1000));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [bannedUntil]);

  const handleTabChange = (tab: 'home' | 'history' | 'shorts' | 'community' | 'profile') => {
    // Dismiss banners when migrating tabs
    if (activeTab === 'home' && tab !== 'home') {
      setShowHomeWelcome(false);
    }
    if (activeTab === 'community' && tab !== 'community') {
      setShowCommunityWelcome(false);
    }
    if (tab === 'shorts' || tab === 'history' || tab === 'community' || tab === 'profile') {
      setShowHomeWelcome(false);
    }
    if (tab === 'shorts' || tab === 'history' || tab === 'home' || tab === 'profile') {
      setShowCommunityWelcome(false);
    }
    setSelectedVideo(null);
    setActiveTab(tab);
  };

  // Sync to local data persistence with try-catch blocks to prevent quota exceeded crashes
  useEffect(() => {
    try {
      localStorage.setItem('opentube_user', JSON.stringify(currentUser));
    } catch (e) {
      console.warn("Storage quota exceeded for opentube_user:", e);
    }
  }, [currentUser]);

  useEffect(() => {
    try {
      localStorage.setItem('opentube_videos', JSON.stringify(videos));
    } catch (e) {
      console.warn("Storage quota exceeded for opentube_videos:", e);
    }
  }, [videos]);

  useEffect(() => {
    try {
      localStorage.setItem('opentube_posts', JSON.stringify(posts));
    } catch (e) {
      console.warn("Storage quota exceeded for opentube_posts:", e);
    }
  }, [posts]);

  // Sync playback progress history
  useEffect(() => {
    try {
      localStorage.setItem('opentube_progress', JSON.stringify(playbackProgress));
    } catch (e) {
      console.warn("Storage quota exceeded for opentube_progress:", e);
    }
  }, [playbackProgress]);

  // No prepopulation of default or procedural videos per user request.

  // Update progress registry callbacks
  const handleUpdatePlaybackProgress = (videoId: string, currentTime: number, duration: number) => {
    if (duration <= 0) return;
    setPlaybackProgress(prev => ({
      ...prev,
      [videoId]: {
        currentTime,
        duration,
        timestamp: Date.now()
      }
    }));
  };

  // Infinite Scroll lazy loading more videos from existing uploaded list
  const handleLoadMoreVideos = () => {
    if (isInfiniteLoading) return;
    const filteredStandardVideos = videos.filter(v => !v.isShort && (selectedCategory === 'Todos' || v.category === selectedCategory));
    if (displayedLimit >= filteredStandardVideos.length) return;

    setIsInfiniteLoading(true);
    setTimeout(() => {
      setDisplayedLimit(prev => prev + 4);
      setIsInfiniteLoading(false);
    }, 800); 
  };

  // Scroll detection trigger
  useEffect(() => {
    const handleScroll = () => {
      if (activeTab !== 'home' || selectedVideo) return;
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 160) {
        handleLoadMoreVideos();
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [selectedVideo, activeTab, isInfiniteLoading, videos, selectedCategory, displayedLimit]);

  // Synchronize creator details for comments and self-published posts dynamically
  const updateCreatorDetailsOnContent = (nextProfile: UserProfile) => {
    // Sync videos published by current user
    setVideos(prev => prev.map(v => {
      if (v.authorName === currentUser.name || v.authorName === nextProfile.name) {
        return {
          ...v,
          authorName: nextProfile.name,
          authorAvatar: nextProfile.avatarUrl,
        };
      }
      return v;
    }));

    // Sync posts/comments published by current user
    setPosts(prev => prev.map(p => {
      let isSelfPost = p.authorName === currentUser.name || p.authorName === nextProfile.name;
      const updatedComments = p.comments.map(c => {
        if (c.author === currentUser.name || c.author === nextProfile.name) {
          return {
            ...c,
            author: nextProfile.name,
            avatarUrl: nextProfile.avatarUrl
          };
        }
        return c;
      });

      return {
        ...p,
        authorName: isSelfPost ? nextProfile.name : p.authorName,
        authorAvatar: isSelfPost ? nextProfile.avatarUrl : p.authorAvatar,
        comments: updatedComments
      };
    }));
  };

  const handleUpdateUser = (updatedProfile: UserProfile) => {
    updateCreatorDetailsOnContent(updatedProfile);
    setCurrentUser(updatedProfile);
  };

  // --- LIKES & DISLIKES TRIGGERS ---
  const handleVote = (id: string, voteType: 'like' | 'dislike') => {
    const updated = videos.map(vid => {
      if (vid.id !== id) return vid;
      
      let likesChange = 0;
      let dislikesChange = 0;
      let nextVote: 'like' | 'dislike' | undefined;

      if (vid.userVoted === voteType) {
        // Undo current vote
        if (voteType === 'like') likesChange = -1;
        else dislikesChange = -1;
        nextVote = undefined;
      } else {
        // Switch vote or set new vote
        if (voteType === 'like') {
          likesChange = 1;
          if (vid.userVoted === 'dislike') dislikesChange = -1;
        } else {
          dislikesChange = 1;
          if (vid.userVoted === 'like') likesChange = -1;
        }
        nextVote = voteType;
      }

      return {
        ...vid,
        likes: Math.max(0, vid.likes + likesChange),
        dislikes: Math.max(0, vid.dislikes + dislikesChange),
        userVoted: nextVote
      };
    });

    setVideos(updated);

    // Keep selectedVideo page synced
    if (selectedVideo && selectedVideo.id === id) {
      const match = updated.find(v => v.id === id);
      if (match) setSelectedVideo(match);
    }
  };

  const handlePostVote = (id: string, voteType: 'like' | 'dislike') => {
    setPosts(prev => prev.map(post => {
      if (post.id !== id) return post;
      
      let likesChange = 0;
      let dislikesChange = 0;
      let nextVote: 'like' | 'dislike' | undefined;

      if (post.userVoted === voteType) {
        if (voteType === 'like') likesChange = -1;
        else dislikesChange = -1;
        nextVote = undefined;
      } else {
        if (voteType === 'like') {
          likesChange = 1;
          if (post.userVoted === 'dislike') dislikesChange = -1;
        } else {
          dislikesChange = 1;
          if (post.userVoted === 'like') likesChange = -1;
        }
        nextVote = voteType;
      }

      return {
        ...post,
        likes: Math.max(0, post.likes + likesChange),
        dislikes: Math.max(0, post.dislikes + dislikesChange),
        userVoted: nextVote
      };
    }));
  };

  const handleCommentVote = (commentId: string, voteType: 'like' | 'dislike') => {
    if (!selectedVideo) return;
    
    const updated = videos.map(vid => {
      if (vid.id !== selectedVideo.id) return vid;
      
      const updatedComments = vid.comments.map(comm => {
        if (comm.id !== commentId) return comm;
        
        let lChange = 0;
        let dChange = 0;
        let nextV: 'like' | 'dislike' | undefined;

        if (comm.userVoted === voteType) {
          if (voteType === 'like') lChange = -1;
          else dChange = -1;
          nextV = undefined;
        } else {
          if (voteType === 'like') {
            lChange = 1;
            if (comm.userVoted === 'dislike') dChange = -1;
          } else {
            dChange = 1;
            if (comm.userVoted === 'like') lChange = -1;
          }
          nextV = voteType;
        }

        return {
          ...comm,
          likes: Math.max(0, comm.likes + lChange),
          dislikes: Math.max(0, comm.dislikes + dChange),
          userVoted: nextV
        };
      });

      return { ...vid, comments: updatedComments };
    });

    setVideos(updated);
    
    // Sync active container
    const match = updated.find(v => v.id === selectedVideo.id);
    if (match) setSelectedVideo(match);
  };

  const checkIfBanned = (): boolean => {
    if (bannedUntil !== null && Date.now() < bannedUntil) {
      alert(`⚠️ [Sanción Temporal de IA] Estás bloqueado temporalmente por acumulación de Advertencias de Toxicidad (Warnings >= 3).\n\nNo puedes comentar ni publicar contenido durante los próximos ${banTimeRemaining} segundos.`);
      return true;
    }
    return false;
  };

  const handleAddVideoComment = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedVideo) return;
    if (checkIfBanned()) return;
    
    const textToSubmit = videoComment.trim();
    if (!textToSubmit) return;

    // Run strict local AI moderation check
    const evaluation = moderateComment(textToSubmit);
    if (evaluation.isToxic) {
      const nextWarnings = (currentUser.warnings || 0) + 1;
      const updatedUser = { ...currentUser, warnings: nextWarnings };
      setCurrentUser(updatedUser);
      localStorage.setItem('opentube_user', JSON.stringify(updatedUser));

      if (nextWarnings >= 3) {
        const banExpiry = Date.now() + 30000; // 30 seconds temporal penalty
        setBannedUntil(banExpiry);
        localStorage.setItem('opentube_banned_until', banExpiry.toString());
      }

      setCommentBlockedModal({
        originalText: textToSubmit,
        warningCount: nextWarnings,
        reason: evaluation.violations.join(', ') || 'Palabras ofensivas o difamatorias detectadas'
      });
      setVideoComment('');
      return;
    }

    const newComment: Comment = {
      id: `c-${Date.now()}`,
      author: currentUser.name,
      avatarUrl: currentUser.avatarUrl,
      text: textToSubmit,
      timestamp: "Hace unos instantes",
      likes: 0,
      dislikes: 0
    };

    const updated = videos.map(vid => {
      if (vid.id !== selectedVideo.id) return vid;
      return {
        ...vid,
        comments: [newComment, ...vid.comments]
      };
    });

    setVideos(updated);
    
    // Sync current focused model
    const match = updated.find(v => v.id === selectedVideo.id);
    if (match) setSelectedVideo(match);
    
    setVideoComment('');
  };

  const handleAddPostComment = (postId: string, text: string) => {
    if (checkIfBanned()) return;
    const textToSubmit = text.trim();
    if (!textToSubmit) return;

    // Run strict local AI moderation check
    const evaluation = moderateComment(textToSubmit);
    if (evaluation.isToxic) {
      const nextWarnings = (currentUser.warnings || 0) + 1;
      const updatedUser = { ...currentUser, warnings: nextWarnings };
      setCurrentUser(updatedUser);
      localStorage.setItem('opentube_user', JSON.stringify(updatedUser));

      if (nextWarnings >= 3) {
        const banExpiry = Date.now() + 30000; // 30 seconds temporal penalty
        setBannedUntil(banExpiry);
        localStorage.setItem('opentube_banned_until', banExpiry.toString());
      }

      setCommentBlockedModal({
        originalText: textToSubmit,
        warningCount: nextWarnings,
        reason: evaluation.violations.join(', ') || 'Expresiones inadecuadas o lenguaje de odio'
      });
      setPostCommentInputs(prev => ({
        ...prev,
        [postId]: ''
      }));
      return;
    }

    const newComment: Comment = {
      id: `c-post-${Date.now()}`,
      author: currentUser.name,
      avatarUrl: currentUser.avatarUrl,
      text: textToSubmit,
      timestamp: "Hace unos segundos",
      likes: 0,
      dislikes: 0
    };

    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p;
      return {
        ...p,
        comments: [...p.comments, newComment]
      };
    }));

    setPostCommentInputs(prev => ({
      ...prev,
      [postId]: ''
    }));
  };

  const handleAddShortComment = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (checkIfBanned()) return;
    const activeShort = filteredShorts[currentShortIndex];
    if (!activeShort) return;

    const textToSubmit = shortCommentText.trim();
    if (!textToSubmit) return;

    // Run strict local AI moderation check
    const evaluation = moderateComment(textToSubmit);
    if (evaluation.isToxic) {
      const nextWarnings = (currentUser.warnings || 0) + 1;
      const updatedUser = { ...currentUser, warnings: nextWarnings };
      setCurrentUser(updatedUser);
      localStorage.setItem('opentube_user', JSON.stringify(updatedUser));

      if (nextWarnings >= 3) {
        const banExpiry = Date.now() + 30000; // 30 seconds temporal penalty
        setBannedUntil(banExpiry);
        localStorage.setItem('opentube_banned_until', banExpiry.toString());
      }

      setCommentBlockedModal({
        originalText: textToSubmit,
        warningCount: nextWarnings,
        reason: evaluation.violations.join(', ') || 'Infracción de normas comunitarias de comentarios'
      });
      setShortCommentText('');
      return;
    }

    const newComment: Comment = {
      id: `c-short-${Date.now()}`,
      author: currentUser.name,
      avatarUrl: currentUser.avatarUrl,
      text: textToSubmit,
      timestamp: "Justo ahora",
      likes: 0,
      dislikes: 0
    };

    setVideos(prev => prev.map(v => {
      if (v.id !== activeShort.id) return v;
      return {
        ...v,
        comments: [newComment, ...v.comments]
      };
    }));

    setShortCommentText('');
  };

  // --- COMMUNITY PUBLICATIONS AND UPLOADS ---
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (checkIfBanned()) return;
    const textToSubmit = newPostText.trim();
    if (!textToSubmit) return;

    // Run strict local AI moderation check on new post text
    const evaluation = moderateComment(textToSubmit);
    if (evaluation.isToxic) {
      const nextWarnings = (currentUser.warnings || 0) + 1;
      const updatedUser = { ...currentUser, warnings: nextWarnings };
      setCurrentUser(updatedUser);
      localStorage.setItem('opentube_user', JSON.stringify(updatedUser));

      if (nextWarnings >= 3) {
        const banExpiry = Date.now() + 30000; // 30 seconds temporal penalty
        setBannedUntil(banExpiry);
        localStorage.setItem('opentube_banned_until', banExpiry.toString());
      }

      setCommentBlockedModal({
        originalText: textToSubmit,
        warningCount: nextWarnings,
        reason: evaluation.violations.join(', ') || 'Expresiones inadecuadas o lenguaje de odio'
      });
      setNewPostText('');
      return;
    }

    const newPost: Post = {
      id: `post-${Date.now()}`,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatarUrl,
      isVerifiedAuthor: true, // gets the unique exclusive Tick
      text: textToSubmit,
      timestamp: "Ahora mismo",
      likes: 0,
      dislikes: 0,
      comments: []
    };

    setPosts([newPost, ...posts]);
    setNewPostText('');
  };

  const handleUploadVideo = (
    newVideo: Video & { originalityScore?: number },
    videoFile?: File | Blob,
    thumbnailFile?: File | Blob
  ) => {
    // If it's standard user upload, mark as verified channel because we own it!
    const finalVideo = {
      ...newVideo,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatarUrl,
      isVerifiedAuthor: true,
      originalityScore: newVideo.originalityScore ?? 100
    };

    // If less than 50% copyright breach (excluding 1% and 1.0% which play countdown animations)
    if (finalVideo.originalityScore < 50 && finalVideo.originalityScore !== 1 && finalVideo.originalityScore !== 1.0) {
      // Discard instantly by rights safety
      return;
    }

    if (finalVideo.originalityScore === 50) {
      const unlockTime = Date.now() + 3600000; // 1 hour absolute lock
      setScheduledVideoIds(prev => ({
        ...prev,
        [finalVideo.id]: unlockTime
      }));
    }

    // Save actual binary content and metadata directly inside IndexedDB using Dexie
    if (videoFile) {
      saveVideoToIndexedDB(finalVideo, videoFile, thumbnailFile);
      // Register current URL so our Circular Buffer cleans previous items if they leak
      blobManager.register(finalVideo.id + '-video', finalVideo.videoUrl);
      if (finalVideo.thumbnailUrl && finalVideo.thumbnailUrl.startsWith('blob:')) {
        blobManager.register(finalVideo.id + '-thumbnail', finalVideo.thumbnailUrl);
      }
    }

    setVideos(prev => [finalVideo, ...prev]);

    // Fast self-destruct scenarios
    if (finalVideo.originalityScore === 1) {
      setTimeout(() => {
        setVideos(prev => prev.filter(v => v.id !== finalVideo.id));
        deleteVideoFromIndexedDB(finalVideo.id);
        blobManager.revoke(finalVideo.id + '-video');
        blobManager.revoke(finalVideo.id + '-thumbnail');
        setSelectedVideo(current => current?.id === finalVideo.id ? null : current);
      }, 10000); // 10 seconds
    } else if (finalVideo.originalityScore === 1.0) {
      setTimeout(() => {
        setVideos(prev => prev.filter(v => v.id !== finalVideo.id));
        deleteVideoFromIndexedDB(finalVideo.id);
        blobManager.revoke(finalVideo.id + '-video');
        blobManager.revoke(finalVideo.id + '-thumbnail');
        setSelectedVideo(current => current?.id === finalVideo.id ? null : current);
      }, 1000); // 1 second
    }
  };

  const handleDeleteVideo = (videoId: string, isShort: boolean) => {
    if (window.confirm("¿Seguro que deseas eliminar este contenido?")) {
      setVideos(prev => prev.filter(v => v.id !== videoId));
      
      // Delete from Dexie IndexedDB and revoke Blob urls instantly
      deleteVideoFromIndexedDB(videoId);
      blobManager.revoke(videoId + '-video');
      blobManager.revoke(videoId + '-thumbnail');

      if (selectedVideo && selectedVideo.id === videoId) {
        setSelectedVideo(null);
      }
      if (isShort && currentShortIndex >= filteredShorts.length - 1) {
        setCurrentShortIndex(Math.max(0, currentShortIndex - 1));
      }
    }
  };

  const handleAdminCommand = (command: string, args: string[]) => {
    if (command === '/boostviews') {
      setVideos(prev => prev.map(v => ({
        ...v,
        views: v.views + 1000000
      })));
    } else if (command === '/verifyall') {
      setVideos(prev => prev.map(v => ({
        ...v,
        isVerifiedAuthor: true
      })));
    } else if (command === '/cleanothers') {
      setVideos(prev => prev.filter(v => v.authorName === currentUser.name));
    } else if (command === '/addtestshort') {
      const demoShort: Video = {
        id: `short-admin-${Date.now()}`,
        title: "🔥 BEST OF THE WEEK (Exclusivo GamerCool Admin)",
        description: "Insuperable demostración de puntería de videojuego y jugadas profesionales de nivel competitivo con escalado IA activado.",
        videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-playing-an-action-video-game-with-a-controller-40292-large.mp4",
        thumbnailUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=2670&auto=format&fit=crop",
        duration: 36,
        views: 312500,
        uploadDate: "Hace un momento",
        likes: 9150,
        dislikes: 12,
        category: "Gamer",
        isShort: true,
        authorName: currentUser.name,
        authorAvatar: currentUser.avatarUrl,
        isVerifiedAuthor: true,
        comments: [],
        hashtags: ["gaming", "esport", "admin", "fullhd"],
        language: "Español"
      };
      setVideos([demoShort, ...videos]);
    }
  };

  // --- FILTERS & COMPUTATIONS ---
  const standardVideos = videos.filter(v => !v.isShort);
  const shortsList = videos.filter(v => v.isShort);

  const filteredStandardVideos = standardVideos.filter(vid => {
    const matchesSearch = 
      vid.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      vid.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vid.authorName.toLowerCase().includes(searchQuery.toLowerCase());
      
    const matchesCategory = selectedCategory === 'Todos' || vid.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const filteredShorts = shortsList.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    s.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpenUploadModal = (mode: 'video' | 'short') => {
    if (checkIfBanned()) return;
    setUploadMode(mode);
    setIsUploadOpen(true);
  };

  const handleSelectVideo = (video: Video) => {
    // Increment local views counter sequentially upon clicking
    setVideos(prev => prev.map(v => {
      if (v.id === video.id) {
        return { ...v, views: v.views + 1 };
      }
      return v;
    }));
    
    const incrementedVid = { ...video, views: video.views + 1 };
    setSelectedVideo(incrementedVid);
    setActiveTab('home');
  };

  const handleNavigateToHome = () => {
    setSelectedVideo(null);
    handleTabChange('home');
  };

  const categories = [
    'Todos', 'Desarrollo Web', 'Música & Lo-Fi', 'Gamer', 'Tecnología de Punta', 'Entretenimiento', 'Cortometraje'
  ];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-red-600/30 selection:text-white select-none">
      
      {/* EXCLUSIVE GOLDEN ANNOUNCEMENT BANNER */}
      {currentUser.vipAnnouncement && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-neutral-950 font-black text-xs py-2 px-4 shadow shadow-amber-500/20 flex items-center justify-between gap-4 border-b border-amber-600 relative overflow-hidden shrink-0 select-none">
          <div className="flex items-center gap-3 overflow-hidden flex-1">
            <div className="bg-neutral-950 text-amber-400 text-[9px] tracking-widest font-black uppercase px-2.5 py-0.5 rounded flex items-center gap-1 shrink-0 font-mono">
              <Radio className="w-3 h-3 text-amber-400 animate-pulse" /> ALERTA VIP
            </div>
            {/* Scroll Container */}
            <div className="overflow-hidden relative w-full flex items-center py-1">
              <span className="inline-block animate-marquee whitespace-nowrap text-[12px] uppercase font-bold tracking-wider">
                👑 ANUNCIO PLATINO DE {currentUser.name}: {currentUser.vipAnnouncement} • {currentUser.vipAnnouncement} • {currentUser.vipAnnouncement}
              </span>
            </div>
          </div>

          <button 
            type="button" 
            onClick={() => handleUpdateUser({ ...currentUser, vipAnnouncement: '' })} 
            className="text-neutral-950 hover:text-black p-1 hover:bg-neutral-950/15 rounded-full transition-all shrink-0 cursor-pointer"
            title="Cerrar cartelera VIP"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. STICKY PLATFORM HEADER */}
      <Header 
        currentUser={currentUser}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenUpload={handleOpenUploadModal}
        onNavigateToProfile={() => handleTabChange('profile')}
        onNavigateToHome={handleNavigateToHome}
        onSelectSuggestion={(suggestion) => {
          setSearchQuery(suggestion);
          const match = videos.find(v => 
            v.title.toLowerCase().includes(suggestion.toLowerCase()) || 
            v.category.toLowerCase().includes(suggestion.toLowerCase())
          );
          if (match) {
            if (match.isShort) {
              const shortIdx = videos.filter(v => v.isShort).findIndex(s => s.id === match.id);
              if (shortIdx !== -1) {
                setCurrentShortIndex(shortIdx);
                handleTabChange('shorts');
              }
            } else {
              setSelectedVideo(match);
              handleTabChange('home');
            }
          } else {
            handleTabChange('home');
            setSelectedVideo(null);
          }
        }}
        allVideos={videos}
        lang={lang}
        onLanguageChange={(l) => {
          setLang(l);
          localStorage.setItem('opentube_lang', l);
        }}
      />

      {/* CORE DOUBLE BLOCK BODY CONTAINER */}
      <div className="flex-1 flex flex-col md:flex-row">
        
        {/* 2. RESPONSIVE SIDEBAR NAVIGATION */}
        <Sidebar 
          activeTab={activeTab}
          setActiveTab={(tab) => handleTabChange(tab)}
          subscribersCount={currentUser.subscribers}
          lang={lang}
        />

        {/* 3. WORKING VIEWPORT STAGE */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
          
          {/* TAB 1: INICIO (HOME FEED OR VIDEO DETAILS) */}
          {activeTab === 'home' && (
            <div className="animate-fade-in flex flex-col gap-6">
              
              {/* VIDEO DETAILED INNER SUBPAGE */}
              {selectedVideo ? (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
                  
                  {/* LEFT DETAILED COLLAPSE: PLAYER + TEXT INFO + COMMENTS */}
                  <div className="lg:col-span-2 flex flex-col gap-4">
                    
                    {/* VIDEO PLAYER COMPONENT WITH DETECTS */}
                    <VideoPlayer 
                      url={selectedVideo.videoUrl} 
                      poster={selectedVideo.thumbnailUrl}
                      title={selectedVideo.title}
                      isAudio={selectedVideo.isAudio}
                      initialTime={playbackProgress[selectedVideo.id]?.currentTime || 0}
                      onTimeProgress={(time, dur) => handleUpdatePlaybackProgress(selectedVideo.id, time, dur)}
                    />

                    {/* METADATA DESCRIPTIVE ROW */}
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex flex-col gap-3">
                      
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <span className="bg-red-600 font-mono text-white text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded shadow uppercase">
                          {selectedVideo.category}
                        </span>
                        
                        {/* Self content Delete Button */}
                        {selectedVideo.authorName === currentUser.name && (
                          <button
                            onClick={() => handleDeleteVideo(selectedVideo.id, false)}
                            className="flex items-center gap-1.5 px-3 py-1 bg-red-950/40 hover:bg-red-900 text-red-400 hover:text-white rounded-lg text-xs font-semibold border border-red-500/20 transition-all cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Eliminar mi Video</span>
                          </button>
                        )}
                      </div>

                      <h2 className="text-white text-lg sm:text-xl font-bold tracking-tight">
                        {selectedVideo.title}
                      </h2>

                      {/* Views count and date */}
                      <div className="flex items-center gap-2 text-xs text-neutral-400 font-sans border-b border-neutral-800 pb-3">
                        <span>{formatViews(selectedVideo.views)}</span>
                        <span>•</span>
                        <span>Publicado: {selectedVideo.uploadDate}</span>
                      </div>

                      {/* Author Card row */}
                      <div className="flex items-center justify-between flex-wrap gap-4 pt-1">
                        <div className="flex items-center gap-3">
                          <img 
                            src={selectedVideo.authorAvatar} 
                            alt={selectedVideo.authorName} 
                            className="w-10 h-10 rounded-full border border-neutral-800 object-cover"
                          />
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-white text-sm font-bold">{selectedVideo.authorName}</span>
                              {/* Verified Tick is exclusive to our logged main user profile name */}
                              {selectedVideo.authorName === currentUser.name && (
                                <span className="inline-flex items-center gap-1 font-sans">
                                  <VerifiedBadge type={currentUser.vipEmblem} size="md" />
                                  {currentUser.vipEmblem === 'star' && (
                                    <span className="px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wider bg-gradient-to-r from-red-500 to-amber-500 text-neutral-950 rounded shadow-sm select-none">
                                      creator
                                    </span>
                                  )}
                                </span>
                              )}
                            </div>
                            <span className="text-neutral-400 text-xs font-sans block mt-0.5">
                              {selectedVideo.authorName === currentUser.name 
                                ? `${currentUser.subscribers.toLocaleString('es-ES')} suscriptores` 
                                : 'Canal Autor Afiliado'
                              }
                            </span>
                          </div>
                        </div>

                        {/* VOTER CONTAINER & REMIX */}
                        <div className="flex items-center gap-2 flex-wrap">
                          <div className="flex items-center gap-1 bg-neutral-950 border border-neutral-800 p-1 rounded-xl">
                            <button
                              onClick={() => handleVote(selectedVideo.id, 'like')}
                              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                                selectedVideo.userVoted === 'like'
                                  ? 'bg-red-650 hover:bg-red-500 text-white'
                                  : 'hover:bg-neutral-800 text-neutral-300 hover:text-white'
                              }`}
                            >
                              <ThumbsUp className={`w-4 h-4 ${selectedVideo.userVoted === 'like' ? 'fill-current' : ''}`} />
                              <span>{selectedVideo.likes.toLocaleString()}</span>
                            </button>

                            <div className="w-px h-6 bg-neutral-800" />

                            <button
                              onClick={() => handleVote(selectedVideo.id, 'dislike')}
                              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                                selectedVideo.userVoted === 'dislike'
                                  ? 'bg-neutral-800 text-zinc-300 border border-neutral-300/60'
                                  : 'hover:bg-neutral-800 text-neutral-300 hover:text-white'
                              }`}
                            >
                              <ThumbsDown className={`w-4 h-4 ${selectedVideo.userVoted === 'dislike' ? 'fill-current' : ''}`} />
                              <span>{selectedVideo.dislikes.toLocaleString()}</span>
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => setRemixModalVideo(selectedVideo)}
                            className="bg-neutral-950 hover:bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-300 hover:text-white font-bold text-xs px-3.5 py-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow"
                          >
                            <span className="animate-pulse">🎙️</span>
                            <span>{lang === 'es' ? "Remix por IA" : "AI Remix"}</span>
                          </button>
                        </div>
                      </div>

                      {/* Video description */}
                      <div className="bg-neutral-950 p-4 rounded-xl border border-neutral-800 text-xs sm:text-sm text-neutral-300 leading-relaxed font-sans mt-2 whitespace-pre-wrap">
                        {selectedVideo.description}
                      </div>
                    </div>

                    {/* COMMENT SYSTEM SECTION */}
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 flex flex-col gap-6">
                      <h3 className="text-white font-bold text-base border-b border-neutral-800 pb-2.5 flex items-center gap-2">
                        <MessageSquare className="w-5 h-5 text-red-500" />
                        <span>Comentarios ({selectedVideo.comments.length})</span>
                      </h3>

                      {/* Comment Input box */}
                      <form onSubmit={handleAddVideoComment} className="flex gap-3">
                        <img 
                          src={currentUser.avatarUrl} 
                          alt="Tu Perfil" 
                          className="w-9 h-9 rounded-full border border-red-500 object-cover"
                        />
                        <div className="flex-1 flex gap-2">
                          <input
                            type="text"
                            required
                            placeholder="Añade un comentario sobre este video en OpenTube..."
                            value={videoComment}
                            onChange={(e) => setVideoComment(e.target.value)}
                            className="flex-1 bg-neutral-950 text-white placeholder-neutral-500 text-xs rounded-xl px-4 py-2 border border-neutral-800 focus:outline-none focus:border-red-500 transition-colors"
                          />
                          <button
                            type="submit"
                            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 hover:shadow-lg transition-all"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>Comentar</span>
                          </button>
                        </div>
                      </form>

                      {/* Comments stream list */}
                      <div className="flex flex-col gap-4 divide-y divide-neutral-800">
                        {selectedVideo.comments.length === 0 ? (
                          <p className="text-center text-neutral-500 text-xs py-4">No hay comentarios aún. ¡Sé el primero en dejar tu opinión!</p>
                        ) : (
                          selectedVideo.comments.map((comment) => {
                            const isSelfComment = comment.author === currentUser.name;
                            return (
                              <div key={comment.id} className="pt-4 flex gap-3 first:pt-0">
                                <img 
                                  src={comment.avatarUrl} 
                                  alt={comment.author} 
                                  className="w-8 h-8 rounded-full border border-neutral-800 object-cover"
                                />
                                <div className="flex-1">
                                  {/* User details */}
                                  <div className="flex items-center gap-1.5 text-xs">
                                    <span className="text-white font-bold">{comment.author}</span>
                                    {/* Tick badge only exclusive to current author */}
                                    {isSelfComment ? (
                                      <span className="inline-flex items-center gap-1">
                                        <VerifiedBadge type={currentUser.vipEmblem} size="sm" />
                                        {currentUser.vipEmblem === 'star' && (
                                          <span className="px-1 py-0.5 text-[7px] font-black uppercase tracking-wider bg-gradient-to-r from-red-500 to-amber-500 text-neutral-950 rounded shadow-sm select-none">
                                            creator
                                          </span>
                                        )}
                                      </span>
                                    ) : (
                                      <span className="inline-flex items-center gap-1 bg-neutral-950 px-1 py-0.5 rounded border border-neutral-850">
                                        <VerifiedBadge type="new-member" size="sm" />
                                        <span className="px-1 py-0.2 text-[8px] font-black uppercase bg-neutral-850 text-neutral-400 rounded select-none">
                                          Nuevo
                                        </span>
                                      </span>
                                    )}
                                    <span className="text-neutral-500 text-[10px]">{comment.timestamp}</span>
                                  </div>

                                  <p className="text-neutral-300 text-xs sm:text-sm mt-1 font-sans">
                                    {comment.text}
                                  </p>

                                  {/* Likes & Dislikes on Comment */}
                                  <div className="flex items-center gap-3 mt-2 text-xs">
                                    <button 
                                      onClick={() => handleCommentVote(comment.id, 'like')}
                                      className={`flex items-center gap-1 ${comment.userVoted === 'like' ? 'text-red-500' : 'text-neutral-500 hover:text-white'}`}
                                      title="Me gusta"
                                    >
                                      <ThumbsUp className="w-3 h-3" />
                                      <span className="text-[10px]">{comment.likes}</span>
                                    </button>
                                    
                                    <button 
                                      onClick={() => handleCommentVote(comment.id, 'dislike')}
                                      className={`flex items-center gap-1 ${comment.userVoted === 'dislike' ? 'text-zinc-200' : 'text-neutral-500 hover:text-white'}`}
                                      title="No me gusta"
                                    >
                                      <ThumbsDown className="w-3 h-3" />
                                      <span className="text-[10px]">{comment.dislikes}</span>
                                    </button>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  </div>

                  {/* RIGHT SIDEBAR: OTHER RECOMMENDED STANDARDS */}
                  <div className="flex flex-col gap-4">
                    <h3 className="text-white text-sm font-bold uppercase tracking-wider block">Recomendaciones sugeridas</h3>
                    <div className="flex flex-col gap-3">
                      {standardVideos
                        .filter(v => v.id !== selectedVideo.id)
                        .map(vid => (
                          <div 
                            key={vid.id} 
                            onClick={() => handleSelectVideo(vid)}
                            className="flex gap-2.5 bg-neutral-900/60 hover:bg-neutral-900 border border-neutral-800 rounded-xl p-2 cursor-pointer transition-all duration-300 group"
                          >
                            <div className="relative w-28 aspect-video shrink-0 rounded-lg overflow-hidden bg-black">
                              <img src={vid.thumbnailUrl} alt={vid.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                              <span className="absolute bottom-1 right-1 bg-black/85 text-[8px] font-mono font-bold px-1 py-0.2 rounded text-white">
                                {formatDuration(vid.duration)}
                              </span>
                            </div>
                            <div className="min-w-0 flex-1 flex flex-col justify-between">
                              <h4 className="text-white text-xs font-semibold leading-tight line-clamp-2 hover:text-red-500 transition-colors">
                                {vid.title}
                              </h4>
                              <div className="text-[10px] text-neutral-400 mt-1">
                                <span className="block truncate">{vid.authorName}</span>
                                <span className="block text-neutral-500">{formatViews(vid.views)}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>

                </div>
              ) : (
                
                // MAIN STANDARD FEED BLOCK
                <div className="flex flex-col gap-6">

                  {/* WALCOMING LOGS FOR ALL NEW USERS (Tick Gris Claro & "Nuevo") */}
                  <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center animate-pulse">
                        <span className="text-lg">👋</span>
                      </div>
                      <div>
                        <h4 className="text-white text-xs sm:text-sm font-bold flex items-center gap-2">
                          ¡Damos la bienvenida a los nuevos creadores de OpenTube!
                        </h4>
                        <p className="text-neutral-400 text-[10.5px] sm:text-xs">
                          Cada cuenta activa que no sea GamerCool recibe de forma inmediata el <span className="text-neutral-200 font-bold underline decoration-indigo-500 underline-offset-2">Tick Gris Claro</span> y la etiqueta de <span className="bg-neutral-805 px-1 py-0.5 rounded text-[9px] font-black uppercase text-neutral-400">Nuevo</span>. Bienvenidos a OpenTube.
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1.5 text-[10px] font-mono shrink-0">
                      <span className="bg-neutral-950 px-2 py-1 rounded-lg border border-neutral-850 text-neutral-400 hover:border-neutral-700 transition-colors">
                        👋 Bienvenido <span className="text-white font-bold">Carlos Tech</span>
                      </span>
                      <span className="bg-neutral-950 px-2 py-1 rounded-lg border border-neutral-850 text-neutral-400 hover:border-neutral-700 transition-colors">
                        👋 Bienvenido <span className="text-white font-bold">Elena R.</span>
                      </span>
                      <span className="bg-neutral-950 px-2 py-1 rounded-lg border border-neutral-850 text-neutral-400 hover:border-neutral-700 transition-colors">
                        👋 Bienvenido <span className="text-white font-bold">Pedro Tech</span>
                      </span>
                    </div>
                  </div>
                  
                  {/* CONTINUAR VIENDO (PLAYBACK HISTORY RESUME HOOKS) */}
                  {(() => {
                    const continueWatchingVideos = videos.filter(vid => {
                      if (vid.isShort) return false;
                      const progress = playbackProgress[vid.id];
                      if (!progress) return false;
                      const ratio = progress.currentTime / (progress.duration || 1);
                      return progress.currentTime > 2 && ratio < 0.94;
                    });

                    if (continueWatchingVideos.length === 0) return null;

                    return (
                      <div className="bg-neutral-900 border border-neutral-800/85 rounded-2xl p-4 md:p-5 flex flex-col gap-3 mb-1 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-48 h-48 bg-red-600/5 rounded-full blur-[60px] pointer-events-none" />
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-black font-sans uppercase tracking-[0.16em] text-red-500 bg-red-500/10 border border-red-500/20 px-3 py-1 rounded-full flex items-center gap-1.5 animate-pulse">
                            <Compass className="w-3.5 h-3.5 text-red-500" /> REPRODUCCIÓN EN CURSO: CONTINUAR VIENDO
                          </span>
                          <button 
                            onClick={() => {
                              if (confirm("¿Seguro que deseas vaciar tu progreso en todos los videos?")) {
                                setPlaybackProgress({});
                              }
                            }} 
                            className="text-[10px] uppercase font-mono font-bold text-neutral-500 hover:text-red-400 transition-colors cursor-pointer"
                          >
                            Limpiar Historial
                          </button>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-1.5">
                          {continueWatchingVideos.map(vid => {
                            const progress = playbackProgress[vid.id];
                            const percent = Math.min(((progress?.currentTime || 0) / (progress?.duration || 1)) * 100, 100);
                            return (
                              <div 
                                key={`continue-${vid.id}`}
                                className="relative flex flex-col group bg-neutral-950 border border-neutral-850 hover:border-neutral-800 rounded-xl overflow-hidden transition-all duration-300"
                              >
                                {/* Thumbnail block */}
                                <div 
                                  className="relative aspect-video w-full bg-black cursor-pointer overflow-hidden"
                                  onClick={() => {
                                    // Resume to the saved timestamp
                                    setSelectedVideo({
                                      ...vid,
                                      // inject a tiny custom reference so components can resume
                                    });
                                  }}
                                >
                                  <img src={vid.thumbnailUrl} alt={vid.title} className="w-full h-full object-cover group-hover:scale-103 transition-transform" />
                                  <span className="absolute bottom-2 right-2 bg-neutral-950/80 font-mono text-[9px] text-white px-1.5 py-0.5 rounded font-black border border-white/5">
                                    Quedan {formatDuration(Math.max((progress?.duration || 0) - (progress?.currentTime || 0), 0))}
                                  </span>
                                  
                                  {/* Red dynamic progress tracking line */}
                                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-neutral-800">
                                    <div className="h-full bg-red-600" style={{ width: `${percent}%` }} />
                                  </div>
                                </div>
                                <div className="p-3 flex-1 flex flex-col justify-between">
                                  <h4 
                                    onClick={() => setSelectedVideo({ ...vid })}
                                    className="text-white hover:text-red-400 text-xs font-bold leading-normal line-clamp-2 cursor-pointer transition-colors"
                                  >
                                    {vid.title}
                                  </h4>
                                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-neutral-900">
                                    <span className="text-[10px] text-neutral-400 truncate max-w-[100px]">{vid.authorName}</span>
                                    <button
                                      onClick={() => {
                                        const nextProg = { ...playbackProgress };
                                        delete nextProg[vid.id];
                                        setPlaybackProgress(nextProg);
                                      }}
                                      className="text-neutral-500 hover:text-red-400 p-1 rounded transition-colors text-[9px] font-bold cursor-pointer font-mono"
                                      title="Quitar progreso"
                                    >
                                      QUITAR
                                    </button>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })()}

                  {/* CATEGORIES BUTTONS HORIZONTAL PANEL */}
                  <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all border cursor-pointer ${
                          selectedCategory === cat
                            ? 'bg-red-600 text-white border-red-500 shadow-md shadow-red-950/20'
                            : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white hover:bg-neutral-850'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  {/* VIDEO CARDS STREAM GRID */}
                  <div>
                    {filteredStandardVideos.length === 0 ? (
                      <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-12 text-center">
                        <p className="text-neutral-400 text-sm mb-2">No se han encontrado videos estándar que coincidan con la búsqueda.</p>
                        <button 
                          onClick={() => { setSearchQuery(''); setSelectedCategory('Todos'); }} 
                          className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold transition-colors"
                        >
                          Reiniciar filtros
                        </button>
                      </div>
                    ) : (
                      <div className="flex flex-col">
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                          {filteredStandardVideos.slice(0, displayedLimit).map((vid) => (
                            <VideoCard 
                              key={vid.id}
                              video={vid}
                              currentUser={currentUser}
                              onSelectVideo={handleSelectVideo}
                              onVote={handleVote}
                              playbackProgress={playbackProgress}
                              onDeleteVideo={handleDeleteVideo}
                              onSelectHashtag={(tag) => setSearchQuery(tag)}
                            />
                          ))}
                        </div>

                        {/* Shimmer layout shown during automatic or manual load scroll feeds */}
                        {isInfiniteLoading && (
                          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-6">
                            {[...Array(4)].map((_, i) => (
                              <div key={`shimmer-${i}`} className="bg-neutral-900/40 border border-neutral-800/80 rounded-2xl overflow-hidden p-4 flex flex-col gap-3 animate-pulse">
                                <div className="aspect-video rounded-xl bg-neutral-800/60 w-full" />
                                <div className="flex gap-3">
                                  <div className="w-9 h-9 rounded-full bg-neutral-800/60 shrink-0" />
                                  <div className="flex-1 space-y-2 py-1">
                                    <div className="h-3 bg-neutral-850/50 rounded w-11/12 animate-pulse" />
                                    <div className="h-2.5 bg-neutral-850/50 rounded w-2/3 animate-pulse" />
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}

                        {/* Infinite scroll indicator and manual fallback button */}
                        {filteredStandardVideos.length > displayedLimit ? (
                          <div className="flex flex-col items-center justify-center mt-10 mb-2 gap-2">
                            <button
                              onClick={handleLoadMoreVideos}
                              disabled={isInfiniteLoading}
                              className="px-6 py-2.5 bg-neutral-900/80 hover:bg-neutral-900 text-neutral-300 hover:text-white border border-neutral-800 hover:border-neutral-750 font-sans text-xs font-black tracking-wider uppercase rounded-full transition-all flex items-center gap-2 shadow-lg cursor-pointer disabled:opacity-50"
                            >
                              {isInfiniteLoading ? (
                                <div className="flex items-center gap-1.5">
                                  <div className="w-3.5 h-3.5 rounded-full border-2 border-red-500 border-t-transparent animate-spin" />
                                  <span>Procesando recomendaciones...</span>
                                </div>
                              ) : (
                                <span>Cargar más recomendaciones IA ⚡</span>
                              )}
                            </button>
                            <span className="text-[10px] text-neutral-500 font-mono tracking-widest">CONTINUAR DESLIZANDO PARA SCROLL INFINITO</span>
                          </div>
                        ) : (
                          <div className="flex justify-center mt-10 mb-2">
                            <span className="text-[10px] text-neutral-500 font-mono tracking-widest bg-neutral-900/40 border border-neutral-850 px-4 py-1.5 rounded-full">HAS LLEGADO AL FINAL DEL CANAL LOCAL</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* DOCK MINI-SECTION SHORTS ON HOME FOR TIKTOK FEED PREVIEW */}
                  <div className="border-t border-neutral-800/80 pt-8 mt-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-amber-500" />
                        <h3 className="text-white text-base md:text-lg font-black tracking-tight font-sans">
                          Atracciones OpenTube <span className="text-amber-500 font-bold">Shorts ⚡</span>
                        </h3>
                      </div>
                      <button 
                        onClick={() => setActiveTab('shorts')}
                        className="text-amber-500 hover:text-amber-400 text-xs font-bold flex items-center gap-1 transition-all"
                      >
                        Ver todos los shorts →
                      </button>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {shortsList.slice(0, 6).map((short, index) => (
                        <div 
                          key={short.id}
                          onClick={() => {
                            const indexInShorts = shortsList.findIndex(s => s.id === short.id);
                            setCurrentShortIndex(indexInShorts !== -1 ? indexInShorts : 0);
                            setActiveTab('shorts');
                          }}
                          className="bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden cursor-pointer group hover:border-neutral-700 transition-all shadow-md flex flex-col h-full"
                        >
                          <div className="relative aspect-[9/16] bg-black rounded-t-xl overflow-hidden">
                            <img src={short.thumbnailUrl} alt={short.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent" />
                            <span className="absolute bottom-2 left-2 bg-neutral-950/80 text-[8px] font-mono px-1.5 py-0.5 rounded text-white flex items-center gap-1 font-semibold border border-white/5">
                              <Play className="w-2 h-2 fill-current" /> {formatViews(short.views)}
                            </span>
                          </div>
                          <div className="p-2.5 flex-1 flex flex-col justify-between">
                            <h4 className="text-white text-xs font-bold leading-tight line-clamp-2 hover:text-amber-400 transition-colors">
                              {short.title}
                            </h4>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}
            </div>
          )}

          {/* TAB 2: SHORTS SYSTEM VIEW (TIKTOK/REELS EXTREME VIEW) */}
          {activeTab === 'shorts' && (
            <div className="relative w-full h-[calc(100vh-3.5rem)] bg-black overflow-hidden animate-fade-in flex flex-col justify-center items-center">
              
              {filteredShorts.length === 0 ? (
                <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-12 text-center max-w-md w-full">
                  <p className="text-neutral-400 text-sm mb-4">No hay Shorts subidos aún que coincidan con la búsqueda.</p>
                  <button 
                    onClick={() => handleOpenUploadModal('short')} 
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-bold transition-all"
                  >
                    Subir un Short de prueba 🚀
                  </button>
                </div>
              ) : (
                (() => {
                  const activeShort = filteredShorts[currentShortIndex];
                  if (!activeShort) return null;

                  return (
                    <div id="shorts-player-container" className="absolute inset-0 w-full h-full flex items-center justify-center overflow-hidden">
                      {/* Full-screen stretched player */}
                      <div className="absolute inset-0 w-full h-full z-0 bg-neutral-950">
                        <VideoPlayer 
                          url={activeShort.videoUrl} 
                          poster={activeShort.thumbnailUrl}
                          title={activeShort.title}
                          autoPlay={true}
                          isAudio={activeShort.isAudio}
                          isShort={true}
                        />
                      </div>

                      {/* Translucent overlay for mobile-first aesthetic information */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30 pointer-events-none z-10" />

                      {/* Floating left information block (Ultra Compact to avoid covering the short video canvas) */}
                      <div className="absolute bottom-3 left-3 z-20 max-w-[calc(100%-5.5rem)] bg-black/60 backdrop-blur-md border border-white/5 rounded-xl p-2 flex flex-col gap-1.5 shadow-lg select-none">
                        <div className="flex items-center gap-1.5">
                          <img 
                            src={activeShort.authorAvatar} 
                            alt={activeShort.authorName} 
                            className="w-5 h-5 rounded-full border border-neutral-800 object-cover"
                          />
                          <div>
                            <div className="flex items-center gap-1 text-white text-[9px] font-black">
                              <span className="truncate max-w-[80px]">{activeShort.authorName}</span>
                              {activeShort.authorName === currentUser.name && (
                                <span className="inline-flex items-center gap-0.5">
                                  <VerifiedBadge type={currentUser.vipEmblem} size="sm" />
                                  {currentUser.vipEmblem === 'star' && (
                                    <span className="px-0.5 py-0.2 text-[5px] font-black uppercase tracking-wider bg-gradient-to-r from-red-500 to-amber-500 text-neutral-950 rounded select-none">
                                      vip
                                    </span>
                                  )}
                                </span>
                              )}
                            </div>
                            <span className="text-[7.5px] text-neutral-400 font-mono leading-none block">{formatViews(activeShort.views)} {TRANSLATIONS[lang].views}</span>
                          </div>
                        </div>

                        <h3 className="text-neutral-100 font-medium text-[9px] sm:text-[10px] tracking-tight leading-normal line-clamp-1" title={activeShort.title}>
                          {activeShort.title}
                        </h3>

                        {activeShort.hashtags && activeShort.hashtags.length > 0 && (
                          <div className="flex flex-wrap gap-0.5 max-h-[14px] overflow-hidden">
                            {activeShort.hashtags.slice(0, 2).map((tag, i) => (
                              <span key={i} className="text-[7px] font-bold text-red-400 bg-red-950/40 px-1 py-0.5 rounded-md border border-red-500/5">
                                #{tag}
                              </span>
                            ))}
                          </div>
                        )}

                        <span className="text-[7px] font-black tracking-widest text-amber-400 uppercase bg-amber-500/10 border border-amber-500/10 px-1 py-0.5 rounded self-start">
                          {TRANSLATIONS[lang].shortsUltimateMode}
                        </span>
                      </div>

                      {/* Floating right command toolbar */}
                      <div className="absolute bottom-6 right-6 z-20 flex flex-col gap-4 items-center bg-black/40 backdrop-blur-md border border-white/10 rounded-3xl p-3.5">
                        
                        {/* Vote Like */}
                        <button
                          onClick={() => handleVote(activeShort.id, 'like')}
                          className={`flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 group font-sans ${
                            activeShort.userVoted === 'like' ? 'text-amber-400 font-black' : 'text-neutral-300 hover:text-white'
                          }`}
                        >
                          <span className={`p-2.5 rounded-full border transition-all ${
                            activeShort.userVoted === 'like' ? 'bg-amber-600/30 border-amber-500' : 'bg-neutral-900/60 border-neutral-800'
                          }`}>
                            <ThumbsUp className="w-4 h-4" />
                          </span>
                          <span className="text-[10px] font-mono">{activeShort.likes.toLocaleString()}</span>
                        </button>

                        {/* Vote Dislike */}
                        <button
                          onClick={() => handleVote(activeShort.id, 'dislike')}
                          className={`flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 group font-sans ${
                            activeShort.userVoted === 'dislike' ? 'text-white font-black' : 'text-neutral-300 hover:text-white'
                          }`}
                        >
                          <span className={`p-2.5 rounded-full border transition-all ${
                            activeShort.userVoted === 'dislike' ? 'bg-zinc-700/55 border-neutral-500' : 'bg-neutral-900/60 border-neutral-800'
                          }`}>
                            <ThumbsDown className="w-4 h-4" />
                          </span>
                          <span className="text-[10px] font-mono">{activeShort.dislikes.toLocaleString()}</span>
                        </button>

                        {/* Full Screen for Shorts Toggler */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            const container = document.getElementById('shorts-player-container');
                            if (container) {
                              if (!document.fullscreenElement) {
                                container.requestFullscreen().catch((err) => {
                                  console.error("Error entering shorts fullscreen:", err);
                                });
                              } else {
                                document.exitFullscreen().catch((err) => {
                                  console.error("Error exiting shorts fullscreen:", err);
                                });
                              }
                            }
                          }}
                          className="flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 text-neutral-300 hover:text-white group"
                          title="Alternar Pantalla Completa"
                        >
                          <span className="p-2.5 rounded-full bg-neutral-900/60 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 flex items-center justify-center">
                            <Maximize className="w-4 h-4 text-amber-500 animate-pulse" />
                          </span>
                          <span className="text-[9px] font-bold">Pantalla Completa</span>
                        </button>

                        {/* Report Button */}
                        <button
                          onClick={(e) => { e.stopPropagation(); setReportingVideo(activeShort); }}
                          className="flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 hover:text-red-400 text-neutral-300 group"
                          title="Reportar este Short"
                        >
                          <span className="p-2.5 rounded-full bg-neutral-900/60 hover:bg-rose-955 border border-neutral-800 hover:border-red-500/20">
                            🚩
                          </span>
                          <span className="text-[9px] font-bold">Reportar</span>
                        </button>

                        {/* AI Remix for Shorts (Solo Audio) */}
                        <button
                          onClick={() => setRemixModalVideo(activeShort)}
                          className="flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 text-neutral-300 hover:text-white group"
                          title="Remix de Audio con IA"
                        >
                          <span className="p-2.5 rounded-full bg-neutral-900/60 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 flex items-center justify-center">
                            🎙️
                          </span>
                          <span className="text-[9px] font-bold">AI Remix</span>
                        </button>

                        {/* Toggle Comment Overlay */}
                        <button
                          onClick={() => setIsShortCommentsOpen(!isShortCommentsOpen)}
                          className={`flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 group ${
                            isShortCommentsOpen ? 'text-amber-500' : 'text-neutral-300 hover:text-white'
                          }`}
                        >
                          <span className={`p-2.5 rounded-full border transition-all ${
                            isShortCommentsOpen ? 'bg-amber-600/20 border-amber-500' : 'bg-neutral-900/60 border-neutral-800'
                          }`}>
                            💬
                          </span>
                          <span className="text-[10px] font-mono">{activeShort.comments.length}</span>
                        </button>

                        {/* Navigation controls */}
                        <div className="border-t border-white/10 pt-3 flex flex-col gap-2">
                          <button
                            onClick={() => setCurrentShortIndex(prev => Math.max(0, prev - 1))}
                            disabled={currentShortIndex === 0}
                            className="p-2 rounded-full bg-neutral-900/80 hover:bg-neutral-850 text-white border border-neutral-800 disabled:opacity-20 disabled:pointer-events-none active:scale-90 transition-transform"
                            title="Anterior Short"
                          >
                            <ChevronUp className="w-4 h-4" />
                          </button>
                          
                          <button
                            onClick={() => setCurrentShortIndex(prev => Math.min(filteredShorts.length - 1, prev + 1))}
                            disabled={currentShortIndex === filteredShorts.length - 1}
                            className="p-2 rounded-full bg-amber-600 hover:bg-amber-550 text-neutral-950 disabled:opacity-20 disabled:pointer-events-none active:scale-90 transition-transform"
                            title="Siguiente Short"
                          >
                            <ChevronDown className="w-4 h-4 font-bold" />
                          </button>
                        </div>
                      </div>

                      {/* Slide-out comments cabinet panel overlay */}
                      {isShortCommentsOpen && (
                        <div className="absolute top-0 right-0 h-full w-full sm:w-[360px] bg-neutral-950/95 border-l border-neutral-900/80 backdrop-blur-xl shadow-2xl z-30 p-5 flex flex-col justify-between animate-fade-in">
                          
                          <div className="flex justify-between items-center border-b border-neutral-850 pb-3">
                            <div>
                              <span className="text-white text-xs font-black uppercase tracking-wider">Comentarios del Short</span>
                              <p className="text-[10px] text-neutral-550">Resolución comunitaria automática</p>
                            </div>
                            <button
                              onClick={() => setIsShortCommentsOpen(false)}
                              className="p-1 px-2 text-xs font-bold bg-neutral-900 rounded hover:bg-neutral-800 text-neutral-300"
                            >
                              Ocultar
                            </button>
                          </div>

                          {/* list wrapper */}
                          <div className="flex-1 overflow-y-auto my-4 space-y-4 pr-1 font-sans">
                            {activeShort.comments.length === 0 ? (
                              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-neutral-500">
                                <p className="text-xs">No hay comentarios todavía.</p>
                                <p className="text-[10px] text-neutral-600 mt-1">¡Sé el primero en aportar con tus opiniones!</p>
                              </div>
                            ) : (
                              activeShort.comments.map((comm) => (
                                <div key={comm.id} className="text-xs flex gap-2.5 bg-neutral-900/20 p-2.5 rounded-xl border border-neutral-900/60">
                                  <img 
                                    src={comm.avatarUrl} 
                                    alt={comm.author} 
                                    className="w-6 h-6 rounded-full border border-neutral-850 object-cover shrink-0" 
                                  />
                                  <div className="space-y-0.5">
                                    <div className="flex items-center gap-1.5">
                                      <span className="text-neutral-200 font-bold block">{comm.author}</span>
                                      {comm.author === currentUser.name ? (
                                        <VerifiedBadge type={currentUser.vipEmblem} size="sm" />
                                      ) : (
                                        <span className="inline-flex items-center gap-1">
                                          <VerifiedBadge type="new-member" size="sm" />
                                          <span className="px-1 py-0.2 text-[7px] font-black bg-neutral-800 text-neutral-400 rounded">
                                            Nuevo
                                          </span>
                                        </span>
                                      )}
                                    </div>
                                    <span className="text-neutral-300 text-[11px] block mt-0.5 leading-relaxed">{comm.text}</span>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>

                          {/* form container */}
                          <form onSubmit={handleAddShortComment} className="flex gap-2">
                            <input
                              type="text"
                              required
                              placeholder="Escribe en este short..."
                              value={shortCommentText}
                              onChange={(e) => setShortCommentText(e.target.value)}
                              className="flex-1 bg-neutral-900 border border-neutral-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 placeholder-neutral-600"
                            />
                            <button
                              type="submit"
                              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-550 text-neutral-950 font-black rounded-xl text-xs uppercase"
                            >
                              Enviar
                            </button>
                          </form>
                        </div>
                      )}
                    </div>
                  );
                })()
              )}

            </div>
          )}

          {/* TAB 2.5: HISTORIAL (PLAYBACK HISTORY VIEW) */}
          {activeTab === 'history' && (
            <div className="animate-fade-in flex flex-col gap-6">
              
              {/* Header section with background blur overlay */}
              <div className="bg-gradient-to-r from-amber-950/40 via-neutral-900 to-neutral-900 border border-neutral-800 p-6 rounded-2xl shadow-md flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-[40px] pointer-events-none" />
                <div>
                  <span className="bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono text-[9px] uppercase font-bold tracking-widest px-2.5 py-1 rounded inline-block mb-3">
                    📋 {lang === 'es' ? 'Historial de Reproducción' : 'Playback Watch History'}
                  </span>
                  <h2 className="text-white text-xl font-bold tracking-tight">{lang === 'es' ? 'Tus Videos Recientemente Vistos' : 'Your Recently Viewed Videos'}</h2>
                  <p className="text-neutral-400 text-xs sm:text-sm mt-1 leading-relaxed font-sans">
                    {lang === 'es' ? 'Aquí se lista el estado de reproducción de todos los videos o shorts.' : 'Here is the progress of all your watched standard videos or shorts.'}
                  </p>
                </div>

                <button 
                  onClick={() => {
                    if (confirm(TRANSLATIONS[lang].clearHistoryConfirm)) {
                      setPlaybackProgress({});
                    }
                  }}
                  disabled={Object.keys(playbackProgress).length === 0}
                  className="px-4 py-2 bg-red-950/30 border border-red-500/25 hover:border-red-500 hover:bg-red-900 hover:text-white text-red-400 font-bold rounded-xl text-xs uppercase cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all shrink-0"
                >
                  {TRANSLATIONS[lang].clearHistory}
                </button>
              </div>

              {/* Dynamic calculations list */}
              {(() => {
                const historyItems = Object.entries(playbackProgress)
                  .map(([id, prog]) => {
                    const vid = videos.find(v => v.id === id);
                    return { vid, prog };
                  })
                  .filter((item): item is { vid: Video; prog: { currentTime: number; duration: number; timestamp: number } } => item.vid !== undefined)
                  .sort((a, b) => b.prog.timestamp - a.prog.timestamp);

                if (historyItems.length === 0) {
                  return (
                    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4">
                      <span className="text-4xl">📋</span>
                      <h3 className="text-white font-bold text-base">{TRANSLATIONS[lang].noHistory}</h3>
                      <p className="text-neutral-400 text-xs sm:text-sm max-w-sm">
                        {TRANSLATIONS[lang].noHistoryDesc}
                      </p>
                      <button 
                        onClick={() => setActiveTab('home')}
                        className="px-4 py-2 bg-red-650 hover:bg-red-600 text-white font-bold rounded-xl text-xs uppercase cursor-pointer"
                      >
                        {lang === 'es' ? 'Explorar Videos' : 'Explore Videos'}
                      </button>
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {historyItems.map(({ vid, prog }) => {
                      const percent = Math.min((prog.currentTime / (prog.duration || 1)) * 100, 100);
                      const timeString = new Date(prog.timestamp).toLocaleTimeString(lang === 'es' ? 'es-ES' : 'en-US', { hour: '2-digit', minute: '2-digit' });

                      return (
                        <div 
                          key={`hist-${vid.id}`} 
                          className="group bg-neutral-900/40 border border-neutral-800 hover:border-neutral-750 rounded-xl overflow-hidden flex flex-col justify-between transition-all"
                        >
                          <div className="relative">
                            {/* Card Media Preview Thumbnail */}
                            <div 
                              onClick={() => {
                                if (vid.isShort) {
                                  const idx = videos.filter(v => v.isShort).findIndex(v => v.id === vid.id);
                                  if (idx !== -1) {
                                    setCurrentShortIndex(idx);
                                    setActiveTab('shorts');
                                  }
                                } else {
                                  setSelectedVideo(vid);
                                  setActiveTab('home');
                                }
                              }}
                              className="aspect-video w-full relative bg-neutral-950 overflow-hidden cursor-pointer group-hover:opacity-90"
                            >
                              <img 
                                src={vid.thumbnailUrl} 
                                alt={vid.title} 
                                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                              />
                              
                              {/* Duration Badge */}
                              <span className="absolute bottom-2 right-2 bg-black/85 text-[9px] font-mono font-bold text-white px-1.5 py-0.5 rounded border border-white/5 shadow">
                                {formatDuration(vid.duration)}
                              </span>

                              {/* Short Visual Indicator Badge */}
                              {vid.isShort && (
                                <span className="absolute top-2 left-2 bg-amber-500 text-neutral-900 text-[8px] font-black tracking-widest px-2 py-0.5 rounded shadow-md uppercase">
                                  ⚡ SHORT
                                </span>
                              )}
                            </div>

                            {/* Progress bar indicator */}
                            <div className="w-full bg-neutral-800 h-1 relative overflow-hidden">
                              <div 
                                className={`h-full ${vid.isShort ? 'bg-amber-500' : 'bg-red-650'}`} 
                                style={{ width: `${percent}%` }} 
                              />
                            </div>
                          </div>

                          <div className="p-3 flex-1 flex flex-col justify-between gap-3 font-sans">
                            <div>
                              <h3 
                                onClick={() => {
                                  if (vid.isShort) {
                                    const idx = videos.filter(v => v.isShort).findIndex(v => v.id === vid.id);
                                    if (idx !== -1) {
                                      setCurrentShortIndex(idx);
                                      setActiveTab('shorts');
                                    }
                                  } else {
                                    setSelectedVideo(vid);
                                    setActiveTab('home');
                                  }
                                }}
                                className="text-white hover:text-red-500 transition-colors text-xs font-bold leading-snug line-clamp-2 cursor-pointer"
                                title={vid.title}
                              >
                                {vid.title}
                              </h3>
                              <span className="text-[10px] text-neutral-400 block mt-1 truncate">{vid.authorName}</span>
                            </div>

                            <div className="flex items-center justify-between gap-2 border-t border-neutral-800/80 pt-2.5">
                              <span className="text-[8.5px] text-neutral-450 font-mono">
                                Visto {timeString}
                              </span>

                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] text-neutral-350 font-bold">
                                  {Math.round(percent)}%
                                </span>
                                <button
                                  onClick={() => {
                                    setPlaybackProgress(prev => {
                                      const next = { ...prev };
                                      delete next[vid.id];
                                      return next;
                                    });
                                  }}
                                  className="p-1 hover:bg-neutral-800 hover:text-red-400 text-neutral-500 rounded-lg transition-colors cursor-pointer"
                                  title={lang === 'es' ? 'Quitar del historial' : 'Remove from history'}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}

            </div>
          )}

          {/* TAB 3: COMUNIDAD (COMMUNITY LOG) */}
          {activeTab === 'community' && (
            <div className="animate-fade-in max-w-3xl mx-auto flex flex-col gap-6">
              
              {/* Introduction Banner header */}
              <div className="bg-gradient-to-r from-indigo-950 via-neutral-900 to-neutral-900 border border-neutral-800 p-6 rounded-2xl shadow-md">
                <span className="bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-mono text-[9px] uppercase font-bold tracking-widest px-2.5 py-1 rounded inline-block mb-3">
                  Pestaña de Comunidad Interactiva
                </span>
                <h2 className="text-white text-xl font-bold tracking-tight">Publica y Comunícate con tus Suscriptores</h2>
                <p className="text-neutral-400 text-xs sm:text-sm mt-1 leading-relaxed font-sans">
                  Comparte tus reflexiones sobre lo-fi, JavaScript, videojuegos o novedades del canal de OpenTube. Las publicaciones admiten me gustas, no me gustas y hilos de comentarios simulados.
                </p>
              </div>

              {/* DYNAMIC WELCOMERS FOR ALL NEW LOGGED USERS (Tick Gris Claro & "Nuevo") */}
              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center animate-pulse">
                    <span className="text-lg">👋</span>
                  </div>
                  <div>
                    <h4 className="text-white text-xs sm:text-sm font-bold flex items-center gap-2">
                      ¡Damos la bienvenida a los nuevos miembros de OpenTube!
                    </h4>
                    <p className="text-neutral-400 text-[10.5px] sm:text-xs">
                      Cada nueva cuenta registrada recibe un cálido saludo oficial, el <span className="text-neutral-200 font-bold underline decoration-neutral-500">Tick Gris Claro</span> y la etiqueta <span className="bg-neutral-805 px-1 py-0.5 rounded text-[9px] font-black uppercase text-neutral-450">Nuevo</span>.
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1.5 text-[10px] font-mono shrink-0">
                  <span className="bg-neutral-950 px-2.5 py-1.5 rounded-lg border border-neutral-850 text-neutral-450 hover:border-neutral-700 transition-colors">
                    👋 Bienvenido, <span className="text-white font-bold">Carlos Tech</span>
                  </span>
                  <span className="bg-neutral-950 px-2.5 py-1.5 rounded-lg border border-neutral-850 text-neutral-450 hover:border-neutral-700 transition-colors">
                    👋 Bienvenido, <span className="text-white font-bold">Elena R.</span>
                  </span>
                  <span className="bg-neutral-950 px-2.5 py-1.5 rounded-lg border border-neutral-850 text-neutral-450 hover:border-neutral-700 transition-colors">
                    👋 Bienvenido, <span className="text-white font-bold">Pedro Tech</span>
                  </span>
                </div>
              </div>

              {/* CREATE NEW POST FORM */}
              <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 flex flex-col gap-3">
                <div className="flex items-center gap-2">
                  <img src={currentUser.avatarUrl} alt="Yo" className="w-8 h-8 rounded-full border border-red-500 object-cover" />
                  <span className="text-white text-xs font-bold font-mono">Escribiendo como {currentUser.name} (Canal Verificado)</span>
                </div>

                <form onSubmit={handleCreatePost} className="flex flex-col gap-3 mt-1">
                  <textarea
                    required
                    rows={3}
                    placeholder="Escribe un anuncio, encuesta o pensamiento para la comunidad de fans..."
                    value={newPostText}
                    onChange={(e) => setNewPostText(e.target.value)}
                    className="w-full bg-neutral-950 text-white placeholder-neutral-500 text-xs sm:text-sm rounded-xl px-4 py-3 border border-neutral-850 focus:outline-none focus:border-indigo-500 transition-colors resize-none"
                  />
                  <button
                    type="submit"
                    className="self-end px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 hover:shadow-lg active:scale-95 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Publicar en Comunidad</span>
                  </button>
                </form>
              </div>

              {/* POSTS TIMELINE LIST */}
              <div className="flex flex-col gap-5">
                {posts.map((post) => (
                  <div key={post.id} className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 flex flex-col gap-4 shadow-sm animate-fade-in">
                    
                    {/* Upper row details */}
                    <div className="flex items-center justify-between border-b border-neutral-800/80 pb-3">
                      <div className="flex items-center gap-2.5">
                        <img src={post.authorAvatar} alt={post.authorName} className="w-9 h-9 rounded-full border border-neutral-800 object-cover" />
                        <div>
                          <div className="flex items-center gap-1">
                            <span className="text-white text-xs font-bold leading-none">{post.authorName}</span>
                            {post.authorName === currentUser.name && (
                              <span className="inline-flex items-center gap-1">
                                <VerifiedBadge type={currentUser.vipEmblem} size="sm" />
                                {currentUser.vipEmblem === 'star' && (
                                  <span className="px-1 py-0.5 text-[7px] font-black uppercase tracking-wider bg-gradient-to-r from-red-500 to-amber-500 text-neutral-950 rounded shadow-sm select-none">
                                    creator
                                  </span>
                                )}
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-neutral-500 font-sans block mt-1">{post.timestamp}</span>
                        </div>
                      </div>

                      {/* Delete self community post */}
                      {post.authorName === currentUser.name && (
                        <button
                          onClick={() => {
                            if (window.confirm("¿Seguro que deseas eliminar este anuncio?")) {
                              setPosts(posts.filter(p => p.id !== post.id));
                            }
                          }}
                          className="p-1 rounded hover:bg-neutral-805 text-neutral-500 hover:text-red-500 transition-all cursor-pointer"
                          title="Borrar publicación"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Main post text content */}
                    <p className="text-neutral-200 text-xs sm:text-sm font-sans leading-relaxed whitespace-pre-wrap">
                      {post.text}
                    </p>

                    {/* Post action row (Likes & Dislikes) */}
                    <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl self-start border border-neutral-800">
                      <button
                        onClick={() => handlePostVote(post.id, 'like')}
                        className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold leading-none transition-all ${
                          post.userVoted === 'like'
                            ? 'bg-indigo-600/20 text-indigo-400'
                            : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                        }`}
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>{post.likes}</span>
                      </button>

                      <button
                        onClick={() => handlePostVote(post.id, 'dislike')}
                        className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold leading-none transition-all ${
                          post.userVoted === 'dislike'
                            ? 'bg-neutral-800 text-zinc-300'
                            : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                        }`}
                      >
                        <ThumbsDown className="w-3.5 h-3.5" />
                        <span>{post.dislikes}</span>
                      </button>
                    </div>

                    {/* Nested Post Comments (Interactive Sub-feed) */}
                    <div className="bg-neutral-950/60 p-4 rounded-xl border border-neutral-800/80 flex flex-col gap-3 font-sans">
                      <span className="text-neutral-400 text-[10px] uppercase font-bold tracking-wider block mb-1">Comentarios del Anuncio ({post.comments.length})</span>
                      
                      {post.comments.map(c => (
                        <div key={c.id} className="text-xs flex gap-2 pt-2.5 border-t border-neutral-900 first:border-0 first:pt-0">
                          <img src={c.avatarUrl} alt={c.author} className="w-6 h-6 rounded-full object-cover border border-neutral-800 shrink-0" />
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-1.5 leading-none">
                              <span className="text-neutral-200 font-bold block leading-none">{c.author}</span>
                              {c.author === currentUser.name ? (
                                <VerifiedBadge type={currentUser.vipEmblem} size="sm" />
                              ) : (
                                <span className="inline-flex items-center gap-1">
                                  <VerifiedBadge type="new-member" size="sm" />
                                  <span className="px-1 py-0.2 text-[7px] font-black uppercase bg-neutral-800 text-neutral-400 rounded">
                                    Nuevo
                                  </span>
                                </span>
                              )}
                            </div>
                            <span className="text-neutral-300 text-[11px] block mt-1 leading-normal">{c.text}</span>
                          </div>
                        </div>
                      ))}

                      {/* Comment Input action on post */}
                      <div className="flex gap-2 mt-2 pt-2 border-t border-neutral-900/60">
                        <input
                          type="text"
                          placeholder="Responde a esta publicación..."
                          value={postCommentInputs[post.id] || ''}
                          onChange={(e) => setPostCommentInputs({ ...postCommentInputs, [post.id]: e.target.value })}
                          className="flex-1 bg-neutral-950 border border-neutral-850 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-indigo-500"
                        />
                        <button
                          type="button"
                          onClick={() => handleAddPostComment(post.id, postCommentInputs[post.id] || '')}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 rounded-lg text-xs font-bold text-white transition-colors"
                        >
                          Comentar
                        </button>
                      </div>
                    </div>

                  </div>
                ))}
              </div>

            </div>
          )}

          {/* TAB 4: PROFILE & CREATOR CONFIG (ME CREADOR) */}
          {activeTab === 'profile' && (
            <div className="animate-fade-in">
              <ProfileSettings 
                currentUser={currentUser}
                onUpdateUser={handleUpdateUser}
                videos={videos}
                playbackProgress={playbackProgress}
                onSelectVideo={handleSelectVideo}
                onAdminCommand={handleAdminCommand}
              />
            </div>
          )}

        </main>
      </div>

      {/* FOOTER DECOR */}
      <footer className="border-t border-neutral-900 py-6 px-6 bg-neutral-950 z-10 text-center font-sans text-[11px] text-neutral-500">
        <p>© OpenTube Streaming Media. Desarrollador Vip: GamerCool OpenTube.</p>
      </footer>

      {/* 4. MODULAR UPLOAD DIALOG OVERLAY */}
      <UploadModal 
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        initialMode={uploadMode}
        currentUser={currentUser}
        existingVideos={videos}
        onUpload={handleUploadVideo}
      />

      {/* REMIX DE AUDIO CON IA MODAL OVERLAY */}
      {remixModalVideo && (
        <div className="fixed inset-0 z-[99990] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 max-w-sm w-full shadow-2xl relative flex flex-col gap-4">
            <button 
              onClick={() => setRemixModalVideo(null)}
              className="absolute top-4 right-4 text-neutral-400 hover:text-white p-1 hover:bg-neutral-800 rounded-full transition-all"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3 border-b border-neutral-800 pb-3">
              <span className="p-2 bg-amber-500/10 border border-amber-500/20 text-amber-500 rounded-full">
                <Music className="w-5 h-5 animate-bounce" />
              </span>
              <div>
                <h4 className="text-white font-black text-xs sm:text-sm tracking-tight uppercase font-sans">Remix de Audio con IA 🎙️</h4>
                <p className="text-amber-500 text-[9.5px] uppercase font-mono font-bold">Cumplimiento Estricto de Copyright</p>
              </div>
            </div>

            <div className="space-y-2 text-xs sm:text-sm">
              <p className="text-neutral-300 leading-relaxed font-sans">
                La Inteligencia Artificial de OpenTube aislará y extraerá la pista de música/sonido limpia del video:
              </p>
              <div className="bg-neutral-950 p-3 rounded-xl border border-neutral-800 font-mono text-xs text-amber-400">
                "{remixModalVideo.title}"
              </div>
              <div className="bg-red-950/20 border border-red-500/20 rounded-xl p-3 text-red-350 text-xs leading-snug">
                ⚠️ **Seguridad Antipiratería Activa:** Para evitar el plagio y robo de contenido de marca ajena, las plantillas visuales han sido desactivadas en el sistema de remixes. Solo podrás reutilizar el audio limpio de fondo y deberás grabar o subir tus propias imágenes para el Short.
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-2">
              <button
                type="button"
                onClick={() => setRemixModalVideo(null)}
                className="bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  const targetVideo = remixModalVideo;
                  setRemixModalVideo(null);
                  handleOpenUploadModal('short');
                  // Give modal inputs some presets
                  setTimeout(() => {
                    const titleInput = document.querySelector('input[placeholder*="React de" i]') as HTMLInputElement || document.querySelector('input[type="text"]') as HTMLInputElement;
                    if (titleInput) {
                      titleInput.value = `Remix de ${targetVideo.authorName} - Audio AI`;
                      const event = new Event('input', { bubbles: true });
                      titleInput.dispatchEvent(event);
                    }
                  }, 200);
                }}
                className="bg-red-650 hover:bg-red-500 text-white font-bold text-xs py-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Crear Short con Audio ⚡
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. ON-DEVICE AI TOXICITY WARNING DIALOG OVERLAY */}
      {commentBlockedModal && (
        <div className="fixed inset-0 z-[99995] bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-neutral-900 border-2 border-red-600 rounded-3xl p-6 max-w-md w-full shadow-[0_0_60px_rgba(239,68,68,0.35)] flex flex-col gap-4 relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-[40px] pointer-events-none" />
            
            <div className="flex items-center gap-3 border-b border-neutral-800 pb-3">
              <div className="p-2 bg-red-500/15 border border-red-500/30 text-red-500 rounded-full">
                <Sparkles className="w-6 h-6 text-red-500 animate-pulse" />
              </div>
              <div>
                <h4 className="text-white font-black text-sm tracking-wide uppercase font-sans">COMENTARIO BLOQUEADO POR IA 🛡️</h4>
                <p className="text-red-500 text-[10px] uppercase font-mono font-bold">Filtro de Moderación Activo de OpenTube</p>
              </div>
            </div>

            <div className="space-y-3">
              <p className="text-neutral-300 text-xs leading-relaxed font-sans">
                Nuestra Inteligencia Artificial de moderación ha detectado e interceptado un comentario ofensivo o inapropiado. Tu lenguaje infringe las normas.
              </p>
              
              <div className="bg-red-950/20 border border-red-900/30 rounded-xl p-3 text-red-400 font-mono italic text-xs leading-relaxed">
                "{commentBlockedModal.originalText}"
              </div>

              <div className="bg-neutral-950 border border-neutral-850 rounded-xl p-2.5 font-mono text-[10px] text-neutral-400 space-y-1 leading-normal">
                <div><span className="text-neutral-600">Categoría Sanción:</span> <span className="text-red-400 font-bold">{commentBlockedModal.reason}</span></div>
                <div><span className="text-neutral-600">Advertencias Totales de tu Perfil:</span> <span className="text-red-500 font-extrabold text-base bg-red-950 px-2 py-0.5 rounded ml-1 animate-pulse">{commentBlockedModal.warningCount} / 3</span></div>
              </div>

              {commentBlockedModal.warningCount >= 3 ? (
                <div className="p-3 rounded-lg bg-orange-950/40 border border-orange-500/30 text-[10px] text-orange-400 leading-normal font-sans text-center">
                  🚨 ¡ATENCIÓN! Has superado las 3 advertencias acumuladas en tu historial.
                </div>
              ) : null}
            </div>

            <button
              onClick={() => setCommentBlockedModal(null)}
              className="w-full py-2.5 bg-red-650 hover:bg-red-500 text-white font-black tracking-wider text-xs uppercase rounded-xl transition-all shadow-md shadow-red-950/20 cursor-pointer"
            >
              Entendido, Respetaré las Reglas
            </button>
          </div>
        </div>
      )}

      {/* 6. REPORT / REPORTAR INTERACTIVE MODAL OVERLAY */}
      {reportingVideo && (
        <div className="fixed inset-0 z-[99990] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 max-w-lg w-full shadow-[0_0_50px_rgba(239,68,68,0.1)] flex flex-col gap-4 relative">
            
            <div className="flex justify-between items-center border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-red-500 text-lg">🚩</span>
                <div>
                  <h4 className="text-white font-black text-xs sm:text-sm tracking-wide uppercase font-sans">Reportar Infracción de Video/Short</h4>
                  <p className="text-neutral-550 text-[10px] truncate max-w-sm font-mono mt-0.5">{reportingVideo.title}</p>
                </div>
              </div>
              <button 
                onClick={() => setReportingVideo(null)}
                className="p-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4">
              <label className="block text-[11px] font-bold text-neutral-300 uppercase tracking-wider font-sans">Selecciona el motivo del reporte:</label>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                {[
                  "Infracción de derechos de autor (Copyright)",
                  "Contenido violento o repulsivo",
                  "Contenido sexual explícito",
                  "Contenido provocativo o incitación al odio",
                  "Acoso o bullying",
                  "Spam o contenido engañoso",
                  "Maltrato infantil o peligro para menores"
                ].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedReportCategory(cat)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between ${
                      selectedReportCategory === cat
                        ? 'bg-red-950/40 border-red-500 text-red-400 font-bold'
                        : 'bg-neutral-950 border-neutral-850 text-neutral-400 hover:bg-neutral-850 hover:text-neutral-200'
                    }`}
                  >
                    <span>{cat}</span>
                    {selectedReportCategory === cat && <span className="text-red-500 text-xs">●</span>}
                  </button>
                ))}
              </div>

              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold text-neutral-300 uppercase tracking-wider font-sans">Añadir observaciones o marcas de tiempo:</label>
                <textarea
                  value={reportDescription}
                  onChange={(e) => setReportDescription(e.target.value)}
                  placeholder="Por favor, especifica por qué incumple las condiciones de servicio de OpenTube..."
                  className="w-full bg-neutral-950 border border-neutral-850 text-neutral-200 text-xs p-3 rounded-xl focus:border-red-500 outline-none h-16 resize-none"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-2 border-t border-neutral-850 pt-4 text-[11px] font-bold">
              <button
                onClick={() => setReportingVideo(null)}
                className="flex-1 py-3 border border-neutral-800 hover:bg-neutral-800 text-neutral-450 rounded-xl transition-all"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  const subject = `📢 REPORT: [OpenTube] Reporte de Infracción sobre ${reportingVideo.title}`;
                  const body = 
                    `--- REPORTE OFICIAL DE COMUNIDAD DE OPENTUBE ---\n\n` +
                    `Detalles de la Infracción:\n` +
                    `ID del Video: ${reportingVideo.id}\n` +
                    `Título: ${reportingVideo.title}\n` +
                    `Autor: ${reportingVideo.authorName}\n` +
                    `URL del Recurso: ${reportingVideo.videoUrl}\n\n` +
                    `Categoría elegida: ${selectedReportCategory}\n` +
                    `Descripción detallada: ${reportDescription || "Sin descripción adicional"}\n\n` +
                    `Reportador: ${currentUser.name}\n` +
                    `Advertencias acumuladas: ${currentUser.warnings || 0}\n\n` +
                    `El usuario ha reportado esto desde su interfaz web como prioridad. Enviado prioritariamente a OpenTubeofficial@proton.me`;
                  
                  // Open mail handler
                  window.location.href = `mailto:OpenTubeofficial@proton.me?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
                  
                  // Clean video from local list so it disappears for reported user
                  setVideos(prev => prev.filter(v => v.id !== reportingVideo.id));
                  if (selectedVideo && selectedVideo.id === reportingVideo.id) {
                    setSelectedVideo(null);
                  }
                  
                  // Trigger success modal
                  setReportSuccessModal(true);
                  setReportingVideo(null);
                }}
                className="flex-1 py-1 px-3 bg-red-600 hover:bg-red-505 text-white rounded-xl transition-all flex items-center justify-center gap-1.5"
              >
                <span>Enviar Reporte 📧</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. REPORT EXTREME SUCCESS NOTIFICATION MODAL */}
      {reportSuccessModal && (
        <div className="fixed inset-0 z-[99999] bg-neutral-950/95 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-neutral-900 border border-green-500 rounded-3xl p-6 max-w-sm w-full shadow-[0_0_50px_rgba(34,197,94,0.15)] flex flex-col gap-4 text-center">
            <div className="w-12 h-12 bg-green-500/15 border border-green-500/30 text-green-550 rounded-full flex items-center justify-center mx-auto animate-pulse">
              <span className="text-xl">✅</span>
            </div>
            
            <h4 className="text-white font-extrabold text-xs tracking-wider uppercase">¡Reporte Enviado!</h4>
            <p className="text-neutral-400 text-xs leading-relaxed font-sans">
              El reporte contra el video ha sido enviado exitosamente mediante correo prioritario y registrado para resolución prioritariamente a <span className="text-green-400 font-bold">OpenTubeofficial@proton.me</span>. 
              <br /><br />
              Hemos removido este video de tu feed e historial local de forma permanente. ¡Gracias por mantener limpia y segura nuestra plataforma!
            </p>

            <button
              onClick={() => {
                setReportSuccessModal(false);
                setReportDescription('');
              }}
              className="w-full py-2 bg-green-500 hover:bg-green-400 text-neutral-950 font-black tracking-wider text-xs uppercase rounded-xl transition-all cursor-pointer"
            >
              Regresar a OpenTube
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
