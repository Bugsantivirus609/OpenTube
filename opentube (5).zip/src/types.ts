export interface UserProfile {
  name: string;
  avatarUrl: string;
  subscribers: number;
  vipEmblem?: 'classic' | 'crown' | 'star' | 'shield'; // exclusive VIP badge theme
  vipNeonTheme?: boolean; // exclusive VIP neon design glow
  vipAnnouncement?: string; // custom platform announcement banner
  socialInstagram?: string;
  socialTwitter?: string;
  socialYoutube?: string;
  socialGithub?: string;
  warnings?: number; // warnings counter for community moderation rules
}

export interface Comment {
  id: string;
  author: string;
  avatarUrl: string;
  text: string;
  timestamp: string;
  likes: number;
  dislikes: number;
  userVoted?: 'like' | 'dislike';
  replies?: Comment[]; // Threaded replies
}

export interface Video {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  duration: number; // in seconds
  views: number;
  uploadDate: string;
  likes: number;
  dislikes: number;
  userVoted?: 'like' | 'dislike';
  category: string;
  isShort: boolean;
  authorName: string;
  authorAvatar: string;
  isVerifiedAuthor: boolean;
  isAudio?: boolean;
  comments: Comment[];
  hashtags?: string[]; // Custom hashtags
  language?: string; // e.g. "English", "Spanish", "Japanese" etc.
  originalityScore?: number;
}

export interface Post {
  id: string;
  authorName: string;
  authorAvatar: string;
  isVerifiedAuthor: boolean;
  text: string;
  mediaUrl?: string;
  timestamp: string;
  likes: number;
  dislikes: number;
  userVoted?: 'like' | 'dislike';
  comments: Comment[];
}
